
  # 3D Underwater Simulation Game

  This is a code bundle for 3D Underwater Simulation Game. The original project is available at https://www.figma.com/design/E0mV7Phg6MA0c1gmYWAYrB/3D-Underwater-Simulation-Game.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  