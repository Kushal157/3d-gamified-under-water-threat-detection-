import { useState } from 'react';
import { UnderwaterScene } from './components/UnderwaterScene';
import { ControlPanel } from './components/ControlPanel';
import { DetectionPanel } from './components/DetectionPanel';
import { InfoPanel } from './components/InfoPanel';
import { YOLOv8ProcessingIndicator } from './components/YOLOv8ProcessingIndicator';
import { SubmarineController, SubmarineMovement } from './components/SubmarineController';
import { EnvironmentZoneIndicator } from './components/EnvironmentZoneIndicator';
import { PDFReportGenerator } from './components/PDFReportGenerator';
import { DynamicEnvironmentManager } from './components/DynamicEnvironmentManager';
import { Button } from './components/ui/button';
import { Switch } from './components/ui/switch';
import { Label } from './components/ui/label';
import { Settings, AlertTriangle, Navigation2 } from 'lucide-react';

export default function App() {
  const [isScanning, setIsScanning] = useState(false);
  const [detectionRange, setDetectionRange] = useState(50);
  const [aiSensitivity, setAiSensitivity] = useState(0.7);
  const [detectedThreats, setDetectedThreats] = useState<any[]>([]);
  const [sonarPulseActive, setSonarPulseActive] = useState(false);
  const [scanDirection, setScanDirection] = useState<'north' | 'south' | 'east' | 'west' | 'all'>('all');
  const [activePanel, setActivePanel] = useState<'sonar' | 'threats' | null>(null);
  const [isVisualizationActive, setIsVisualizationActive] = useState(false);
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.5);
  const [showConfidenceFilter, setShowConfidenceFilter] = useState(false);
  
  // Submarine movement state
  const [submarineMovement, setSubmarineMovement] = useState<SubmarineMovement>({
    position: [0, -15, 0],
    rotation: 0,
    velocity: [0, 0, 0]
  });
  
  const handleScan = (direction: 'north' | 'south' | 'east' | 'west' | 'all') => {
    setScanDirection(direction);
    setIsScanning(true);
    setSonarPulseActive(true);
    
    // Simulate scan duration
    setTimeout(() => {
      setIsScanning(false);
    }, 3000);
  };

  const handleReset = () => {
    setDetectedThreats([]);
    setSonarPulseActive(false);
    setIsScanning(false);
    setIsVisualizationActive(false);
  };

  const toggleVisualization = () => {
    setIsVisualizationActive(!isVisualizationActive);
  };
  
  // Filter threats by confidence threshold
  const filteredThreats = showConfidenceFilter 
    ? detectedThreats.filter(t => parseFloat(t.confidence) / 100 >= confidenceThreshold)
    : detectedThreats;

  return (
    <div className="relative w-full h-screen bg-slate-950 overflow-hidden">
      {/* Submarine Controller */}
      <SubmarineController 
        onMove={setSubmarineMovement}
        movement={submarineMovement}
      />
      
      <DynamicEnvironmentManager submarinePosition={submarineMovement.position}>
        {(environment) => (
          <>
            {/* 3D Scene */}
            <UnderwaterScene 
              isScanning={isScanning}
              detectionRange={detectionRange}
              aiSensitivity={aiSensitivity}
              scanDirection={scanDirection}
              onThreatsDetected={setDetectedThreats}
              sonarPulseActive={sonarPulseActive}
              isVisualizationActive={isVisualizationActive}
              detectedThreats={filteredThreats}
              submarinePosition={submarineMovement.position}
              submarineRotation={submarineMovement.rotation}
              submarineVelocity={submarineMovement.velocity}
              dynamicThreats={environment.threats}
              dynamicMines={environment.mines}
            />
            
            {/* UI Overlay */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="container mx-auto h-full p-6 flex flex-col">
                {/* Header */}
                <div className="pointer-events-auto mb-6 flex gap-4">
                  <div className="flex-1">
                    <InfoPanel />
                  </div>
                  <div className="w-80">
                    <EnvironmentZoneIndicator 
                      zone={environment.zone}
                      submarinePosition={submarineMovement.position}
                    />
                  </div>
                </div>
                
                {/* Spacer */}
                <div className="flex-1" />
                
                {/* Bottom Panel Area */}
                <div className="pointer-events-auto space-y-3">
                  {/* Panel Content */}
                  {activePanel === 'sonar' && (
                    <div className="flex justify-center">
                      <div className="w-full max-w-5xl space-y-3">
                        {/* Confidence Threshold Control */}
                        {detectedThreats.length > 0 && (
                          <div className="bg-slate-900/95 border border-cyan-500/40 backdrop-blur-md rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-3">
                                <Switch
                                  checked={showConfidenceFilter}
                                  onCheckedChange={setShowConfidenceFilter}
                                  id="confidence-filter"
                                />
                                <Label htmlFor="confidence-filter" className="text-white cursor-pointer">
                                  Confidence Threshold Filter
                                </Label>
                              </div>
                              {showConfidenceFilter && (
                                <span className="text-cyan-400">{(confidenceThreshold * 100).toFixed(0)}%</span>
                              )}
                            </div>
                            {showConfidenceFilter && (
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={confidenceThreshold * 100}
                                onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value) / 100)}
                                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                              />
                            )}
                          </div>
                        )}
                        
                        <ControlPanel 
                          isScanning={isScanning}
                          onScan={handleScan}
                          onReset={handleReset}
                          detectionRange={detectionRange}
                          onDetectionRangeChange={setDetectionRange}
                          aiSensitivity={aiSensitivity}
                          onAiSensitivityChange={setAiSensitivity}
                          hasDetections={detectedThreats.length > 0}
                          currentDirection={scanDirection}
                        />
                      </div>
                    </div>
                  )}
                  
                  {activePanel === 'threats' && (
                    <div className="flex justify-center">
                      <div className="w-full max-w-5xl space-y-3">
                        {/* PDF Report Generator */}
                        {detectedThreats.length > 0 && (
                          <div className="bg-slate-900/95 border border-cyan-500/40 backdrop-blur-md rounded-lg p-4 flex justify-between items-center">
                            <div>
                              <h3 className="text-white mb-1">Threat Report</h3>
                              <p className="text-slate-400 text-sm">Generate detailed PDF report of detected threats</p>
                            </div>
                            <PDFReportGenerator
                              threats={filteredThreats}
                              scanParams={{
                                direction: scanDirection,
                                range: detectionRange,
                                sensitivity: aiSensitivity,
                                submarinePosition: submarineMovement.position
                              }}
                            />
                          </div>
                        )}
                        
                        <DetectionPanel 
                          threats={filteredThreats}
                          isScanning={isScanning}
                          isVisualizationActive={isVisualizationActive}
                          onToggleVisualization={toggleVisualization}
                        />
                      </div>
                    </div>
                  )}
                  
                  {/* Bottom Button Bar */}
                  <div className="flex justify-center gap-4">
                    <Button
                      onClick={() => setActivePanel(activePanel === 'sonar' ? null : 'sonar')}
                      size="lg"
                      className={`${
                        activePanel === 'sonar' 
                          ? 'bg-cyan-600 hover:bg-cyan-700' 
                          : 'bg-slate-800 hover:bg-slate-700'
                      } text-white px-8`}
                    >
                      <Settings className="w-5 h-5 mr-2" />
                      Sonar Control
                    </Button>
                    
                    <Button
                      onClick={() => setActivePanel(activePanel === 'threats' ? null : 'threats')}
                      size="lg"
                      className={`${
                        activePanel === 'threats' 
                          ? 'bg-red-600 hover:bg-red-700' 
                          : 'bg-slate-800 hover:bg-slate-700'
                      } text-white px-8`}
                    >
                      <AlertTriangle className="w-5 h-5 mr-2" />
                      Threat Detection
                      {filteredThreats.length > 0 && (
                        <span className="ml-2 px-2 py-0.5 bg-red-500 rounded-full text-xs">
                          {filteredThreats.length}
                        </span>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Movement Instructions */}
            <div className="absolute top-6 left-6 pointer-events-none space-y-3">
              <div className="bg-slate-900/90 border border-slate-700 backdrop-blur-md rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Navigation2 className="w-4 h-4 text-cyan-400" />
                  <span className="text-white text-sm">Submarine Controls</span>
                </div>
                <div className="space-y-1 text-xs text-slate-400">
                  <div>↑/W - Forward | ↓/S - Backward</div>
                  <div>←/A - Turn Left | →/D - Turn Right</div>
                  <div>Q - Ascend | E - Descend</div>
                </div>
                
                {/* Speed Indicator */}
                <div className="mt-3 pt-3 border-t border-slate-700">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-slate-400">Speed</span>
                    <span className="text-xs text-cyan-400">
                      {(Math.sqrt(
                        submarineMovement.velocity[0] ** 2 + 
                        submarineMovement.velocity[2] ** 2
                      ) * 10).toFixed(1)} knots
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-cyan-500 to-cyan-400 transition-all duration-200"
                      style={{ 
                        width: `${Math.min(
                          (Math.sqrt(
                            submarineMovement.velocity[0] ** 2 + 
                            submarineMovement.velocity[2] ** 2
                          ) * 100), 
                          100
                        )}%` 
                      }}
                    />
                  </div>
                </div>
                
                {/* Depth Indicator */}
                <div className="mt-2">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-slate-400">Depth</span>
                    <span className="text-xs text-blue-400">
                      {Math.abs(submarineMovement.position[1]).toFixed(1)}m
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-500 to-blue-400 transition-all duration-200"
                      style={{ 
                        width: `${(Math.abs(submarineMovement.position[1]) / 35) * 100}%` 
                      }}
                    />
                  </div>
                </div>
              </div>
              
              {/* Compass */}
              <div className="bg-slate-900/90 border border-slate-700 backdrop-blur-md rounded-lg p-4">
                <div className="flex flex-col items-center">
                  <span className="text-white text-xs mb-2">Heading</span>
                  <div className="relative w-20 h-20">
                    {/* Compass Circle */}
                    <div className="absolute inset-0 rounded-full border-2 border-slate-600 bg-slate-800/50" />
                    
                    {/* Cardinal Directions */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="relative w-full h-full">
                        <span className="absolute top-1 left-1/2 -translate-x-1/2 text-xs text-red-400">N</span>
                        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-xs text-slate-500">S</span>
                        <span className="absolute left-1 top-1/2 -translate-y-1/2 text-xs text-slate-500">W</span>
                        <span className="absolute right-1 top-1/2 -translate-y-1/2 text-xs text-slate-500">E</span>
                      </div>
                    </div>
                    
                    {/* Submarine Direction Indicator */}
                    <div 
                      className="absolute inset-0 flex items-center justify-center transition-transform duration-100"
                      style={{ transform: `rotate(${(submarineMovement.rotation * 180 / Math.PI)}deg)` }}
                    >
                      <div className="w-1 h-8 bg-gradient-to-t from-cyan-500 to-cyan-300 rounded-full" />
                    </div>
                    
                    {/* Center Dot */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full" />
                    </div>
                  </div>
                  <span className="text-cyan-400 text-xs mt-2">
                    {((submarineMovement.rotation * 180 / Math.PI + 360) % 360).toFixed(0)}°
                  </span>
                </div>
              </div>
            </div>
          </>
        )}
      </DynamicEnvironmentManager>
      
      {/* Scanning Overlay */}
      {isScanning && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0 bg-cyan-500/5 animate-pulse" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
            <div className="text-cyan-400 text-2xl tracking-widest animate-pulse mb-2">
              SCANNING...
            </div>
            <div className="text-cyan-300 text-sm mb-1">
              Direction: {scanDirection.toUpperCase()}
            </div>
            <div className="text-purple-400 text-xs animate-pulse">
              YOLOv8 AI Processing...
            </div>
          </div>
        </div>
      )}
      
      {/* YOLOv8 Processing Indicator */}
      <YOLOv8ProcessingIndicator isProcessing={isScanning} />
      
      {/* Visualization Active Indicator */}
      {isVisualizationActive && detectedThreats.length > 0 && (
        <div className="absolute top-24 right-6 pointer-events-none">
          <div className="bg-green-500/20 border border-green-500/40 backdrop-blur-md rounded-lg px-4 py-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-green-400 text-sm">3D Visualization Active</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}