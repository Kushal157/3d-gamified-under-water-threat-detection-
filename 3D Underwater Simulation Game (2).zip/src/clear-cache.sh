#!/bin/bash

echo "🧹 Clearing all Three.js caches and reinstalling..."
echo ""

# Clear Vite cache
echo "Clearing Vite cache..."
rm -rf .vite
rm -rf dist

# Clear node modules
echo "Clearing node_modules..."
rm -rf node_modules

# Clear lock files
echo "Clearing lock files..."
rm -f package-lock.json
rm -f yarn.lock
rm -f pnpm-lock.yaml

# Clear npm cache
echo "Clearing npm cache..."
npm cache clean --force

echo ""
echo "✅ All caches cleared!"
echo ""
echo "Now run: npm install"
echo "Then run: npm run dev"
