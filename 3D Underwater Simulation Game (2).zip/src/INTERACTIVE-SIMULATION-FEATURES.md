# Interactive Simulation Features

## Overview
The underwater threat detection simulation has been transformed into a fully interactive experience with dynamic submarine movement, real-time environment generation, and comprehensive PDF threat reporting.

## 🎮 Interactive Features

### 1. Submarine Movement System
- **Keyboard Controls**: 
  - Arrow Keys / WASD: Forward, backward, left/right rotation
  - Q/E: Ascend/Descend
- **On-Screen Joystick**: Touch-friendly control for movement
- **Smooth Physics**: Realistic submarine movement with inertia and floating animation
- **Position Tracking**: Real-time coordinate display in environment zone indicator

### 2. Dynamic Environment Generation
- **Zone-Based Threats**: Environment changes based on submarine position
  - **Safe Zone** (Center): Low threat density, patrolled waters
  - **Contested Waters** (Mid-range): Medium threat density, disputed area
  - **Hostile Territory** (Far range): High threat density, enemy waters
- **Procedural Generation**: Threats and mines spawn dynamically as you move
- **Context-Aware**: Threat types vary based on current zone

### 3. Position-Relative Sonar Scanning
- **Mobile Scan Origin**: Sonar pulses emit from submarine's current position
- **Directional Scanning**: North, South, East, West, or 360° coverage
- **Range-Based Detection**: Adjustable detection range (20m-80m)
- **AI Sensitivity Control**: Filter threats by confidence threshold

### 4. PDF Threat Report Generation
Generates comprehensive military-style reports including:
- **Header**: Classified document styling with Indian Navy branding
- **Timestamp**: Full date/time in IST timezone
- **Submarine Coordinates**: Exact X, Y (depth), Z position at scan time
- **Scan Parameters**: Direction, range, AI sensitivity, model version
- **Threat Table**: ID, type, distance, confidence, threat level
- **Tactical Map**: Visual representation of submarine and detected threats
- **Color-Coded Threats**: Critical (red), Medium (orange), Low (yellow)
- **Legend**: Clear identification of map symbols
- **Report Metadata**: Unique report ID, page numbers, classification markings

### 5. Confidence Threshold Filter
- **Toggle Control**: Enable/disable filtering in Sonar Control panel
- **Adjustable Slider**: Set minimum confidence level (0-100%)
- **Real-Time Filtering**: Updates threat list and visualizations immediately
- **Affects All Outputs**: Filters detection panel, 3D visualization, and PDF reports

### 6. Environment Zone Indicator
- **Current Zone Display**: Safe Zone, Contested Waters, or Hostile Territory
- **Threat Level Badge**: Color-coded (green/yellow/red) density indicator
- **Position Readout**: Live submarine coordinates
- **Zone Description**: Contextual information about current area

## 📋 How to Use

### Basic Operation
1. **Launch Application**: System starts in Safe Zone at coordinates (0, -15, 0)
2. **Move Submarine**: Use keyboard (WASD/Arrows + Q/E) or joystick
3. **Configure Sonar**: Click "Sonar Control" to access settings
4. **Initiate Scan**: Select direction and click to start detection
5. **View Results**: Click "Threat Detection" to see detected objects
6. **Generate Report**: Click "Generate PDF Report" after successful scan

### Advanced Features
- **Filter Low Confidence**: Enable threshold filter in Sonar Control
- **3D Visualization**: Toggle threat highlighting in 3D scene
- **Explore Zones**: Move to different areas to encounter varied threats
- **Reset Detection**: Clear all previous scan data

## 🔧 Technical Details

### Dynamic Threat System
- Threats regenerate every 10 meters of movement
- Position-based seeding ensures consistent local threats
- Threat count and types scale with zone danger level
- Mines use separate generation algorithm

### Sonar Detection
- Distance calculations relative to submarine position
- Directional scanning uses angle-based filtering
- YOLOv8 confidence scores with realistic variance
- Threat level assessment considers type, confidence, and proximity

### PDF Generation
- Uses jsPDF library for client-side report creation
- Military-standard document formatting
- Automatic filename with date and timestamp
- No server required - fully client-side

## 📦 New Components

1. **PDFReportGenerator.tsx**: PDF generation with jsPDF
2. **DynamicEnvironmentManager.tsx**: Procedural threat/mine generation
3. **EnvironmentZoneIndicator.tsx**: Zone and position display
4. **SubmarineController.tsx**: Movement input handler (enhanced)
5. **Joystick.tsx**: Touch-friendly movement control (enhanced)

## 🎯 Key Enhancements

- **Reactive Environment**: World changes as you explore
- **Position Awareness**: All systems use submarine location
- **Professional Reporting**: Military-grade threat documentation
- **User Control**: Full submarine navigation capability
- **Visual Feedback**: Clear indicators for zone, position, and status

## 🚀 Future Enhancements

Possible additions:
- Waypoint navigation system
- Mission objectives with predefined routes
- Historical scan data archive
- Multi-page PDF reports with trend analysis
- Threat tracking over time
- Collision detection with obstacles
- Battery/fuel management
- Communication range limitations
