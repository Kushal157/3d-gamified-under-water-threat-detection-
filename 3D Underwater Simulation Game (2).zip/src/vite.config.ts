import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    dedupe: ['three', '@react-three/fiber', '@react-three/drei'],
    alias: {
      'three': path.resolve(__dirname, './node_modules/three'),
    },
  },
  optimizeDeps: {
    include: ['three', '@react-three/fiber', '@react-three/drei'],
    exclude: [],
    esbuildOptions: {
      target: 'es2020',
    },
    force: true,
  },
  build: {
    target: 'es2020',
    commonjsOptions: {
      include: [/three/, /node_modules/],
    },
    rollupOptions: {
      output: {
        manualChunks: {
          'three-core': ['three'],
          'three-fiber': ['@react-three/fiber', '@react-three/drei'],
        },
      },
    },
  },
  server: {
    fs: {
      strict: false,
    },
  },
});