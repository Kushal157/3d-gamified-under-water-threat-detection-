# Quick Usage Guide - Interactive Submarine Simulation

## 🚀 Getting Started

### Installation
```bash
npm install
npm run dev
```

The application will start at `http://localhost:5173`

## 🎮 Controls

### Submarine Movement

**Keyboard Controls:**
- `↑` or `W` - Move Forward
- `↓` or `S` - Move Backward  
- `←` or `A` - Turn Left
- `→` or `D` - Turn Right
- `Q` - Ascend (go up)
- `E` - Descend (go down)

**Joystick Control:**
- Drag the cyan joystick (bottom-left) with mouse or touch
- Forward/backward movement
- Left/right turning

**Camera:**
- Click and drag to rotate view
- Scroll to zoom in/out
- Right-click drag to pan

## 📡 Operating the Sonar System

### 1. Open Sonar Control Panel
Click the **"Sonar Control"** button at the bottom of the screen

### 2. Configure Scan Parameters

**Scan Direction:**
- Use arrow buttons to select direction: North, South, East, West
- Or click center button for 360° scan

**Detection Range:**
- Adjust slider: 20m to 80m
- Longer range = more area covered
- Shorter range = higher accuracy

**AI Sensitivity:**
- Adjust slider: 50% to 100%
- Higher = detect more objects (including low confidence)
- Lower = only high-confidence threats

### 3. Start Scanning
- Click any direction button
- Watch the scan progress (3 seconds)
- Sonar pulses emit from submarine position
- YOLOv8 AI processes the data

### 4. View Results
- Click **"Threat Detection"** button
- See list of detected threats
- Each shows: Type, Distance, Confidence, Threat Level

## 📊 Advanced Features

### Confidence Threshold Filter
In Sonar Control panel:
1. Enable the **"Confidence Threshold Filter"** toggle
2. Adjust slider to set minimum confidence (0-100%)
3. Only threats above threshold will display

### 3D Threat Visualization
In Threat Detection panel:
1. Click **"Visualize"** button
2. Threats highlighted in 3D scene with bounding boxes
3. Click again to hide visualization

### PDF Report Generation
In Threat Detection panel:
1. After scanning, click **"Generate PDF Report"**
2. Comprehensive report downloads automatically
3. Includes:
   - Timestamp and submarine coordinates
   - All detected threats with details
   - Tactical situation map
   - Scan parameters used

### Reset Detections
In Sonar Control panel:
- Click **"Reset Detections"** to clear all previous scan data
- Starts fresh for next scan

## 🗺️ Environment Zones

### Safe Zone (Green)
- **Location**: Center area (0, 0)
- **Threat Level**: Low
- **Characteristics**: Patrolled waters, few threats

### Contested Waters (Yellow)
- **Location**: Mid-range areas
- **Threat Level**: Medium  
- **Characteristics**: Disputed territory, moderate threats

### Hostile Territory (Red)
- **Location**: Far from center (>60m)
- **Threat Level**: High
- **Characteristics**: Enemy waters, many threats

**Zone changes automatically as you move!**

## 💡 Pro Tips

1. **Explore Different Zones**: Move around to encounter varied threat densities
2. **Use Directional Scans**: More focused than 360° in specific directions
3. **Adjust Range**: Match detection range to current zone
4. **Filter by Confidence**: Enable threshold to focus on high-priority threats
5. **Generate Reports**: Document all significant scans for analysis
6. **Watch Your Depth**: Q/E keys control depth (stay between -5m and -35m)
7. **Zone Awareness**: Check top-right indicator for current zone and position

## 🎯 Typical Workflow

1. **Navigate** to area of interest using keyboard/joystick
2. **Check Zone** in top-right Environment Zone Indicator
3. **Open Sonar Control** and configure parameters
4. **Scan** in desired direction
5. **Review Results** in Threat Detection panel
6. **Visualize** threats in 3D if needed
7. **Generate PDF** report for documentation
8. **Move** to new location and repeat

## ⚠️ Important Notes

- **Dynamic Threats**: New threats appear as you move (every 10m)
- **Relative Detection**: All scans are relative to submarine position
- **Battery**: Unlimited in demo mode
- **Collisions**: Not implemented - submarine can pass through objects
- **Performance**: Reduce graphics quality if experiencing lag

## 🆘 Troubleshooting

**No Threats Detected?**
- Check if you're too far from threats (increase range)
- Lower AI sensitivity threshold
- Try 360° scan instead of directional

**Joystick Not Working?**
- Make sure you're clicking/touching the joystick area
- Try keyboard controls as backup

**PDF Won't Download?**
- Ensure browser allows downloads
- Check if threats were actually detected
- Try scanning again

**Scene Not Loading?**
- Refresh page
- Check console for errors
- Ensure WebGL is supported in browser

## 📱 Mobile Support

- Touch controls work on mobile devices
- Joystick is touch-optimized
- Pinch to zoom, two-finger pan
- Recommended: Tablet or larger screen for best experience

---

**Happy Hunting! 🎯⚓**
