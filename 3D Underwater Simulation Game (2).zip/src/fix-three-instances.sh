#!/bin/bash

echo "🔧 Fixing Multiple Three.js Instances Warning..."
echo ""

# Step 1: Clear all caches
echo "📦 Step 1: Clearing caches and dependencies..."
rm -rf node_modules
rm -rf .vite
rm -rf dist
rm -f package-lock.json
rm -f yarn.lock
rm -f pnpm-lock.yaml
echo "✅ Caches cleared"
echo ""

# Step 2: Install dependencies
echo "📦 Step 2: Installing dependencies..."
if command -v pnpm &> /dev/null; then
    echo "Using pnpm (recommended)..."
    pnpm install
elif command -v yarn &> /dev/null; then
    echo "Using yarn..."
    yarn install
else
    echo "Using npm..."
    npm install
fi
echo "✅ Dependencies installed"
echo ""

# Step 3: Check for duplicate three installations
echo "🔍 Step 3: Checking for duplicate 'three' installations..."
if command -v npm &> /dev/null; then
    npm ls three
fi
echo ""

# Step 4: Force rebuild
echo "🔨 Step 4: Force rebuilding optimized dependencies..."
if command -v pnpm &> /dev/null; then
    pnpm run dev --force &
elif command -v yarn &> /dev/null; then
    yarn dev &
else
    npm run dev &
fi

DEV_PID=$!
echo "✅ Dev server starting (PID: $DEV_PID)"
echo ""

# Wait a few seconds for the server to start
sleep 5

echo "🎉 Fix applied! Check your browser console."
echo ""
echo "If you still see the warning:"
echo "1. Stop the dev server (Ctrl+C)"
echo "2. Clear browser cache and hard reload"
echo "3. Check that only ONE version of 'three' is installed: npm ls three"
echo "4. Try using pnpm instead: npm install -g pnpm && pnpm install"
echo ""
echo "Press Ctrl+C to stop the dev server when done testing."

# Keep script running
wait $DEV_PID
