# Installation Guide

## Quick Start

### 1. Automated Installation (Recommended)

Run the fix script to automatically set up the project:

**On Linux/Mac:**
```bash
chmod +x fix-three-instances.sh
./fix-three-instances.sh
```

**On Windows:**
```bash
fix-three-instances.bat
```

This will:
- ✅ Clear all caches and old dependencies
- ✅ Install fresh dependencies with proper deduplication
- ✅ Check for duplicate Three.js installations
- ✅ Start the dev server

### 2. Manual Installation

If you prefer to install manually:

```bash
# Step 1: Clean install
rm -rf node_modules .vite dist package-lock.json

# Step 2: Install dependencies (pnpm recommended)
pnpm install

# Step 3: Start dev server
pnpm dev
```

Or with npm:
```bash
npm install
npm run dev
```

## Troubleshooting

### "Multiple instances of Three.js" Warning

If you see this warning, it means multiple copies of the Three.js library are being loaded. Here's how to fix it:

#### Solution 1: Use the Fix Script
```bash
./fix-three-instances.sh  # Linux/Mac
fix-three-instances.bat   # Windows
```

#### Solution 2: Use pnpm
pnpm is better at deduplication than npm/yarn:

```bash
npm install -g pnpm
rm -rf node_modules package-lock.json
pnpm install
pnpm dev
```

#### Solution 3: Clear All Caches

```bash
# Clear project caches
rm -rf node_modules .vite dist
rm -f package-lock.json yarn.lock pnpm-lock.yaml

# Clear global caches (optional but recommended)
npm cache clean --force
# or
yarn cache clean
# or
pnpm store prune

# Reinstall
npm install
npm run dev
```

#### Solution 4: Check for Duplicates

```bash
# List all installed versions of 'three'
npm ls three

# You should see only ONE version like:
# └── three@0.160.0

# If you see multiple versions, reinstall:
rm -rf node_modules package-lock.json
npm install
```

### Other Common Issues

#### Port Already in Use

```bash
# Kill process on port 5173 (default Vite port)
# On Linux/Mac:
lsof -ti:5173 | xargs kill -9

# On Windows:
netstat -ano | findstr :5173
taskkill /PID <PID> /F
```

#### TypeScript Errors

```bash
# Clear TypeScript cache
rm -rf node_modules/.vite
npm run dev
```

#### Module Not Found

```bash
# Ensure all dependencies are installed
rm -rf node_modules
npm install

# Check if package.json exists
ls -la package.json
```

## Verification

After installation, verify everything is working:

### 1. Check Browser Console
- Open browser DevTools (F12)
- Look for any warnings or errors
- Should NOT see "Multiple instances of Three.js"

### 2. Check Installed Packages
```bash
npm ls three
# Should show only ONE version
```

### 3. Check Dev Server
```bash
npm run dev
# Should start without warnings
# Should show: "Local: http://localhost:5173/"
```

### 4. Test the Application
- Navigate to http://localhost:5173
- You should see the underwater scene
- Check that sonar scanning works
- Test the YOLOv8 detection
- Verify visualization buttons appear

## Development

### Available Scripts

```bash
# Start dev server (with forced dependency optimization)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Tech Stack

- **React 19** - UI framework
- **Three.js 0.160** - 3D graphics
- **React Three Fiber 8.15** - React renderer for Three.js
- **React Three Drei 9.92** - Three.js helpers
- **Vite 5** - Build tool
- **TypeScript 5** - Type safety
- **Tailwind CSS 4** - Styling

### Project Structure

```
├── App.tsx                          # Main application component
├── main.tsx                         # Entry point
├── components/                      # React components
│   ├── UnderwaterScene.tsx         # 3D scene setup
│   ├── PlayerSubmarine.tsx         # Player submarine
│   ├── SonarPulse.tsx              # Sonar visualization
│   ├── YOLOv8Detector.tsx          # AI detection
│   ├── ThreatVisualizer.tsx        # 3D threat highlighting
│   └── ...                         # Other components
├── styles/
│   └── globals.css                 # Global styles
├── vite.config.ts                  # Vite configuration
├── package.json                    # Dependencies
└── tsconfig.json                   # TypeScript config
```

## Support

### Documentation

- [FIX-THREE-JS-WARNING.md](./FIX-THREE-JS-WARNING.md) - Detailed fix guide
- [README-YOLOV8.md](./README-YOLOV8.md) - YOLOv8 integration docs
- [FEATURES.md](./FEATURES.md) - Feature list
- [QUICK-START.md](./QUICK-START.md) - Quick start guide

### Common Questions

**Q: Why do I see the Three.js warning?**
A: This happens when npm/yarn installs multiple copies of Three.js. Use the fix scripts or pnpm to resolve it.

**Q: Which package manager should I use?**
A: pnpm is recommended as it handles deduplication better than npm/yarn.

**Q: How do I update dependencies?**
A: Update package.json versions, then run `rm -rf node_modules package-lock.json && npm install`

**Q: Is the YOLOv8 model real?**
A: This is a demonstration with simulated detection. For production, integrate a real YOLOv8 backend.

## Next Steps

After successful installation:

1. ✅ Explore the underwater scene
2. ✅ Test sonar scanning (directional and omnidirectional)
3. ✅ Try the YOLOv8 threat detection
4. ✅ Click "Visualize" to see detected threats highlighted
5. ✅ Read [FEATURES.md](./FEATURES.md) for full feature list
6. ✅ Check [README-YOLOV8.md](./README-YOLOV8.md) for AI integration details

## Production Deployment

For deploying to production:

```bash
# Build the app
npm run build

# Preview the build locally
npm run preview

# Deploy the 'dist' folder to your hosting service
# (Vercel, Netlify, GitHub Pages, etc.)
```

The build output will be in the `dist/` directory, ready for deployment.

---

**Need help?** Check the documentation files or review the configuration files for detailed explanations.
