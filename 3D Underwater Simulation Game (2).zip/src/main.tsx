import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/globals.css';
import * as THREE from 'three';

// Ensure only one instance of THREE is used globally
if (typeof window !== 'undefined') {
  (window as any).THREE = THREE;
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
