#!/bin/bash

echo "=================================="
echo "🔧 IMMEDIATE THREE.JS FIX"
echo "=================================="
echo ""

# Step 1: Stop any running processes
echo "Step 1: Stopping dev server if running..."
pkill -f "vite" 2>/dev/null || true
sleep 2

# Step 2: Delete Vite cache (this is the main culprit)
echo "Step 2: Deleting Vite cache..."
rm -rf .vite
rm -rf node_modules/.vite
rm -rf dist

# Step 3: Clear npm cache
echo "Step 3: Clearing npm cache..."
npm cache clean --force 2>/dev/null || true

# Step 4: Delete and reinstall node_modules (nuclear option)
echo "Step 4: Deleting node_modules..."
rm -rf node_modules
rm -f package-lock.json

# Step 5: Fresh install
echo "Step 5: Fresh installation..."
npm install

echo ""
echo "=================================="
echo "✅ FIX COMPLETE!"
echo "=================================="
echo ""
echo "Now run: npm run dev"
echo ""
echo "The warning should be GONE."
echo "If you still see it:"
echo "1. Hard refresh browser (Ctrl+Shift+R)"
echo "2. Check: npm ls three (should show only ONE version)"
echo ""
