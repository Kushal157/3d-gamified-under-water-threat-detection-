import { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface DynamicCameraProps {
  submarinePosition: [number, number, number];
  submarineRotation: number;
}

export function DynamicCamera({ submarinePosition, submarineRotation }: DynamicCameraProps) {
  const { camera } = useThree();
  const targetPosition = useRef(new THREE.Vector3());
  const targetLookAt = useRef(new THREE.Vector3());
  
  useFrame(() => {
    // Camera follows submarine from behind and above
    const offset = new THREE.Vector3(
      Math.sin(submarineRotation) * 40,
      20,
      Math.cos(submarineRotation) * 40
    );
    
    targetPosition.current.set(
      submarinePosition[0] + offset.x,
      submarinePosition[1] + offset.y,
      submarinePosition[2] + offset.z
    );
    
    targetLookAt.current.set(...submarinePosition);
    
    // Smooth camera movement
    camera.position.lerp(targetPosition.current, 0.05);
    
    // Look at submarine
    const currentLookAt = new THREE.Vector3();
    camera.getWorldDirection(currentLookAt);
    currentLookAt.multiplyScalar(10).add(camera.position);
    currentLookAt.lerp(targetLookAt.current, 0.05);
    camera.lookAt(currentLookAt);
  });
  
  return null;
}
