import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function Diver({ position, id }: { position: [number, number, number]; id: number }) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      const time = state.clock.getElapsedTime();
      // Swimming motion
      groupRef.current.position.y = position[1] + Math.sin(time * 0.8 + id) * 0.5;
      groupRef.current.position.x = position[0] + Math.sin(time * 0.3 + id) * 2;
      groupRef.current.rotation.x = Math.sin(time * 0.5 + id) * 0.2;
      groupRef.current.rotation.z = Math.sin(time * 0.4 + id) * 0.1;
      
      // Face direction of movement
      const angle = Math.cos(time * 0.3 + id);
      groupRef.current.rotation.y = angle * 0.3;
    }
  });

  const divingSuitColor = ['#ff6600', '#ffcc00', '#00ccff'][id % 3];

  return (
    <group ref={groupRef} position={position}>
      {/* Body */}
      <mesh castShadow>
        <capsuleGeometry args={[0.25, 0.8, 8, 16]} />
        <meshStandardMaterial 
          color={divingSuitColor}
          roughness={0.4}
          metalness={0.6}
        />
      </mesh>
      
      {/* Head/Helmet */}
      <mesh position={[0, 0.7, 0]} castShadow>
        <sphereGeometry args={[0.22, 16, 16]} />
        <meshStandardMaterial 
          color="#1a1a1a"
          roughness={0.2}
          metalness={0.9}
          transparent
          opacity={0.8}
        />
      </mesh>
      
      {/* Helmet visor */}
      <mesh position={[0, 0.7, 0.15]} castShadow>
        <sphereGeometry args={[0.18, 16, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial 
          color="#006699"
          roughness={0.1}
          metalness={0.5}
          transparent
          opacity={0.6}
        />
      </mesh>
      
      {/* Oxygen tank */}
      <mesh position={[0, 0.2, -0.25]} rotation={[0, 0, 0]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 0.6, 8]} />
        <meshStandardMaterial 
          color="#333333"
          roughness={0.3}
          metalness={0.9}
        />
      </mesh>
      
      {/* Arms */}
      <mesh position={[0.3, 0.2, 0]} rotation={[0, 0, Math.PI / 6]} castShadow>
        <capsuleGeometry args={[0.08, 0.5, 6, 8]} />
        <meshStandardMaterial color={divingSuitColor} roughness={0.4} metalness={0.6} />
      </mesh>
      <mesh position={[-0.3, 0.2, 0]} rotation={[0, 0, -Math.PI / 6]} castShadow>
        <capsuleGeometry args={[0.08, 0.5, 6, 8]} />
        <meshStandardMaterial color={divingSuitColor} roughness={0.4} metalness={0.6} />
      </mesh>
      
      {/* Legs */}
      <mesh position={[0.15, -0.6, 0]} rotation={[0.2, 0, 0]} castShadow>
        <capsuleGeometry args={[0.1, 0.6, 6, 8]} />
        <meshStandardMaterial color={divingSuitColor} roughness={0.4} metalness={0.6} />
      </mesh>
      <mesh position={[-0.15, -0.6, 0]} rotation={[0.2, 0, 0]} castShadow>
        <capsuleGeometry args={[0.1, 0.6, 6, 8]} />
        <meshStandardMaterial color={divingSuitColor} roughness={0.4} metalness={0.6} />
      </mesh>
      
      {/* Fins */}
      <mesh position={[0.15, -1.1, 0]} rotation={[-0.3, 0, 0]} castShadow>
        <boxGeometry args={[0.25, 0.05, 0.4]} />
        <meshStandardMaterial color="#0066aa" roughness={0.3} metalness={0.7} />
      </mesh>
      <mesh position={[-0.15, -1.1, 0]} rotation={[-0.3, 0, 0]} castShadow>
        <boxGeometry args={[0.25, 0.05, 0.4]} />
        <meshStandardMaterial color="#0066aa" roughness={0.3} metalness={0.7} />
      </mesh>
      
      {/* Flashlight */}
      <pointLight position={[0, 0.7, 0.3]} intensity={1.5} color="#ffffff" distance={8} />
      
      {/* Bubble trail */}
      {Array.from({ length: 3 }).map((_, i) => (
        <mesh 
          key={i}
          position={[0, 0.7 + i * 0.3, -0.2]}
        >
          <sphereGeometry args={[0.05 + i * 0.02, 8, 8]} />
          <meshStandardMaterial 
            color="#aaddff"
            transparent
            opacity={0.4 - i * 0.1}
            roughness={0.1}
          />
        </mesh>
      ))}
    </group>
  );
}

export function Divers() {
  const diverPositions: [number, number, number][] = [
    [15, -3, -20],
    [-20, -5, -15],
    [30, -4, 25],
    [-25, -6, 30],
    [10, -4, -30],
    [-15, -5, 20],
  ];

  return (
    <group>
      {diverPositions.map((pos, i) => (
        <Diver key={i} position={pos} id={i} />
      ))}
    </group>
  );
}
