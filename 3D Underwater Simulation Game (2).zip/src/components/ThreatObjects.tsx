import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface Threat {
  id: number;
  position: [number, number, number];
  type: string;
  threat: number;
}

interface ThreatObjectsProps {
  threats: Threat[];
  isScanning: boolean;
  detectionRange: number;
}

function ThreatObject({ threat, isScanning, detectionRange }: { threat: Threat; isScanning: boolean; detectionRange: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  
  const distance = Math.sqrt(threat.position[0] ** 2 + threat.position[2] ** 2);
  const isDetected = isScanning && distance <= detectionRange;

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005;
      meshRef.current.position.y += Math.sin(state.clock.getElapsedTime() + threat.id) * 0.003;
    }
    
    if (glowRef.current && isDetected) {
      glowRef.current.scale.setScalar(1 + Math.sin(state.clock.getElapsedTime() * 2) * 0.2);
    }
  });

  const getThreatColor = (type: string) => {
    switch (type) {
      case 'submarine': return '#ff3333';
      case 'mine': return '#ff6633';
      case 'torpedo': return '#ff0000';
      case 'drone': return '#ffaa33';
      default: return '#ffff33';
    }
  };

  const getThreatGeometry = (type: string) => {
    switch (type) {
      case 'submarine':
        return <capsuleGeometry args={[0.5, 2, 4, 8]} />;
      case 'mine':
        return <icosahedronGeometry args={[0.8, 0]} />;
      case 'torpedo':
        return <cylinderGeometry args={[0.3, 0.3, 2, 8]} />;
      case 'drone':
        return <octahedronGeometry args={[0.7, 0]} />;
      default:
        return <boxGeometry args={[1, 1, 1]} />;
    }
  };

  return (
    <group position={threat.position}>
      {/* Main threat object */}
      <mesh ref={meshRef} castShadow receiveShadow>
        {getThreatGeometry(threat.type)}
        <meshStandardMaterial 
          color={getThreatColor(threat.type)}
          emissive={getThreatColor(threat.type)}
          emissiveIntensity={isDetected ? 0.5 : 0.1}
          roughness={0.3}
          metalness={0.7}
        />
      </mesh>
      
      {/* Detection glow */}
      {isDetected && (
        <mesh ref={glowRef}>
          <sphereGeometry args={[2, 16, 16]} />
          <meshBasicMaterial 
            color={getThreatColor(threat.type)}
            transparent
            opacity={0.2}
            side={THREE.BackSide}
          />
        </mesh>
      )}
      
      {/* Warning marker */}
      {isDetected && (
        <mesh position={[0, 3, 0]}>
          <coneGeometry args={[0.3, 0.8, 3]} />
          <meshBasicMaterial 
            color="#ff0000"
            transparent
            opacity={0.8}
          />
        </mesh>
      )}
    </group>
  );
}

export function ThreatObjects({ threats, isScanning, detectionRange }: ThreatObjectsProps) {
  return (
    <group>
      {threats.map(threat => (
        <ThreatObject 
          key={threat.id}
          threat={threat}
          isScanning={isScanning}
          detectionRange={detectionRange}
        />
      ))}
    </group>
  );
}
