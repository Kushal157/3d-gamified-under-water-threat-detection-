import { useEffect } from 'react';

export interface SubmarineMovement {
  position: [number, number, number];
  rotation: number;
  velocity: [number, number, number];
}

interface SubmarineControllerProps {
  onMove: (movement: SubmarineMovement) => void;
  movement: SubmarineMovement;
}

export function SubmarineController({ onMove, movement }: SubmarineControllerProps) {
  useEffect(() => {
    const keys: { [key: string]: boolean } = {};
    
    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.key] = true;
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.key] = false;
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    // Movement update loop
    const interval = setInterval(() => {
      const speed = 0.5;
      const rotationSpeed = 0.05;
      let newVelocity: [number, number, number] = [0, 0, 0];
      let newRotation = movement.rotation;
      let verticalChange = 0;
      
      // Keyboard controls
      if (keys['ArrowUp'] || keys['w'] || keys['W']) {
        // Move forward in current direction
        newVelocity[0] = -Math.sin(movement.rotation) * speed;
        newVelocity[2] = -Math.cos(movement.rotation) * speed;
      }
      if (keys['ArrowDown'] || keys['s'] || keys['S']) {
        // Move backward
        newVelocity[0] = Math.sin(movement.rotation) * speed * 0.5;
        newVelocity[2] = Math.cos(movement.rotation) * speed * 0.5;
      }
      if (keys['ArrowLeft'] || keys['a'] || keys['A']) {
        // Rotate left
        newRotation -= rotationSpeed;
      }
      if (keys['ArrowRight'] || keys['d'] || keys['D']) {
        // Rotate right
        newRotation += rotationSpeed;
      }
      if (keys['q'] || keys['Q']) {
        // Ascend
        verticalChange = 0.3;
      }
      if (keys['e'] || keys['E']) {
        // Descend
        verticalChange = -0.3;
      }
      
      // Apply movement if there's any input
      if (newVelocity[0] !== 0 || newVelocity[2] !== 0 || verticalChange !== 0 || newRotation !== movement.rotation) {
        const newPosition: [number, number, number] = [
          movement.position[0] + newVelocity[0],
          Math.max(-35, Math.min(-5, movement.position[1] + verticalChange)),
          movement.position[2] + newVelocity[2]
        ];
        
        // Clamp position to playable area
        newPosition[0] = Math.max(-100, Math.min(100, newPosition[0]));
        newPosition[2] = Math.max(-100, Math.min(100, newPosition[2]));
        
        onMove({
          position: newPosition,
          rotation: newRotation,
          velocity: newVelocity
        });
      }
    }, 1000 / 60); // 60 FPS
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      clearInterval(interval);
    };
  }, [movement, onMove]);
  
  return null; // This is a controller component, no UI
}