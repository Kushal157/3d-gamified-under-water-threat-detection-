import { Card } from './ui/card';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Gauge, 
  Compass, 
  Waves, 
  Radio, 
  AlertTriangle,
  Navigation,
  Radar
} from 'lucide-react';

interface GameHUDProps {
  depth: number;
  speed: number;
  heading: number;
  sonarRange: number;
  isScanning: boolean;
  onScan: () => void;
  onSonarRangeChange: (value: number) => void;
  threatCount: number;
}

export function GameHUD({
  depth,
  speed,
  heading,
  sonarRange,
  isScanning,
  onScan,
  onSonarRangeChange,
  threatCount,
}: GameHUDProps) {
  const getDepthColor = () => {
    if (depth < 5) return 'text-yellow-400';
    if (depth < 15) return 'text-green-400';
    if (depth < 25) return 'text-cyan-400';
    return 'text-blue-400';
  };

  const getSpeedColor = () => {
    if (speed < 10) return 'text-slate-400';
    if (speed < 30) return 'text-green-400';
    return 'text-yellow-400';
  };

  return (
    <div className="absolute inset-x-0 top-0 p-6 pointer-events-none">
      <div className="max-w-7xl mx-auto">
        {/* Top Bar */}
        <div className="flex items-start justify-between gap-4 mb-4">
          {/* Left: System Info */}
          <Card className="bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-4 pointer-events-auto">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-cyan-500/20 rounded-lg">
                <Waves className="w-5 h-5 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-white">SSN-774 Virginia</h2>
                <p className="text-slate-400 text-xs">Attack Submarine</p>
              </div>
              <Badge className="ml-2 bg-green-500/20 text-green-400 border-green-500/30">
                ACTIVE
              </Badge>
            </div>
          </Card>

          {/* Center: Main Instruments */}
          <div className="flex gap-3">
            {/* Depth Gauge */}
            <Card className="bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-4 pointer-events-auto min-w-[140px]">
              <div className="flex items-center gap-2 mb-2">
                <Waves className={`w-4 h-4 ${getDepthColor()}`} />
                <span className="text-slate-400 text-xs">DEPTH</span>
              </div>
              <div className={`text-3xl ${getDepthColor()} mb-1`}>
                {depth.toFixed(1)}
              </div>
              <div className="text-slate-500 text-xs">meters</div>
              <Progress value={(depth / 32) * 100} className="mt-2 h-1" />
            </Card>

            {/* Speed Gauge */}
            <Card className="bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-4 pointer-events-auto min-w-[140px]">
              <div className="flex items-center gap-2 mb-2">
                <Gauge className={`w-4 h-4 ${getSpeedColor()}`} />
                <span className="text-slate-400 text-xs">SPEED</span>
              </div>
              <div className={`text-3xl ${getSpeedColor()} mb-1`}>
                {speed.toFixed(1)}
              </div>
              <div className="text-slate-500 text-xs">knots</div>
              <Progress value={speed} className="mt-2 h-1" />
            </Card>

            {/* Heading Compass */}
            <Card className="bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-4 pointer-events-auto min-w-[140px]">
              <div className="flex items-center gap-2 mb-2">
                <Compass className="w-4 h-4 text-purple-400" />
                <span className="text-slate-400 text-xs">HEADING</span>
              </div>
              <div className="text-3xl text-purple-400 mb-1">
                {heading.toFixed(0)}°
              </div>
              <div className="text-slate-500 text-xs">
                {getCardinalDirection(heading)}
              </div>
              <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-purple-500 transition-all"
                  style={{ width: `${(heading / 360) * 100}%` }}
                />
              </div>
            </Card>
          </div>

          {/* Right: Threat Alert */}
          {threatCount > 0 && (
            <Card className="bg-red-900/40 border-red-500/50 backdrop-blur-md p-4 pointer-events-auto">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-6 h-6 text-red-400 animate-pulse" />
                <div>
                  <div className="text-red-400">{threatCount} Threats</div>
                  <div className="text-red-300 text-xs">In Range</div>
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Sonar Control */}
        <div className="flex justify-center">
          <Card className="bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-4 pointer-events-auto">
            <div className="flex items-center gap-6">
              {/* Sonar Button */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Radar className="w-4 h-4 text-cyan-400" />
                  <span className="text-slate-300 text-sm">Active Sonar</span>
                </div>
                <Button 
                  onClick={onScan}
                  disabled={isScanning}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white px-6"
                  size="lg"
                >
                  <Radio className="w-4 h-4 mr-2" />
                  {isScanning ? 'Scanning...' : 'PING'}
                </Button>
              </div>

              {/* Range Control */}
              <div className="min-w-[250px]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-300 text-sm">Detection Range</span>
                  <span className="text-cyan-400">{sonarRange}m</span>
                </div>
                <Slider
                  value={[sonarRange]}
                  onValueChange={([value]) => onSonarRangeChange(value)}
                  min={30}
                  max={100}
                  step={10}
                  className="w-full"
                  disabled={isScanning}
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>Close</span>
                  <span>Far</span>
                </div>
              </div>

              {/* Status */}
              <div className="pl-6 border-l border-slate-700">
                <div className="text-slate-400 text-xs mb-1">Status</div>
                <Badge 
                  variant={isScanning ? "default" : "secondary"}
                  className={isScanning ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-slate-700 text-slate-400"}
                >
                  {isScanning ? 'ACTIVE' : 'STANDBY'}
                </Badge>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function getCardinalDirection(heading: number): string {
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const index = Math.round(heading / 45) % 8;
  return directions[index];
}
