import { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface SonarPulseProps {
  isActive: boolean;
  range: number;
  direction: 'north' | 'south' | 'east' | 'west' | 'all';
}

export function SonarPulse({ isActive, range, direction }: SonarPulseProps) {
  const groupRef = useRef<THREE.Group>(null);
  const [pulses, setPulses] = useState<Array<{ id: number; scale: number }>>([]);
  const pulseInterval = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (isActive) {
      let pulseId = 0;
      pulseInterval.current = setInterval(() => {
        setPulses(prev => [...prev, { id: pulseId++, scale: 0 }]);
      }, 400);
    } else {
      if (pulseInterval.current) {
        clearInterval(pulseInterval.current);
      }
    }

    return () => {
      if (pulseInterval.current) {
        clearInterval(pulseInterval.current);
      }
    };
  }, [isActive]);

  useFrame(() => {
    setPulses(prev => 
      prev
        .map(pulse => ({ ...pulse, scale: pulse.scale + 0.6 }))
        .filter(pulse => pulse.scale < range)
    );
  });

  const getDirectionAngle = () => {
    switch (direction) {
      case 'north': return 0;
      case 'east': return Math.PI / 2;
      case 'south': return Math.PI;
      case 'west': return -Math.PI / 2;
      default: return 0;
    }
  };

  const getScanAngle = () => {
    return direction === 'all' ? Math.PI * 2 : Math.PI / 3; // 60 degrees for directional
  };

  return (
    <group ref={groupRef} position={[0, -8, 0]}>
      {pulses.map(pulse => (
        <group key={pulse.id}>
          {direction === 'all' ? (
            // Full 360-degree scan
            <>
              <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
                <ringGeometry args={[Math.max(0, pulse.scale - 1), pulse.scale, 64]} />
                <meshBasicMaterial 
                  color="#00ffff"
                  transparent
                  opacity={Math.max(0, 0.8 - pulse.scale / range)}
                  side={THREE.DoubleSide}
                />
              </mesh>
            </>
          ) : (
            // Directional cone scan
            <>
              {/* Horizontal cone */}
              <mesh 
                rotation={[-Math.PI / 2, 0, getDirectionAngle()]} 
                position={[0, 0, 0]}
              >
                <ringGeometry 
                  args={[
                    Math.max(0, pulse.scale - 1), 
                    pulse.scale, 
                    32,
                    1,
                    getDirectionAngle() - getScanAngle() / 2,
                    getScanAngle()
                  ]} 
                />
                <meshBasicMaterial 
                  color="#00ffff"
                  transparent
                  opacity={Math.max(0, 0.9 - pulse.scale / range)}
                  side={THREE.DoubleSide}
                />
              </mesh>
              
              {/* Cone edges */}
              <mesh
                rotation={[-Math.PI / 2, 0, getDirectionAngle() - getScanAngle() / 2]}
                position={[0, 0, 0]}
              >
                <planeGeometry args={[pulse.scale, 0.1]} />
                <meshBasicMaterial 
                  color="#00ffff"
                  transparent
                  opacity={Math.max(0, 0.6 - pulse.scale / range)}
                />
              </mesh>
              <mesh
                rotation={[-Math.PI / 2, 0, getDirectionAngle() + getScanAngle() / 2]}
                position={[0, 0, 0]}
              >
                <planeGeometry args={[pulse.scale, 0.1]} />
                <meshBasicMaterial 
                  color="#00ffff"
                  transparent
                  opacity={Math.max(0, 0.6 - pulse.scale / range)}
                />
              </mesh>
            </>
          )}
        </group>
      ))}
      
      {/* Central sonar emitter */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshStandardMaterial 
          color="#00ffff"
          emissive="#00ffff"
          emissiveIntensity={isActive ? 2 : 0.5}
          transparent
          opacity={0.6}
        />
      </mesh>
      
      {/* Direction indicator */}
      {direction !== 'all' && (
        <mesh 
          rotation={[-Math.PI / 2, 0, getDirectionAngle()]} 
          position={[0, 0.1, 0]}
        >
          <coneGeometry args={[1, 2, 3]} />
          <meshBasicMaterial 
            color="#00ffff"
            transparent
            opacity={0.3}
            wireframe
          />
        </mesh>
      )}
      
      {/* Sonar grid */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]}>
        <ringGeometry args={[0, range, 64, 8]} />
        <meshBasicMaterial 
          color="#00ffff"
          transparent
          opacity={0.05}
          wireframe
        />
      </mesh>
      
      {/* Pulsing light */}
      <pointLight 
        color="#00ffff" 
        intensity={isActive ? 5 : 1} 
        distance={range * 0.8} 
        decay={2}
      />
    </group>
  );
}
