import { Card } from './ui/card';
import { Keyboard } from 'lucide-react';

export function Controls() {
  return (
    <div className="absolute left-6 bottom-6 pointer-events-auto">
      <Card className="bg-slate-900/90 border-cyan-500/30 backdrop-blur-sm p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="p-2 bg-cyan-500/20 rounded-lg">
            <Keyboard className="w-4 h-4 text-cyan-400" />
          </div>
          <h3 className="text-white">Controls</h3>
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">W</kbd>
              <span className="text-slate-400">Forward</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">S</kbd>
              <span className="text-slate-400">Backward</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">A</kbd>
              <span className="text-slate-400">Turn Left</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">D</kbd>
              <span className="text-slate-400">Turn Right</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">Space</kbd>
              <span className="text-slate-400">Surface</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">Shift</kbd>
              <span className="text-slate-400">Dive</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">Q</kbd>
              <span className="text-slate-400">Pitch Up</span>
            </div>
            <div className="flex items-center gap-2">
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs">E</kbd>
              <span className="text-slate-400">Pitch Down</span>
            </div>
          </div>
          
          <div className="pt-2 border-t border-slate-800">
            <p className="text-slate-500 text-xs">
              Move mouse to adjust camera angle
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
