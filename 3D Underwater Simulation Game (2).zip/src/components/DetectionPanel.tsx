import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { AlertTriangle, Target, TrendingUp, Eye, EyeOff } from 'lucide-react';

interface Threat {
  id: number;
  type: string;
  distance: string;
  confidence: string;
}

interface DetectionPanelProps {
  threats: Threat[];
  isScanning: boolean;
  isVisualizationActive: boolean;
  onToggleVisualization: () => void;
}

export function DetectionPanel({ 
  threats, 
  isScanning, 
  isVisualizationActive,
  onToggleVisualization 
}: DetectionPanelProps) {
  const getThreatColor = (type: string) => {
    switch (type) {
      case 'submarine': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'mine': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'torpedo': return 'bg-red-600/20 text-red-300 border-red-600/30';
      case 'drone': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    }
  };

  const getThreatIcon = (type: string) => {
    return <Target className="w-4 h-4" />;
  };

  return (
    <Card className="w-full max-w-5xl bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-6">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-500/20 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <h2 className="text-white">Threat Detection</h2>
              <p className="text-slate-400 text-sm">YOLOv8 AI-Powered Analysis</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {threats.length > 0 && (
              <>
                <Button
                  onClick={onToggleVisualization}
                  size="sm"
                  className={`${
                    isVisualizationActive
                      ? 'bg-green-600 hover:bg-green-700'
                      : 'bg-cyan-600 hover:bg-cyan-700'
                  } text-white`}
                >
                  {isVisualizationActive ? (
                    <>
                      <EyeOff className="w-4 h-4 mr-2" />
                      Hide Visualization
                    </>
                  ) : (
                    <>
                      <Eye className="w-4 h-4 mr-2" />
                      Visualize Threats
                    </>
                  )}
                </Button>
                <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                  {threats.length} Detected
                </Badge>
              </>
            )}
          </div>
        </div>

        {/* Threats Grid */}
        <div className="max-h-80 overflow-y-auto">
          {threats.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-flex p-4 bg-slate-800/50 rounded-full mb-3">
                <Target className="w-8 h-8 text-slate-600" />
              </div>
              <p className="text-slate-500">
                {isScanning ? 'Analyzing...' : 'No threats detected'}
              </p>
              <p className="text-slate-600 text-sm mt-1">
                Use Sonar Control to initiate a scan
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {threats.map((threat) => (
                <Card 
                  key={threat.id}
                  className={`p-4 ${getThreatColor(threat.type)} border`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        {getThreatIcon(threat.type)}
                        <div>
                          <h3 className="capitalize">{threat.type}</h3>
                          <p className="text-xs opacity-70">ID: {threat.id}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="border-current text-xs">
                        ACTIVE
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="opacity-70 text-xs">Distance</p>
                        <p className="">{threat.distance}m</p>
                      </div>
                      <div>
                        <p className="opacity-70 text-xs">Confidence</p>
                        <div className="flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          <p className="">{threat.confidence}%</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="pt-2 border-t border-current/20">
                      <p className="text-xs opacity-70">
                        Threat Level: <span className="">HIGH</span>
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Footer Stats */}
        {threats.length > 0 && (
          <div className="pt-4 border-t border-slate-800 grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl text-cyan-400">{threats.length}</p>
              <p className="text-xs text-slate-500">Total</p>
            </div>
            <div>
              <p className="text-2xl text-red-400">
                {threats.filter(t => t.type === 'submarine' || t.type === 'torpedo').length}
              </p>
              <p className="text-xs text-slate-500">Critical</p>
            </div>
            <div>
              <p className="text-2xl text-green-400">
                {Math.round(threats.reduce((sum, t) => sum + parseFloat(t.confidence), 0) / threats.length)}%
              </p>
              <p className="text-xs text-slate-500">Avg Confidence</p>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
