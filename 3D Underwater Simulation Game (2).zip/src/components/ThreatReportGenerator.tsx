import { Button } from './ui/button';
import { FileText, Download } from 'lucide-react';
import jsPDF from 'jspdf';

interface ThreatReportGeneratorProps {
  threats: any[];
  submarinePosition: [number, number, number];
  scanDirection: string;
  detectionRange: number;
  aiSensitivity: number;
  onGenerate?: () => void;
}

export function ThreatReportGenerator({
  threats,
  submarinePosition,
  scanDirection,
  detectionRange,
  aiSensitivity,
  onGenerate
}: ThreatReportGeneratorProps) {
  
  const generatePDFReport = () => {
    const doc = new jsPDF();
    const timestamp = new Date().toLocaleString();
    
    // Header
    doc.setFillColor(0, 150, 200);
    doc.rect(0, 0, 210, 40, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text('THREAT DETECTION REPORT', 105, 20, { align: 'center' });
    doc.setFontSize(12);
    doc.text('Indian Navy - INS Vagir (S5)', 105, 30, { align: 'center' });
    
    // Reset text color
    doc.setTextColor(0, 0, 0);
    
    // Classification Banner
    doc.setFillColor(255, 0, 0);
    doc.rect(0, 40, 210, 10, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(10);
    doc.text('CLASSIFIED - FOR OFFICIAL USE ONLY', 105, 46, { align: 'center' });
    doc.setTextColor(0, 0, 0);
    
    // Timestamp and coordinates
    let yPos = 60;
    doc.setFontSize(11);
    doc.text(`Report Generated: ${timestamp}`, 20, yPos);
    yPos += 8;
    doc.text(`Submarine Coordinates:`, 20, yPos);
    yPos += 6;
    doc.setFontSize(10);
    doc.text(`  X: ${submarinePosition[0].toFixed(2)}m`, 20, yPos);
    yPos += 5;
    doc.text(`  Y: ${submarinePosition[1].toFixed(2)}m (Depth)`, 20, yPos);
    yPos += 5;
    doc.text(`  Z: ${submarinePosition[2].toFixed(2)}m`, 20, yPos);
    yPos += 10;
    
    // Scan Parameters
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Scan Parameters', 20, yPos);
    doc.setFont('helvetica', 'normal');
    yPos += 8;
    doc.setFontSize(10);
    doc.text(`Scan Direction: ${scanDirection.toUpperCase()}`, 20, yPos);
    yPos += 5;
    doc.text(`Detection Range: ${detectionRange}m`, 20, yPos);
    yPos += 5;
    doc.text(`AI Sensitivity: ${(aiSensitivity * 100).toFixed(0)}%`, 20, yPos);
    yPos += 5;
    doc.text(`AI Model: YOLOv8-Sonar (Naval Variant)`, 20, yPos);
    yPos += 12;
    
    // Threat Summary
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Threat Summary', 20, yPos);
    doc.setFont('helvetica', 'normal');
    yPos += 8;
    doc.setFontSize(10);
    doc.text(`Total Threats Detected: ${threats.length}`, 20, yPos);
    yPos += 8;
    
    // Threat Level Distribution
    const threatLevels = {
      critical: threats.filter(t => t.threatLevel === 'critical').length,
      high: threats.filter(t => t.threatLevel === 'high').length,
      medium: threats.filter(t => t.threatLevel === 'medium').length,
      low: threats.filter(t => t.threatLevel === 'low').length
    };
    
    doc.setTextColor(200, 0, 0);
    doc.text(`  Critical: ${threatLevels.critical}`, 25, yPos);
    yPos += 5;
    doc.setTextColor(255, 100, 0);
    doc.text(`  High: ${threatLevels.high}`, 25, yPos);
    yPos += 5;
    doc.setTextColor(255, 180, 0);
    doc.text(`  Medium: ${threatLevels.medium}`, 25, yPos);
    yPos += 5;
    doc.setTextColor(100, 150, 100);
    doc.text(`  Low: ${threatLevels.low}`, 25, yPos);
    doc.setTextColor(0, 0, 0);
    yPos += 12;
    
    // Detailed Threat List
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Detected Threats', 20, yPos);
    doc.setFont('helvetica', 'normal');
    yPos += 8;
    
    if (threats.length === 0) {
      doc.setFontSize(10);
      doc.text('No threats detected in scan area.', 20, yPos);
    } else {
      threats.forEach((threat, index) => {
        // Check if we need a new page
        if (yPos > 260) {
          doc.addPage();
          yPos = 20;
        }
        
        // Threat box
        doc.setFillColor(240, 240, 240);
        doc.rect(15, yPos - 5, 180, 28, 'F');
        doc.setDrawColor(0, 150, 200);
        doc.rect(15, yPos - 5, 180, 28);
        
        doc.setFontSize(11);
        doc.setFont('helvetica', 'bold');
        doc.text(`Threat #${index + 1}: ${threat.type.toUpperCase()}`, 20, yPos);
        doc.setFont('helvetica', 'normal');
        yPos += 6;
        
        doc.setFontSize(9);
        doc.text(`Distance: ${threat.distance}m`, 20, yPos);
        doc.text(`Confidence: ${threat.confidence}%`, 80, yPos);
        
        // Threat level with color
        const levelColors: any = {
          critical: [200, 0, 0],
          high: [255, 100, 0],
          medium: [255, 180, 0],
          low: [100, 150, 100]
        };
        const color = levelColors[threat.threatLevel] || [0, 0, 0];
        doc.setTextColor(...color);
        doc.text(`Level: ${threat.threatLevel.toUpperCase()}`, 140, yPos);
        doc.setTextColor(0, 0, 0);
        yPos += 5;
        
        doc.text(`Position: [${threat.position[0].toFixed(1)}, ${threat.position[1].toFixed(1)}, ${threat.position[2].toFixed(1)}]`, 20, yPos);
        yPos += 5;
        
        if (threat.bbox) {
          doc.text(`Bounding Box: [${threat.bbox.map((b: number) => b.toFixed(0)).join(', ')}]`, 20, yPos);
        }
        yPos += 10;
      });
    }
    
    // Add new page for recommendations
    doc.addPage();
    yPos = 20;
    
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Recommended Actions', 20, yPos);
    doc.setFont('helvetica', 'normal');
    yPos += 10;
    doc.setFontSize(10);
    
    if (threatLevels.critical > 0) {
      doc.setTextColor(200, 0, 0);
      doc.text('⚠ CRITICAL THREATS DETECTED', 20, yPos);
      doc.setTextColor(0, 0, 0);
      yPos += 6;
      doc.text('• Initiate evasive maneuvers immediately', 25, yPos);
      yPos += 5;
      doc.text('• Alert command center', 25, yPos);
      yPos += 5;
      doc.text('• Prepare countermeasures', 25, yPos);
      yPos += 8;
    }
    
    if (threatLevels.high > 0) {
      doc.text('High Priority Threats:', 20, yPos);
      yPos += 6;
      doc.text('• Maintain heightened alert status', 25, yPos);
      yPos += 5;
      doc.text('• Monitor threat movements closely', 25, yPos);
      yPos += 5;
      doc.text('• Update tactical situation report', 25, yPos);
      yPos += 8;
    }
    
    doc.text('General Recommendations:', 20, yPos);
    yPos += 6;
    doc.text('• Continue periodic sonar sweeps', 25, yPos);
    yPos += 5;
    doc.text('• Maintain stealth protocols', 25, yPos);
    yPos += 5;
    doc.text('• Update navigation based on threat positions', 25, yPos);
    yPos += 5;
    doc.text('• Share intelligence with fleet command', 25, yPos);
    
    // Footer on last page
    yPos = 280;
    doc.setFillColor(0, 150, 200);
    doc.rect(0, yPos, 210, 17, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.text('Generated by YOLOv8 Sonar AI Detection System | Indian Navy', 105, yPos + 6, { align: 'center' });
    doc.text(`Report ID: ${Date.now().toString(36).toUpperCase()}`, 105, yPos + 11, { align: 'center' });
    
    // Save the PDF
    doc.save(`Threat_Report_${Date.now()}.pdf`);
    
    if (onGenerate) {
      onGenerate();
    }
  };
  
  return (
    <Button
      onClick={generatePDFReport}
      disabled={threats.length === 0}
      size="lg"
      className="bg-purple-600 hover:bg-purple-700 text-white px-6"
    >
      <FileText className="w-5 h-5 mr-2" />
      Generate PDF Report
      <Download className="w-4 h-4 ml-2" />
    </Button>
  );
}
