import { MapPin, AlertTriangle, Shield } from 'lucide-react';
import { Badge } from './ui/badge';
import type { EnvironmentZone } from './DynamicEnvironmentManager';

interface EnvironmentZoneIndicatorProps {
  zone: EnvironmentZone;
  submarinePosition: [number, number, number];
}

export function EnvironmentZoneIndicator({ zone, submarinePosition }: EnvironmentZoneIndicatorProps) {
  const getZoneColor = () => {
    switch (zone.threatDensity) {
      case 'high':
        return 'border-red-500/40 bg-red-500/10';
      case 'medium':
        return 'border-yellow-500/40 bg-yellow-500/10';
      case 'low':
        return 'border-green-500/40 bg-green-500/10';
    }
  };

  const getZoneIcon = () => {
    switch (zone.threatDensity) {
      case 'high':
        return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'medium':
        return <MapPin className="w-4 h-4 text-yellow-400" />;
      case 'low':
        return <Shield className="w-4 h-4 text-green-400" />;
    }
  };

  const getZoneBadgeColor = () => {
    switch (zone.threatDensity) {
      case 'high':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'medium':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'low':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
    }
  };

  return (
    <div className={`border backdrop-blur-md rounded-lg p-4 ${getZoneColor()}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {getZoneIcon()}
          <span className="text-white">{zone.name}</span>
        </div>
        <Badge className={getZoneBadgeColor()}>
          {zone.threatDensity.toUpperCase()}
        </Badge>
      </div>
      
      <p className="text-slate-300 text-sm mb-3">{zone.description}</p>
      
      <div className="space-y-1">
        <div className="flex justify-between text-xs">
          <span className="text-slate-400">Position X:</span>
          <span className="text-cyan-400">{submarinePosition[0].toFixed(1)}m</span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-slate-400">Depth Y:</span>
          <span className="text-cyan-400">{submarinePosition[1].toFixed(1)}m</span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-slate-400">Position Z:</span>
          <span className="text-cyan-400">{submarinePosition[2].toFixed(1)}m</span>
        </div>
      </div>
    </div>
  );
}
