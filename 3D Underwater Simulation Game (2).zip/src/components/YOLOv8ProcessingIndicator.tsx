import { Card } from './ui/card';
import { Brain, Cpu, Zap } from 'lucide-react';

interface YOLOv8ProcessingIndicatorProps {
  isProcessing: boolean;
}

export function YOLOv8ProcessingIndicator({ isProcessing }: YOLOv8ProcessingIndicatorProps) {
  if (!isProcessing) return null;

  return (
    <div className="absolute top-24 left-6 pointer-events-none">
      <Card className="bg-purple-900/30 border-purple-500/40 backdrop-blur-md p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Brain className="w-6 h-6 text-purple-400 animate-pulse" />
            <div className="absolute -top-1 -right-1">
              <Zap className="w-3 h-3 text-yellow-400 animate-ping" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Cpu className="w-4 h-4 text-purple-300" />
              <span className="text-purple-200 text-sm">YOLOv8 Processing</span>
            </div>
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
          <div className="ml-2 text-purple-300 text-xs">
            Analyzing...
          </div>
        </div>
      </Card>
    </div>
  );
}
