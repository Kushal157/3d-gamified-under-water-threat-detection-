import { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface CameraControllerProps {
  submarinePosition: { x: number; y: number; z: number };
}

export function CameraController({ submarinePosition }: CameraControllerProps) {
  const { camera } = useThree();
  const targetPosition = useRef(new THREE.Vector3(0, 10, 30));
  const currentPosition = useRef(new THREE.Vector3(0, 10, 30));
  const lookAtTarget = useRef(new THREE.Vector3(0, -8, 0));
  const currentLookAt = useRef(new THREE.Vector3(0, -8, 0));
  
  const mouseX = useRef(0);
  const mouseY = useRef(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.current = (e.clientX / window.innerWidth) * 2 - 1;
      mouseY.current = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useFrame(() => {
    // Camera follows submarine with offset
    const offset = new THREE.Vector3(
      15 + mouseX.current * 10,
      12 + mouseY.current * 5,
      25
    );
    
    targetPosition.current.set(
      submarinePosition.x + offset.x,
      submarinePosition.y + offset.y,
      submarinePosition.z + offset.z
    );

    // Smooth camera movement
    currentPosition.current.lerp(targetPosition.current, 0.05);
    camera.position.copy(currentPosition.current);

    // Look at submarine
    lookAtTarget.current.set(
      submarinePosition.x,
      submarinePosition.y,
      submarinePosition.z
    );
    
    currentLookAt.current.lerp(lookAtTarget.current, 0.08);
    camera.lookAt(currentLookAt.current);
  });

  return null;
}
