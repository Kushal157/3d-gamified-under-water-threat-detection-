import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface SubmarineWaterEffectsProps {
  position: [number, number, number];
  velocity?: [number, number, number];
  rotation: number;
}

export function SubmarineWaterEffects({ position, velocity = [0, 0, 0], rotation }: SubmarineWaterEffectsProps) {
  const bubblesRef = useRef<THREE.Group>(null);
  const trailRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    // Animate bubbles rising
    if (bubblesRef.current) {
      bubblesRef.current.children.forEach((bubble, i) => {
        bubble.position.y += 0.05 + Math.random() * 0.03;
        bubble.position.x += Math.sin(state.clock.elapsedTime + i) * 0.02;
        
        // Reset bubble if it goes too high
        if (bubble.position.y > 5) {
          bubble.position.y = -2;
        }
      });
    }
    
    // Update trail opacity based on velocity
    if (trailRef.current) {
      const speed = Math.sqrt(velocity[0] ** 2 + velocity[2] ** 2);
      trailRef.current.children.forEach((trail) => {
        const material = (trail as THREE.Mesh).material as THREE.MeshBasicMaterial;
        material.opacity = THREE.MathUtils.lerp(material.opacity, speed * 0.3, 0.1);
      });
    }
  });
  
  // Calculate if submarine is moving
  const isMoving = velocity[0] !== 0 || velocity[2] !== 0;
  const speed = Math.sqrt(velocity[0] ** 2 + velocity[2] ** 2);
  
  // Calculate bubble spawn position (behind submarine)
  const bubbleSpawnX = position[0] + Math.sin(rotation) * 12;
  const bubbleSpawnZ = position[2] + Math.cos(rotation) * 12;
  
  return (
    <group>
      {/* Propeller Bubbles */}
      {isMoving && (
        <group ref={bubblesRef} position={[bubbleSpawnX, position[1], bubbleSpawnZ]}>
          {Array.from({ length: 20 }).map((_, i) => (
            <mesh
              key={i}
              position={[
                (Math.random() - 0.5) * 2,
                (Math.random() - 0.5) * 3 - 2,
                (Math.random() - 0.5) * 2
              ]}
            >
              <sphereGeometry args={[0.1 + Math.random() * 0.15, 8, 8]} />
              <meshBasicMaterial
                color="#ffffff"
                transparent
                opacity={0.4 + Math.random() * 0.3}
              />
            </mesh>
          ))}
        </group>
      )}
      
      {/* Motion Trail */}
      {isMoving && (
        <group ref={trailRef}>
          {Array.from({ length: 5 }).map((_, i) => {
            const offset = (i + 1) * 3;
            const trailX = position[0] + Math.sin(rotation) * offset;
            const trailZ = position[2] + Math.cos(rotation) * offset;
            
            return (
              <mesh
                key={i}
                position={[trailX, position[1], trailZ]}
                rotation={[0, rotation, 0]}
              >
                <cylinderGeometry args={[1.5 - i * 0.2, 1.8 - i * 0.2, 0.5, 16]} />
                <meshBasicMaterial
                  color="#00aaff"
                  transparent
                  opacity={0}
                  side={THREE.DoubleSide}
                />
              </mesh>
            );
          })}
        </group>
      )}
      
      {/* Bow Wave Ripples */}
      {speed > 0.2 && (
        <group position={[
          position[0] - Math.sin(rotation) * 10,
          position[1] + 1.5,
          position[2] - Math.cos(rotation) * 10
        ]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[1.5, 2.5, 32]} />
            <meshBasicMaterial
              color="#00ffff"
              transparent
              opacity={speed * 0.15}
              side={THREE.DoubleSide}
            />
          </mesh>
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[2.5, 3.5, 32]} />
            <meshBasicMaterial
              color="#00ffff"
              transparent
              opacity={speed * 0.1}
              side={THREE.DoubleSide}
            />
          </mesh>
        </group>
      )}
      
      {/* Navigation Light Glow */}
      <pointLight
        position={[
          position[0] - Math.sin(rotation) * 12,
          position[1],
          position[2] - Math.cos(rotation) * 12
        ]}
        color="#ffffff"
        intensity={isMoving ? 3 : 1.5}
        distance={8}
      />
      
      {/* Port and Starboard Lights Glow */}
      <pointLight
        position={[
          position[0] - Math.sin(rotation - Math.PI / 2) * 2,
          position[1] + 3,
          position[2] - Math.cos(rotation - Math.PI / 2) * 2
        ]}
        color="#00ff00"
        intensity={2}
        distance={5}
      />
      <pointLight
        position={[
          position[0] - Math.sin(rotation + Math.PI / 2) * 2,
          position[1] + 3,
          position[2] - Math.cos(rotation + Math.PI / 2) * 2
        ]}
        color="#ff0000"
        intensity={2}
        distance={5}
      />
    </group>
  );
}