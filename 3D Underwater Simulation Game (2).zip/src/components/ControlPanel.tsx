import { Card } from './ui/card';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { Radar, Settings, Activity, RotateCcw, Navigation, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

interface ControlPanelProps {
  isScanning: boolean;
  onScan: (direction: 'north' | 'south' | 'east' | 'west' | 'all') => void;
  onReset: () => void;
  detectionRange: number;
  onDetectionRangeChange: (value: number) => void;
  aiSensitivity: number;
  onAiSensitivityChange: (value: number) => void;
  hasDetections: boolean;
  currentDirection: string;
}

export function ControlPanel({
  isScanning,
  onScan,
  onReset,
  detectionRange,
  onDetectionRangeChange,
  aiSensitivity,
  onAiSensitivityChange,
  hasDetections,
  currentDirection,
}: ControlPanelProps) {
  return (
    <Card className="w-full max-w-5xl bg-slate-900/95 border-cyan-500/40 backdrop-blur-md p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/20 rounded-lg">
              <Settings className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-white">Sonar Control</h2>
              <p className="text-slate-400 text-sm">System Configuration</p>
            </div>
          </div>
          
          {/* Status Badge */}
          <Badge 
            variant={isScanning ? "default" : "secondary"}
            className={isScanning ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-slate-700 text-slate-400"}
          >
            {isScanning ? 'ACTIVE' : 'STANDBY'}
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Directional Scan Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-3">
              <Navigation className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-300">Scan Direction</span>
            </div>
            
            {/* Direction Grid */}
            <div className="grid grid-cols-3 gap-2">
              <div></div>
              <Button 
                onClick={() => onScan('north')}
                disabled={isScanning}
                variant="outline"
                size="sm"
                className="border-cyan-500/40 hover:bg-cyan-500/20 hover:border-cyan-500"
              >
                <ArrowUp className="w-4 h-4" />
              </Button>
              <div></div>
              
              <Button 
                onClick={() => onScan('west')}
                disabled={isScanning}
                variant="outline"
                size="sm"
                className="border-cyan-500/40 hover:bg-cyan-500/20 hover:border-cyan-500"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <Button 
                onClick={() => onScan('all')}
                disabled={isScanning}
                variant="outline"
                size="sm"
                className="border-cyan-500/40 hover:bg-cyan-500/20 hover:border-cyan-500"
              >
                <Radar className="w-4 h-4" />
              </Button>
              <Button 
                onClick={() => onScan('east')}
                disabled={isScanning}
                variant="outline"
                size="sm"
                className="border-cyan-500/40 hover:bg-cyan-500/20 hover:border-cyan-500"
              >
                <ArrowRight className="w-4 h-4" />
              </Button>
              
              <div></div>
              <Button 
                onClick={() => onScan('south')}
                disabled={isScanning}
                variant="outline"
                size="sm"
                className="border-cyan-500/40 hover:bg-cyan-500/20 hover:border-cyan-500"
              >
                <ArrowDown className="w-4 h-4" />
              </Button>
              <div></div>
            </div>
            
            <div className="grid grid-cols-5 gap-1 text-xs text-slate-500 text-center">
              <div></div>
              <div>North</div>
              <div></div>
              <div></div>
              <div></div>
              <div>West</div>
              <div></div>
              <div>360°</div>
              <div></div>
              <div>East</div>
              <div></div>
              <div>South</div>
              <div></div>
              <div></div>
              <div></div>
            </div>

            {/* Current Direction */}
            {isScanning && (
              <div className="flex items-center justify-between p-3 bg-cyan-500/10 rounded-lg border border-cyan-500/30 mt-3">
                <span className="text-cyan-300 text-sm">Scanning:</span>
                <Badge className="bg-cyan-500/20 text-cyan-400">
                  {currentDirection.toUpperCase()}
                </Badge>
              </div>
            )}
            
            {/* Reset Button */}
            <Button 
              onClick={onReset}
              disabled={!hasDetections || isScanning}
              variant="outline"
              className="w-full border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-white mt-3"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset Detections
            </Button>
          </div>

          {/* Detection Range */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                Detection Range
              </label>
              <span className="text-cyan-400 text-lg">{detectionRange}m</span>
            </div>
            <Slider
              value={[detectionRange]}
              onValueChange={([value]) => onDetectionRangeChange(value)}
              min={20}
              max={80}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-slate-500">
              <span>20m</span>
              <span>50m</span>
              <span>80m</span>
            </div>
            
            <div className="pt-4">
              <div className="text-slate-400 text-sm mb-2">Range Visualization</div>
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-500 to-cyan-300 transition-all duration-300"
                  style={{ width: `${(detectionRange / 80) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* AI Sensitivity */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-slate-300 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                AI Sensitivity
              </label>
              <span className="text-cyan-400 text-lg">{(aiSensitivity * 100).toFixed(0)}%</span>
            </div>
            <Slider
              value={[aiSensitivity * 100]}
              onValueChange={([value]) => onAiSensitivityChange(value / 100)}
              min={50}
              max={100}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-slate-500">
              <span>Low</span>
              <span>Medium</span>
              <span>High</span>
            </div>
            
            <div className="pt-4">
              <div className="text-slate-400 text-sm mb-2">Confidence Threshold</div>
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 transition-all duration-300"
                  style={{ width: `${aiSensitivity * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="pt-4 border-t border-slate-800">
          <p className="text-slate-500 text-sm text-center">
            Select scan direction or use 360° for full coverage. Adjust parameters to optimize threat detection. Click Reset to clear detections.
          </p>
        </div>
      </div>
    </Card>
  );
}
