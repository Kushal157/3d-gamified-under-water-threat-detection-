import { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface PlayerSubmarineProps {
  onPositionUpdate: (pos: any, rot: any, speed: number) => void;
}

export function PlayerSubmarine({ onPositionUpdate }: PlayerSubmarineProps) {
  const groupRef = useRef<THREE.Group>(null);
  const propellerRef = useRef<THREE.Group>(null);
  const [keys, setKeys] = useState<{ [key: string]: boolean }>({});
  const velocityRef = useRef(new THREE.Vector3());
  const speedRef = useRef(0);
  
  // Submarine physics constants
  const MAX_SPEED = 0.5;
  const ACCELERATION = 0.015;
  const DECELERATION = 0.008;
  const ROTATION_SPEED = 0.02;
  const VERTICAL_SPEED = 0.15;
  const MIN_DEPTH = -2;
  const MAX_DEPTH = -32;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => ({ ...prev, [e.key.toLowerCase()]: true }));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => ({ ...prev, [e.key.toLowerCase()]: false }));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useFrame((state) => {
    if (!groupRef.current) return;

    const submarine = groupRef.current;
    
    // Forward/Backward movement
    if (keys['w']) {
      speedRef.current = Math.min(speedRef.current + ACCELERATION, MAX_SPEED);
    } else if (keys['s']) {
      speedRef.current = Math.max(speedRef.current - ACCELERATION, -MAX_SPEED * 0.5);
    } else {
      // Deceleration
      if (speedRef.current > 0) {
        speedRef.current = Math.max(0, speedRef.current - DECELERATION);
      } else if (speedRef.current < 0) {
        speedRef.current = Math.min(0, speedRef.current + DECELERATION);
      }
    }

    // Rotation (yaw)
    if (keys['a']) {
      submarine.rotation.y += ROTATION_SPEED;
    }
    if (keys['d']) {
      submarine.rotation.y -= ROTATION_SPEED;
    }

    // Vertical movement (depth control)
    if (keys[' ']) { // Space - surface
      submarine.position.y = Math.min(submarine.position.y + VERTICAL_SPEED, MIN_DEPTH);
    }
    if (keys['shift']) { // Shift - dive
      submarine.position.y = Math.max(submarine.position.y - VERTICAL_SPEED, MAX_DEPTH);
    }

    // Pitch control
    if (keys['e']) {
      submarine.rotation.x = Math.max(submarine.rotation.x - 0.01, -Math.PI / 12);
    }
    if (keys['q']) {
      submarine.rotation.x = Math.min(submarine.rotation.x + 0.01, Math.PI / 12);
    }
    
    // If not pitching, gradually level out
    if (!keys['e'] && !keys['q']) {
      submarine.rotation.x *= 0.95;
    }

    // Apply movement in the direction submarine is facing
    const direction = new THREE.Vector3(0, 0, -1);
    direction.applyQuaternion(submarine.quaternion);
    
    velocityRef.current.copy(direction).multiplyScalar(speedRef.current);
    submarine.position.add(velocityRef.current);

    // Clamp depth
    submarine.position.y = Math.max(Math.min(submarine.position.y, MIN_DEPTH), MAX_DEPTH);

    // Add subtle bobbing motion based on speed
    const bobAmount = Math.abs(speedRef.current) * 0.3;
    submarine.position.y += Math.sin(state.clock.getElapsedTime() * 2) * bobAmount * 0.05;
    
    // Slight roll based on turning
    const rollAmount = (keys['a'] ? 1 : 0) - (keys['d'] ? 1 : 0);
    submarine.rotation.z = rollAmount * 0.1;

    // Rotate propeller based on speed
    if (propellerRef.current) {
      propellerRef.current.rotation.z += speedRef.current * 2;
    }

    // Update parent component
    onPositionUpdate(
      { x: submarine.position.x, y: submarine.position.y, z: submarine.position.z },
      { x: submarine.rotation.x, y: submarine.rotation.y, z: submarine.rotation.z },
      Math.abs(speedRef.current) * 100
    );
  });

  return (
    <group ref={groupRef} position={[0, -8, 0]}>
      {/* Main hull */}
      <mesh castShadow receiveShadow>
        <capsuleGeometry args={[2, 10, 32, 64]} />
        <meshStandardMaterial 
          color="#2a4a6a"
          roughness={0.25}
          metalness={0.85}
          envMapIntensity={1.5}
        />
      </mesh>
      
      {/* Hull panels with rivets */}
      {Array.from({ length: 10 }).map((_, i) => (
        <mesh key={`panel-${i}`} position={[0, i * 1.2 - 5.5, 2.05]} castShadow>
          <boxGeometry args={[3.9, 1, 0.08]} />
          <meshStandardMaterial 
            color="#1a3a5a"
            roughness={0.35}
            metalness={0.8}
          />
        </mesh>
      ))}
      
      {/* Conning tower (sail) */}
      <group position={[0, 2.5, -1]}>
        <mesh castShadow receiveShadow>
          <boxGeometry args={[2.2, 3, 4]} />
          <meshStandardMaterial 
            color="#1a3a5a"
            roughness={0.3}
            metalness={0.85}
          />
        </mesh>
        
        {/* Bridge windows */}
        <mesh position={[0, 0.5, 2.15]}>
          <boxGeometry args={[1.8, 1, 0.1]} />
          <meshStandardMaterial 
            color="#001122"
            roughness={0.05}
            metalness={0.3}
            emissive="#0099ff"
            emissiveIntensity={0.4}
            transparent
            opacity={0.8}
          />
        </mesh>
        
        {/* Top hatch */}
        <mesh position={[0, 1.6, 0]} rotation={[0, 0, 0]}>
          <cylinderGeometry args={[0.4, 0.4, 0.1, 16]} />
          <meshStandardMaterial color="#0a1a2a" roughness={0.4} metalness={0.9} />
        </mesh>
      </group>
      
      {/* Periscopes */}
      <mesh position={[0.3, 5.2, -1]} castShadow>
        <cylinderGeometry args={[0.12, 0.12, 3, 16]} />
        <meshStandardMaterial 
          color="#334455"
          roughness={0.15}
          metalness={0.95}
        />
      </mesh>
      <mesh position={[0.3, 6.7, -1]}>
        <boxGeometry args={[0.35, 0.25, 0.5]} />
        <meshStandardMaterial color="#334455" roughness={0.15} metalness={0.95} />
      </mesh>
      
      {/* Antenna */}
      <mesh position={[-0.3, 5, -1]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 2.5, 8]} />
        <meshStandardMaterial color="#1a2a3a" roughness={0.2} metalness={0.95} />
      </mesh>
      
      {/* Front dive planes */}
      <group position={[0, 0, -5.5]}>
        <mesh position={[3.2, 0, 0]} rotation={[0, 0, 0.08]} castShadow>
          <boxGeometry args={[3.5, 0.25, 1.8]} />
          <meshStandardMaterial color="#1a3a5a" roughness={0.3} metalness={0.85} />
        </mesh>
        <mesh position={[-3.2, 0, 0]} rotation={[0, 0, -0.08]} castShadow>
          <boxGeometry args={[3.5, 0.25, 1.8]} />
          <meshStandardMaterial color="#1a3a5a" roughness={0.3} metalness={0.85} />
        </mesh>
      </group>
      
      {/* Rear stabilizers and rudder */}
      <group position={[0, 0, 6]}>
        {/* Vertical rudder */}
        <mesh position={[0, 2.5, 0]} castShadow>
          <boxGeometry args={[0.25, 3.5, 2.5]} />
          <meshStandardMaterial color="#1a3a5a" roughness={0.3} metalness={0.85} />
        </mesh>
        
        {/* Horizontal stabilizers */}
        <mesh position={[2.8, 0, 0]} rotation={[0, 0, 0.05]} castShadow>
          <boxGeometry args={[3.5, 0.25, 2.5]} />
          <meshStandardMaterial color="#1a3a5a" roughness={0.3} metalness={0.85} />
        </mesh>
        <mesh position={[-2.8, 0, 0]} rotation={[0, 0, -0.05]} castShadow>
          <boxGeometry args={[3.5, 0.25, 2.5]} />
          <meshStandardMaterial color="#1a3a5a" roughness={0.3} metalness={0.85} />
        </mesh>
      </group>
      
      {/* Propeller assembly */}
      <group ref={propellerRef} position={[0, 0, 7]}>
        {/* Propeller blades */}
        {[0, 1, 2, 3, 4].map((i) => (
          <mesh 
            key={i}
            rotation={[0, 0, (Math.PI * 2 / 5) * i]}
            castShadow
          >
            <boxGeometry args={[0.18, 2.8, 0.1]} />
            <meshStandardMaterial 
              color="#0a1a2a" 
              metalness={0.95} 
              roughness={0.15}
            />
          </mesh>
        ))}
        {/* Hub */}
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.5, 0.5, 0.4, 20]} />
          <meshStandardMaterial color="#1a2a3a" metalness={0.9} roughness={0.2} />
        </mesh>
        {/* Shaft */}
        <mesh position={[0, 0, -0.5]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.25, 0.25, 1, 16]} />
          <meshStandardMaterial color="#0a1a2a" metalness={0.95} roughness={0.2} />
        </mesh>
      </group>
      
      {/* Sonar dome (bow) */}
      <mesh position={[0, 0, -6.5]} castShadow>
        <sphereGeometry args={[1.3, 32, 32]} />
        <meshStandardMaterial 
          color="#00aaaa"
          roughness={0.08}
          metalness={0.95}
          emissive="#00ffff"
          emissiveIntensity={0.5}
          transparent
          opacity={0.95}
        />
      </mesh>
      
      {/* Torpedo tubes */}
      {[
        [-1, -1.2, -5.8],
        [1, -1.2, -5.8],
        [-1, -0.3, -5.8],
        [1, -0.3, -5.8],
      ].map((pos, i) => (
        <mesh key={`tube-${i}`} position={pos as [number, number, number]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.28, 0.28, 1.2, 16]} />
          <meshStandardMaterial color="#0a1a2a" roughness={0.4} metalness={0.8} />
        </mesh>
      ))}
      
      {/* Navigation and running lights */}
      <pointLight position={[2.2, 0, -5]} intensity={2} color="#00ff00" distance={12} />
      <pointLight position={[-2.2, 0, -5]} intensity={2} color="#ff0000" distance={12} />
      <pointLight position={[0, 0, -7]} intensity={4} color="#00ffff" distance={25} />
      <pointLight position={[0, 2, 6]} intensity={1.5} color="#ffffff" distance={15} />
      
      {/* Light housings */}
      <mesh position={[2.2, 0, -5]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial 
          color="#00ff00" 
          emissive="#00ff00" 
          emissiveIntensity={2}
          transparent
          opacity={0.9}
        />
      </mesh>
      <mesh position={[-2.2, 0, -5]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial 
          color="#ff0000" 
          emissive="#ff0000" 
          emissiveIntensity={2}
          transparent
          opacity={0.9}
        />
      </mesh>
      
      {/* Ballast tank vents */}
      {[-1.8, 1.8].map((x, i) => (
        <mesh key={`vent-${i}`} position={[x, 1.5, 2]} castShadow>
          <cylinderGeometry args={[0.15, 0.15, 0.3, 8]} />
          <meshStandardMaterial color="#0a1a2a" roughness={0.6} metalness={0.7} />
        </mesh>
      ))}
    </group>
  );
}
