import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function Kelp({ position, height, offset }: { position: [number, number, number]; height: number; offset: number }) {
  const kelpRef = useRef<THREE.Group>(null);
  const segmentRefs = useRef<THREE.Mesh[]>([]);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    
    // Gentle swaying motion for each segment
    segmentRefs.current.forEach((segment, i) => {
      if (segment) {
        const sway = Math.sin(time * 0.5 + offset + i * 0.3) * 0.15;
        segment.rotation.z = sway;
        segment.rotation.x = Math.cos(time * 0.4 + offset + i * 0.2) * 0.1;
      }
    });
  });

  const segments = 8;
  const segmentHeight = height / segments;

  return (
    <group ref={kelpRef} position={position}>
      {Array.from({ length: segments }).map((_, i) => (
        <mesh
          key={i}
          ref={(el) => { if (el) segmentRefs.current[i] = el; }}
          position={[0, i * segmentHeight + segmentHeight / 2, 0]}
          castShadow
        >
          <cylinderGeometry args={[0.08 - i * 0.008, 0.09 - i * 0.008, segmentHeight, 8]} />
          <meshStandardMaterial 
            color={i % 2 === 0 ? "#2d4a1a" : "#3d5a2a"}
            roughness={0.8}
          />
        </mesh>
      ))}
      
      {/* Kelp blades - attached to stem */}
      {Array.from({ length: 5 }).map((_, i) => (
        <mesh
          key={`blade-${i}`}
          position={[
            Math.sin(i * 1.2) * 0.15,
            height * 0.3 + i * (height * 0.15),
            Math.cos(i * 1.2) * 0.15
          ]}
          rotation={[0, i * 0.8, Math.sin(i) * 0.3]}
          castShadow
        >
          <boxGeometry args={[0.3, 0.8, 0.02]} />
          <meshStandardMaterial 
            color="#3d5a2a"
            roughness={0.7}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}

function SeaGrass({ position, offset }: { position: [number, number, number]; offset: number }) {
  const grassRef = useRef<THREE.Group>(null);
  const bladeRefs = useRef<THREE.Mesh[]>([]);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    
    // Gentle wave motion
    bladeRefs.current.forEach((blade, i) => {
      if (blade) {
        blade.rotation.z = Math.sin(time * 0.6 + offset + i * 0.2) * 0.2;
        blade.rotation.x = Math.cos(time * 0.5 + offset + i * 0.3) * 0.15;
      }
    });
  });

  return (
    <group ref={grassRef} position={position}>
      {Array.from({ length: 12 }).map((_, i) => {
        const angle = (i / 12) * Math.PI * 2;
        const distance = Math.random() * 0.3;
        const x = Math.cos(angle) * distance;
        const z = Math.sin(angle) * distance;
        const height = 0.5 + Math.random() * 0.5;
        
        return (
          <mesh
            key={i}
            ref={(el) => { if (el) bladeRefs.current[i] = el; }}
            position={[x, height / 2, z]}
            castShadow
          >
            <boxGeometry args={[0.03, height, 0.01]} />
            <meshStandardMaterial 
              color={["#3a5a2a", "#2a4a1a", "#4a6a3a"][Math.floor(Math.random() * 3)]}
              roughness={0.8}
              side={THREE.DoubleSide}
            />
          </mesh>
        );
      })}
    </group>
  );
}

function CoralFormation({ position, type }: { position: [number, number, number]; type: number }) {
  const coralRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (coralRef.current) {
      // Very subtle breathing motion
      const pulse = 1 + Math.sin(state.clock.getElapsedTime() * 0.5 + position[0]) * 0.03;
      coralRef.current.scale.set(pulse, pulse, pulse);
    }
  });

  const coralColors = [
    { main: "#ff6b6b", glow: "#ff4444" },
    { main: "#4ecdc4", glow: "#3ebdb4" },
    { main: "#f9ca24", glow: "#e9ba14" },
    { main: "#a29bfe", glow: "#928bfe" },
  ];

  const color = coralColors[type % coralColors.length];

  return (
    <group ref={coralRef} position={position}>
      {type % 3 === 0 ? (
        // Branch coral
        <>
          <mesh castShadow>
            <cylinderGeometry args={[0.15, 0.2, 1.5, 8]} />
            <meshStandardMaterial 
              color={color.main}
              roughness={0.7}
              emissive={color.glow}
              emissiveIntensity={0.1}
            />
          </mesh>
          {Array.from({ length: 5 }).map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos(i * 1.3) * 0.3,
                0.5 + i * 0.2,
                Math.sin(i * 1.3) * 0.3
              ]}
              rotation={[0.3, i * 1.3, 0.3]}
              castShadow
            >
              <cylinderGeometry args={[0.08, 0.12, 0.8, 6]} />
              <meshStandardMaterial 
                color={color.main}
                roughness={0.7}
                emissive={color.glow}
                emissiveIntensity={0.1}
              />
            </mesh>
          ))}
        </>
      ) : type % 3 === 1 ? (
        // Table coral
        <>
          <mesh position={[0, 0.4, 0]} castShadow>
            <cylinderGeometry args={[0.12, 0.15, 0.8, 8]} />
            <meshStandardMaterial color={color.main} roughness={0.7} />
          </mesh>
          <mesh position={[0, 0.9, 0]} castShadow>
            <cylinderGeometry args={[0.8, 0.6, 0.2, 16]} />
            <meshStandardMaterial 
              color={color.main}
              roughness={0.6}
              emissive={color.glow}
              emissiveIntensity={0.1}
            />
          </mesh>
        </>
      ) : (
        // Brain coral
        <mesh castShadow>
          <sphereGeometry args={[0.6, 16, 16]} />
          <meshStandardMaterial 
            color={color.main}
            roughness={0.8}
            emissive={color.glow}
            emissiveIntensity={0.08}
          />
        </mesh>
      )}
    </group>
  );
}

export function OceanFloor() {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      const positions = meshRef.current.geometry.attributes.position;
      const time = state.clock.getElapsedTime();
      
      // Much slower, gentler floor movement
      for (let i = 0; i < positions.count; i++) {
        const x = positions.getX(i);
        const y = positions.getY(i);
        const wave = Math.sin(x * 0.015 + time * 0.1) * Math.cos(y * 0.015 + time * 0.08) * 0.15;
        positions.setZ(i, wave);
      }
      positions.needsUpdate = true;
    }
  });

  return (
    <group>
      {/* Main Ocean Floor */}
      <mesh 
        ref={meshRef}
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, -35, 0]}
        receiveShadow
      >
        <planeGeometry args={[250, 250, 80, 80]} />
        <meshStandardMaterial 
          color="#1a2f3a"
          roughness={0.95}
          metalness={0.05}
        />
      </mesh>
      
      {/* Sand dunes - fewer and more subtle */}
      {Array.from({ length: 20 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 140;
        const z = (Math.random() - 0.5) * 140;
        const scaleX = Math.random() * 6 + 3;
        const scaleZ = Math.random() * 6 + 3;
        const height = Math.random() * 1 + 0.3;
        
        return (
          <mesh 
            key={`dune-${i}`}
            position={[x, -34 + height / 2, z]}
            rotation={[-Math.PI / 2, 0, Math.random() * Math.PI]}
            receiveShadow
          >
            <cylinderGeometry args={[scaleX, scaleZ, height, 16]} />
            <meshStandardMaterial 
              color="#243842"
              roughness={0.9}
            />
          </mesh>
        );
      })}
      
      {/* Rocky formations - fewer */}
      {Array.from({ length: 15 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 130;
        const z = (Math.random() - 0.5) * 130;
        const scale = Math.random() * 2 + 1;
        const height = Math.random() * 3 + 1.5;
        
        return (
          <mesh 
            key={`rock-${i}`}
            position={[x, -34 + height / 2, z]}
            rotation={[Math.random() * 0.2, Math.random() * Math.PI * 2, Math.random() * 0.2]}
            castShadow
            receiveShadow
          >
            <dodecahedronGeometry args={[scale, 0]} />
            <meshStandardMaterial 
              color={i % 3 === 0 ? "#2a4a52" : "#1f3a42"}
              roughness={0.95}
            />
          </mesh>
        );
      })}
      
      {/* Kelp forests */}
      {Array.from({ length: 25 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 100;
        const z = (Math.random() - 0.5) * 100;
        const height = 3 + Math.random() * 4;
        
        return (
          <Kelp 
            key={`kelp-${i}`}
            position={[x, -34, z]}
            height={height}
            offset={i}
          />
        );
      })}
      
      {/* Sea grass patches */}
      {Array.from({ length: 40 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 110;
        const z = (Math.random() - 0.5) * 110;
        
        return (
          <SeaGrass 
            key={`seagrass-${i}`}
            position={[x, -34, z]}
            offset={i}
          />
        );
      })}
      
      {/* Coral formations */}
      {Array.from({ length: 20 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 90;
        const z = (Math.random() - 0.5) * 90;
        
        return (
          <CoralFormation 
            key={`coral-${i}`}
            position={[x, -34, z]}
            type={i}
          />
        );
      })}

      {/* Sea anemones */}
      {Array.from({ length: 15 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 100;
        const z = (Math.random() - 0.5) * 100;
        
        return (
          <group key={`anemone-${i}`} position={[x, -34, z]}>
            {/* Base */}
            <mesh castShadow>
              <cylinderGeometry args={[0.2, 0.25, 0.4, 12]} />
              <meshStandardMaterial color="#8b4789" roughness={0.7} />
            </mesh>
            {/* Tentacles */}
            {Array.from({ length: 20 }).map((_, j) => {
              const angle = (j / 20) * Math.PI * 2;
              const distance = 0.15;
              const tx = Math.cos(angle) * distance;
              const tz = Math.sin(angle) * distance;
              
              return (
                <mesh
                  key={j}
                  position={[tx, 0.2, tz]}
                  rotation={[Math.random() * 0.3, 0, Math.random() * 0.3]}
                  castShadow
                >
                  <cylinderGeometry args={[0.015, 0.025, 0.4 + Math.random() * 0.2, 6]} />
                  <meshStandardMaterial 
                    color="#ab67a9"
                    roughness={0.6}
                    emissive="#8b4789"
                    emissiveIntensity={0.1}
                  />
                </mesh>
              );
            })}
          </group>
        );
      })}

      {/* Scattered shells and starfish */}
      {Array.from({ length: 25 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 120;
        const z = (Math.random() - 0.5) * 120;
        
        if (i % 3 === 0) {
          // Starfish
          return (
            <group key={`starfish-${i}`} position={[x, -34.2, z]} rotation={[-Math.PI / 2, 0, Math.random() * Math.PI * 2]}>
              {Array.from({ length: 5 }).map((_, j) => {
                const angle = (j / 5) * Math.PI * 2;
                return (
                  <mesh
                    key={j}
                    position={[Math.cos(angle) * 0.15, Math.sin(angle) * 0.15, 0]}
                    rotation={[0, 0, angle]}
                    receiveShadow
                  >
                    <coneGeometry args={[0.08, 0.3, 5]} />
                    <meshStandardMaterial color="#ff6b35" roughness={0.8} />
                  </mesh>
                );
              })}
              {/* Center */}
              <mesh receiveShadow>
                <cylinderGeometry args={[0.1, 0.1, 0.05, 16]} />
                <meshStandardMaterial color="#ff8b55" roughness={0.8} />
              </mesh>
            </group>
          );
        } else {
          // Shell
          return (
            <mesh 
              key={`shell-${i}`}
              position={[x, -34.2, z]}
              rotation={[Math.PI / 2 + Math.random() * 0.3, 0, Math.random() * Math.PI * 2]}
              receiveShadow
            >
              <torusGeometry args={[0.2, 0.08, 10, 16]} />
              <meshStandardMaterial 
                color="#e8d5c4"
                roughness={0.8}
              />
            </mesh>
          );
        }
      })}

      {/* Sponges */}
      {Array.from({ length: 12 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 95;
        const z = (Math.random() - 0.5) * 95;
        const height = 0.5 + Math.random() * 1;
        
        return (
          <mesh 
            key={`sponge-${i}`}
            position={[x, -34 + height / 2, z]}
            castShadow
          >
            <cylinderGeometry args={[0.3, 0.35, height, 8]} />
            <meshStandardMaterial 
              color={["#f4a460", "#daa520", "#cd853f"][Math.floor(Math.random() * 3)]}
              roughness={0.95}
            />
          </mesh>
        );
      })}
    </group>
  );
}
