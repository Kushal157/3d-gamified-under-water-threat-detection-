import { useMemo } from 'react';

export interface DynamicThreat {
  id: number;
  position: [number, number, number];
  type: 'submarine' | 'drone' | 'torpedo' | 'mine';
  threat: number;
}

export interface EnvironmentZone {
  name: string;
  description: string;
  threatDensity: 'low' | 'medium' | 'high';
}

/**
 * Generates static threats and environment - submarine moves through it
 */
export function useDynamicEnvironment(submarinePosition: [number, number, number]) {
  // Generate static environment once - never regenerate
  const staticEnvironment = useMemo(() => {
    const threats: DynamicThreat[] = [];
    const mines: { id: number; position: [number, number, number] }[] = [];
    
    // Generate threats distributed across the entire play area
    // Safe Zone (center): -30 to 30
    const safeZoneThreats: Array<'submarine' | 'drone' | 'torpedo' | 'mine'> = ['mine', 'drone'];
    for (let i = 0; i < 2; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 10 + Math.random() * 20;
      threats.push({
        id: i,
        position: [
          Math.cos(angle) * distance,
          -15 + Math.random() * 10,
          Math.sin(angle) * distance
        ],
        type: safeZoneThreats[i],
        threat: 0.4 + Math.random() * 0.4
      });
    }
    
    // Contested Waters: 30 to 60 radius
    const contestedTypes: Array<'submarine' | 'drone' | 'torpedo' | 'mine'> = ['submarine', 'mine', 'drone', 'mine'];
    for (let i = 0; i < 4; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 35 + Math.random() * 25;
      threats.push({
        id: i + 10,
        position: [
          Math.cos(angle) * distance,
          -15 + Math.random() * 10,
          Math.sin(angle) * distance
        ],
        type: contestedTypes[i],
        threat: 0.6 + Math.random() * 0.3
      });
    }
    
    // Hostile Territory: 60+ radius
    const hostileTypes: Array<'submarine' | 'drone' | 'torpedo' | 'mine'> = 
      ['submarine', 'submarine', 'torpedo', 'mine', 'drone', 'mine'];
    for (let i = 0; i < 6; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 65 + Math.random() * 30;
      threats.push({
        id: i + 20,
        position: [
          Math.cos(angle) * distance,
          -15 + Math.random() * 10,
          Math.sin(angle) * distance
        ],
        type: hostileTypes[i],
        threat: 0.85 + Math.random() * 0.15
      });
    }
    
    // Generate static mines distributed across zones
    // Safe zone mines
    for (let i = 0; i < 3; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 10 + Math.random() * 20;
      mines.push({
        id: i,
        position: [
          Math.cos(angle) * distance,
          -20 + Math.random() * 8,
          Math.sin(angle) * distance
        ]
      });
    }
    
    // Contested zone mines
    for (let i = 0; i < 5; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 35 + Math.random() * 25;
      mines.push({
        id: i + 10,
        position: [
          Math.cos(angle) * distance,
          -20 + Math.random() * 8,
          Math.sin(angle) * distance
        ]
      });
    }
    
    // Hostile zone mines
    for (let i = 0; i < 8; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 65 + Math.random() * 30;
      mines.push({
        id: i + 20,
        position: [
          Math.cos(angle) * distance,
          -20 + Math.random() * 8,
          Math.sin(angle) * distance
        ]
      });
    }
    
    return { threats, mines };
  }, []); // Empty dependency - generate once only
  
  // Determine current zone based on submarine position (for UI display only)
  const currentZone = useMemo(() => {
    const [x, y, z] = submarinePosition;
    const distance = Math.sqrt(x * x + z * z);
    
    if (distance < 30) {
      return {
        name: 'Safe Zone',
        description: 'Patrolled waters - Low threat level',
        threatDensity: 'low' as const
      };
    } else if (distance > 60) {
      return {
        name: 'Hostile Territory',
        description: 'Enemy waters - High threat level',
        threatDensity: 'high' as const
      };
    } else {
      return {
        name: 'Contested Waters',
        description: 'Disputed area - Medium threat level',
        threatDensity: 'medium' as const
      };
    }
  }, [
    Math.floor(submarinePosition[0] / 10),
    Math.floor(submarinePosition[2] / 10)
  ]);
  
  return {
    zone: currentZone,
    threats: staticEnvironment.threats,
    mines: staticEnvironment.mines
  };
}

/**
 * Component that provides environment data to children via render prop
 */
interface DynamicEnvironmentManagerProps {
  submarinePosition: [number, number, number];
  children: (environment: ReturnType<typeof useDynamicEnvironment>) => React.ReactNode;
}

export function DynamicEnvironmentManager({ submarinePosition, children }: DynamicEnvironmentManagerProps) {
  const environment = useDynamicEnvironment(submarinePosition);
  return <>{children(environment)}</>;
}