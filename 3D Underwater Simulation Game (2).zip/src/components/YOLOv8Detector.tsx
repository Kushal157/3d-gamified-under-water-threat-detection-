/**
 * Simulated YOLOv8 Object Detection System
 * In production, this would interface with a real YOLOv8 model
 * For this demo, we simulate the detection process with realistic delays and confidence scores
 */

interface DetectionBox {
  id: number;
  class: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  position: [number, number, number];
  threatLevel: 'critical' | 'high' | 'medium' | 'low';
}

interface YOLOv8Result {
  detections: DetectionBox[];
  processingTime: number;
  modelVersion: string;
  timestamp: number;
}

export class YOLOv8Detector {
  private modelVersion = 'YOLOv8n-underwater';
  private processingDelay = 800; // Simulated inference time in ms

  /**
   * Simulate YOLOv8 object detection on sonar data
   */
  async detectThreats(
    threatPositions: Array<{ id: number; position: [number, number, number]; type: string; threat: number }>,
    minePositions: Array<{ id: number; position: [number, number, number] }>,
    detectionRange: number,
    aiSensitivity: number,
    scanDirection: 'north' | 'south' | 'east' | 'west' | 'all',
    submarinePosition: [number, number, number] = [0, 0, 0]
  ): Promise<YOLOv8Result> {
    const startTime = Date.now();

    // Simulate model inference delay
    await new Promise(resolve => setTimeout(resolve, this.processingDelay));

    const detections: DetectionBox[] = [];

    // Helper function to check if position is in scan direction (relative to submarine)
    const isInDirection = (relX: number, relZ: number): boolean => {
      if (scanDirection === 'all') return true;
      
      const angle = Math.atan2(relX, relZ); // Note: using relX and relZ relative to submarine forward
      const degrees = (angle * 180 / Math.PI + 360) % 360;
      
      switch (scanDirection) {
        case 'north': return degrees > 315 || degrees < 45;
        case 'east': return degrees >= 45 && degrees < 135;
        case 'south': return degrees >= 135 && degrees < 225;
        case 'west': return degrees >= 225 && degrees < 315;
        default: return true;
      }
    };

    // Process threats with YOLOv8-style detection
    threatPositions.forEach((threat, index) => {
      // Calculate relative position to submarine
      const relativeX = threat.position[0] - submarinePosition[0];
      const relativeZ = threat.position[2] - submarinePosition[2];
      
      const distance = Math.sqrt(
        relativeX ** 2 + 
        relativeZ ** 2
      );

      if (distance <= detectionRange && 
          threat.threat >= aiSensitivity &&
          isInDirection(relativeX, relativeZ)) {
        
        // Simulate YOLOv8 bounding box detection
        // Add some variance to simulate real-world detection uncertainty
        const confidenceVariance = (Math.random() - 0.5) * 0.1;
        const baseConfidence = threat.threat + confidenceVariance;
        const confidence = Math.max(0.65, Math.min(0.99, baseConfidence));

        // Calculate normalized bbox coordinates
        const bboxSize = this.getBBoxSize(threat.type);
        
        detections.push({
          id: threat.id,
          class: threat.type,
          confidence: confidence,
          bbox: {
            x: (relativeX / detectionRange + 1) / 2, // Normalize to 0-1
            y: (threat.position[1] / 35 + 1) / 2, // Normalize depth
            width: bboxSize.width,
            height: bboxSize.height
          },
          position: threat.position,
          threatLevel: this.assessThreatLevel(threat.type, confidence, distance)
        });
      }
    });

    // Process mines with YOLOv8-style detection
    minePositions.forEach((mine) => {
      // Calculate relative position to submarine
      const relativeX = mine.position[0] - submarinePosition[0];
      const relativeZ = mine.position[2] - submarinePosition[2];
      
      const distance = Math.sqrt(
        relativeX ** 2 + 
        relativeZ ** 2
      );

      if (distance <= detectionRange &&
          isInDirection(relativeX, relativeZ)) {
        
        const confidenceVariance = (Math.random() - 0.5) * 0.08;
        const confidence = Math.max(0.85, Math.min(0.98, 0.92 + confidenceVariance));

        const bboxSize = this.getBBoxSize('mine');
        
        detections.push({
          id: 1000 + mine.id,
          class: 'mine',
          confidence: confidence,
          bbox: {
            x: (relativeX / detectionRange + 1) / 2,
            y: (mine.position[1] / 35 + 1) / 2,
            width: bboxSize.width,
            height: bboxSize.height
          },
          position: mine.position,
          threatLevel: this.assessThreatLevel('mine', confidence, distance)
        });
      }
    });

    const processingTime = Date.now() - startTime;

    return {
      detections,
      processingTime,
      modelVersion: this.modelVersion,
      timestamp: Date.now()
    };
  }

  /**
   * Get bounding box size based on object class
   */
  private getBBoxSize(type: string): { width: number; height: number } {
    const sizes = {
      submarine: { width: 0.15, height: 0.08 },
      mine: { width: 0.06, height: 0.06 },
      torpedo: { width: 0.08, height: 0.04 },
      drone: { width: 0.07, height: 0.05 }
    };

    return sizes[type as keyof typeof sizes] || { width: 0.1, height: 0.1 };
  }

  /**
   * Assess threat level based on type, confidence, and distance
   */
  private assessThreatLevel(
    type: string, 
    confidence: number, 
    distance: number
  ): 'critical' | 'high' | 'medium' | 'low' {
    if (type === 'torpedo' && distance < 20) return 'critical';
    if (type === 'mine' && distance < 15) return 'critical';
    if ((type === 'submarine' || type === 'torpedo') && confidence > 0.9) return 'critical';
    if (type === 'submarine' && distance < 30) return 'high';
    if (confidence > 0.85) return 'high';
    if (confidence > 0.75) return 'medium';
    return 'low';
  }

  /**
   * Get detection statistics
   */
  getDetectionStats(result: YOLOv8Result) {
    const stats = {
      totalDetections: result.detections.length,
      criticalThreats: result.detections.filter(d => d.threatLevel === 'critical').length,
      highThreats: result.detections.filter(d => d.threatLevel === 'high').length,
      averageConfidence: result.detections.length > 0
        ? result.detections.reduce((sum, d) => sum + d.confidence, 0) / result.detections.length
        : 0,
      processingTime: result.processingTime,
      detectionsByClass: this.groupByClass(result.detections)
    };

    return stats;
  }

  /**
   * Group detections by class
   */
  private groupByClass(detections: DetectionBox[]): Record<string, number> {
    return detections.reduce((acc, detection) => {
      acc[detection.class] = (acc[detection.class] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  }
}

// Export singleton instance
export const yoloDetector = new YOLOv8Detector();