import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface Mine {
  id: number;
  position: [number, number, number];
}

interface TetheredMinesProps {
  mines: Mine[];
  isScanning: boolean;
  detectionRange: number;
}

function TetheredMine({ 
  mine, 
  isScanning, 
  detectionRange 
}: { 
  mine: Mine; 
  isScanning: boolean; 
  detectionRange: number;
}) {
  const mineRef = useRef<THREE.Group>(null);
  const cableRef = useRef<THREE.Line>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  
  const distance = Math.sqrt(mine.position[0] ** 2 + mine.position[2] ** 2);
  const isDetected = isScanning && distance <= detectionRange;
  
  // Calculate ocean floor position
  const floorY = -35;
  const mineY = mine.position[1];
  const cableLength = Math.abs(floorY - mineY);

  useFrame((state) => {
    if (mineRef.current) {
      const time = state.clock.getElapsedTime();
      // Gentle swaying motion
      mineRef.current.position.x = mine.position[0] + Math.sin(time * 0.5 + mine.id) * 0.8;
      mineRef.current.position.z = mine.position[2] + Math.cos(time * 0.3 + mine.id) * 0.8;
      mineRef.current.rotation.y += 0.002;
      
      // Update cable to follow mine
      if (cableRef.current) {
        const points = [];
        const segments = 20;
        
        for (let i = 0; i <= segments; i++) {
          const t = i / segments;
          const y = floorY + cableLength * t;
          const swayX = mine.position[0] + Math.sin(time * 0.5 + mine.id) * 0.8 * t;
          const swayZ = mine.position[2] + Math.cos(time * 0.3 + mine.id) * 0.8 * t;
          // Add curve to cable
          const curve = Math.sin(t * Math.PI) * 0.5;
          points.push(new THREE.Vector3(swayX + curve, y, swayZ));
        }
        
        cableRef.current.geometry.setFromPoints(points);
      }
    }
    
    if (glowRef.current && isDetected) {
      glowRef.current.scale.setScalar(1.5 + Math.sin(state.clock.getElapsedTime() * 3) * 0.3);
    }
  });

  // Create cable points
  const cablePoints = [];
  const segments = 20;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const y = floorY + cableLength * t;
    cablePoints.push(new THREE.Vector3(mine.position[0], y, mine.position[2]));
  }

  return (
    <group>
      {/* Tether cable */}
      <line ref={cableRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={cablePoints.length}
            array={new Float32Array(cablePoints.flatMap(p => [p.x, p.y, p.z]))}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#333333" linewidth={2} />
      </line>
      
      {/* Anchor on ocean floor */}
      <mesh position={[mine.position[0], floorY + 0.3, mine.position[2]]} castShadow>
        <cylinderGeometry args={[0.4, 0.6, 0.6, 8]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.8} metalness={0.6} />
      </mesh>
      
      {/* Anchor spikes */}
      {Array.from({ length: 4 }).map((_, i) => (
        <mesh 
          key={i}
          position={[
            mine.position[0] + Math.cos(i * Math.PI / 2) * 0.5,
            floorY + 0.1,
            mine.position[2] + Math.sin(i * Math.PI / 2) * 0.5
          ]}
          rotation={[0, i * Math.PI / 2, Math.PI / 3]}
          castShadow
        >
          <coneGeometry args={[0.1, 0.5, 4]} />
          <meshStandardMaterial color="#0a0a0a" roughness={0.7} metalness={0.7} />
        </mesh>
      ))}
      
      {/* Mine body */}
      <group ref={mineRef} position={mine.position}>
        {/* Main sphere */}
        <mesh castShadow receiveShadow>
          <sphereGeometry args={[1, 16, 16]} />
          <meshStandardMaterial 
            color="#2a2a2a"
            roughness={0.6}
            metalness={0.8}
            emissive={isDetected ? "#ff3333" : "#000000"}
            emissiveIntensity={isDetected ? 0.3 : 0}
          />
        </mesh>
        
        {/* Spikes/horns (detonators) */}
        {Array.from({ length: 12 }).map((_, i) => {
          const phi = Math.acos(-1 + (2 * i) / 12);
          const theta = Math.sqrt(12 * Math.PI) * phi;
          
          const x = Math.cos(theta) * Math.sin(phi) * 1.2;
          const y = Math.sin(theta) * Math.sin(phi) * 1.2;
          const z = Math.cos(phi) * 1.2;
          
          return (
            <mesh 
              key={i}
              position={[x, y, z]}
              rotation={[phi, theta, 0]}
              castShadow
            >
              <cylinderGeometry args={[0.08, 0.05, 0.4, 8]} />
              <meshStandardMaterial 
                color="#444444"
                roughness={0.5}
                metalness={0.9}
                emissive={isDetected ? "#ff6666" : "#000000"}
                emissiveIntensity={isDetected ? 0.5 : 0}
              />
            </mesh>
          );
        })}
        
        {/* Warning stripes */}
        {[0, 1, 2, 3].map((i) => (
          <mesh 
            key={`stripe-${i}`}
            rotation={[0, (Math.PI / 2) * i, 0]}
          >
            <torusGeometry args={[1.05, 0.05, 8, 32]} />
            <meshStandardMaterial 
              color="#ffaa00"
              emissive="#ffaa00"
              emissiveIntensity={isDetected ? 0.5 : 0.2}
            />
          </mesh>
        ))}
        
        {/* Detection glow */}
        {isDetected && (
          <mesh ref={glowRef}>
            <sphereGeometry args={[2, 16, 16]} />
            <meshBasicMaterial 
              color="#ff3333"
              transparent
              opacity={0.2}
              side={THREE.BackSide}
            />
          </mesh>
        )}
        
        {/* Warning light */}
        {isDetected && (
          <pointLight color="#ff3333" intensity={3} distance={10} />
        )}
      </group>
      
      {/* Detection marker */}
      {isDetected && (
        <mesh position={[mine.position[0], mine.position[1] + 2.5, mine.position[2]]}>
          <coneGeometry args={[0.4, 1, 4]} />
          <meshBasicMaterial 
            color="#ff0000"
            transparent
            opacity={0.8}
          />
        </mesh>
      )}
    </group>
  );
}

export function TetheredMines({ mines, isScanning, detectionRange }: TetheredMinesProps) {
  return (
    <group>
      {mines.map((mine) => (
        <TetheredMine 
          key={mine.id}
          mine={mine}
          isScanning={isScanning}
          detectionRange={detectionRange}
        />
      ))}
    </group>
  );
}
