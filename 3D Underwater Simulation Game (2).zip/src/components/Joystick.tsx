import { useRef, useState, useEffect } from 'react';
import { Move } from 'lucide-react';

interface JoystickProps {
  onMove: (input: { x: number; y: number }) => void;
}

export function Joystick({ onMove }: JoystickProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const joystickRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<HTMLDivElement>(null);
  
  const maxDistance = 40;
  
  useEffect(() => {
    const handlePointerMove = (e: PointerEvent | TouchEvent) => {
      if (!isDragging || !joystickRef.current) return;
      
      const rect = joystickRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      let clientX, clientY;
      if ('touches' in e) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else {
        clientX = e.clientX;
        clientY = e.clientY;
      }
      
      const deltaX = clientX - centerX;
      const deltaY = clientY - centerY;
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      
      // Clamp to max distance
      const clampedDistance = Math.min(distance, maxDistance);
      const angle = Math.atan2(deltaY, deltaX);
      
      const clampedX = Math.cos(angle) * clampedDistance;
      const clampedY = Math.sin(angle) * clampedDistance;
      
      setPosition({ x: clampedX, y: clampedY });
      
      // Normalize to -1 to 1 range
      const normalizedX = clampedX / maxDistance;
      const normalizedY = clampedY / maxDistance;
      
      onMove({ x: normalizedX, y: normalizedY });
    };
    
    const handlePointerUp = () => {
      setIsDragging(false);
      setPosition({ x: 0, y: 0 });
      onMove({ x: 0, y: 0 });
    };
    
    if (isDragging) {
      window.addEventListener('pointermove', handlePointerMove);
      window.addEventListener('pointerup', handlePointerUp);
      window.addEventListener('touchmove', handlePointerMove as any);
      window.addEventListener('touchend', handlePointerUp);
    }
    
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove as any);
      window.removeEventListener('touchend', handlePointerUp);
    };
  }, [isDragging, onMove]);
  
  return (
    <div>
      <div 
        ref={joystickRef}
        className="relative w-32 h-32 bg-slate-900/60 backdrop-blur-md border-2 border-cyan-500/40 rounded-full"
        onPointerDown={() => setIsDragging(true)}
        onTouchStart={() => setIsDragging(true)}
      >
        {/* Center marker */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-cyan-500/40 rounded-full" />
        
        {/* Direction indicators */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 text-cyan-400/40 text-xs">↑</div>
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-cyan-400/40 text-xs">↓</div>
        <div className="absolute left-2 top-1/2 -translate-y-1/2 text-cyan-400/40 text-xs">←</div>
        <div className="absolute right-2 top-1/2 -translate-y-1/2 text-cyan-400/40 text-xs">→</div>
        
        {/* Handle */}
        <div
          ref={handleRef}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-full shadow-lg border-2 border-cyan-400/50 cursor-grab active:cursor-grabbing transition-transform flex items-center justify-center"
          style={{
            transform: `translate(-50%, -50%) translate(${position.x}px, ${position.y}px)`,
          }}
        >
          <Move className="w-6 h-6 text-white" />
        </div>
      </div>
      
      {/* Labels */}
      <div className="mt-2 text-center text-slate-400 text-xs">
        Movement Control
      </div>
      <div className="text-center text-slate-500 text-xs">
        Q/E: Depth
      </div>
    </div>
  );
}