import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function Fish({ position, speed, scale }: { position: [number, number, number]; speed: number; scale: number }) {
  const fishRef = useRef<THREE.Group>(null);
  const tailRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (fishRef.current) {
      const time = state.clock.getElapsedTime();
      
      // Slower, more graceful circular swimming pattern
      const radius = 12 + Math.sin(time * 0.15) * 3;
      fishRef.current.position.x = position[0] + Math.cos(time * speed * 0.4) * radius;
      fishRef.current.position.z = position[2] + Math.sin(time * speed * 0.4) * radius;
      fishRef.current.position.y = position[1] + Math.sin(time * 0.3) * 1;
      
      // Face swimming direction
      const angle = Math.atan2(
        Math.sin(time * speed * 0.4),
        Math.cos(time * speed * 0.4)
      );
      fishRef.current.rotation.y = angle + Math.PI / 2;
      
      // Subtle body undulation
      fishRef.current.rotation.z = Math.sin(time * 1.5) * 0.05;
    }
    
    // Gentle tail wagging
    if (tailRef.current) {
      tailRef.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 3) * 0.25;
    }
  });

  // More realistic fish colors
  const colors = ['#4a7c8c', '#6a9fb0', '#5a8595', '#7ab3c7', '#3a6c7c'];
  const color = colors[Math.floor(Math.random() * colors.length)];

  return (
    <group ref={fishRef} scale={scale}>
      {/* Streamlined body */}
      <mesh castShadow>
        <capsuleGeometry args={[0.15, 0.6, 12, 20]} />
        <meshStandardMaterial 
          color={color}
          roughness={0.4}
          metalness={0.2}
        />
      </mesh>
      
      {/* Head */}
      <mesh position={[0, 0, -0.4]} castShadow>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial color={color} roughness={0.4} metalness={0.2} />
      </mesh>
      
      {/* Tail fin */}
      <mesh ref={tailRef} position={[0, 0, 0.45]} rotation={[0, 0, 0]} castShadow>
        <boxGeometry args={[0.02, 0.35, 0.35]} />
        <meshStandardMaterial color={color} roughness={0.5} metalness={0.1} opacity={0.9} transparent />
      </mesh>
      
      {/* Dorsal fin */}
      <mesh position={[0, 0.15, 0]} rotation={[0, 0, 0]} castShadow>
        <boxGeometry args={[0.02, 0.2, 0.15]} />
        <meshStandardMaterial color={color} roughness={0.5} metalness={0.1} />
      </mesh>
      
      {/* Pectoral fins */}
      <mesh position={[0.15, 0, -0.1]} rotation={[0, 0.3, -Math.PI / 6]} castShadow>
        <boxGeometry args={[0.25, 0.02, 0.15]} />
        <meshStandardMaterial color={color} roughness={0.5} metalness={0.1} opacity={0.9} transparent />
      </mesh>
      <mesh position={[-0.15, 0, -0.1]} rotation={[0, -0.3, Math.PI / 6]} castShadow>
        <boxGeometry args={[0.25, 0.02, 0.15]} />
        <meshStandardMaterial color={color} roughness={0.5} metalness={0.1} opacity={0.9} transparent />
      </mesh>
      
      {/* Eyes */}
      <mesh position={[0.1, 0.05, -0.5]}>
        <sphereGeometry args={[0.03, 8, 8]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      <mesh position={[-0.1, 0.05, -0.5]}>
        <sphereGeometry args={[0.03, 8, 8]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
    </group>
  );
}

function Whale() {
  const whaleRef = useRef<THREE.Group>(null);
  const tailRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (whaleRef.current) {
      const time = state.clock.getElapsedTime();
      
      // Slower, majestic elliptical path
      whaleRef.current.position.x = Math.sin(time * 0.08) * 45;
      whaleRef.current.position.y = -18 + Math.sin(time * 0.12) * 4;
      whaleRef.current.position.z = Math.cos(time * 0.08) * 45;
      
      // Face direction of movement
      whaleRef.current.rotation.y = Math.atan2(
        Math.cos(time * 0.08),
        Math.sin(time * 0.08)
      ) + Math.PI / 2;
      
      // Gentle diving motion
      whaleRef.current.rotation.x = Math.sin(time * 0.12) * 0.15;
    }
    
    // Slow, powerful tail movement
    if (tailRef.current) {
      tailRef.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 1.2) * 0.3;
    }
  });

  return (
    <group ref={whaleRef}>
      {/* Body */}
      <mesh castShadow>
        <capsuleGeometry args={[2, 8, 20, 32]} />
        <meshStandardMaterial 
          color="#2a4a5a"
          roughness={0.6}
          metalness={0.1}
        />
      </mesh>
      
      {/* Head */}
      <mesh position={[0, 0, -5]} castShadow>
        <sphereGeometry args={[2.3, 20, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#2a4a5a" roughness={0.6} metalness={0.1} />
      </mesh>
      
      {/* Belly - lighter colored */}
      <mesh position={[0, -1.5, -2]} castShadow>
        <capsuleGeometry args={[1.5, 6, 16, 24]} />
        <meshStandardMaterial color="#3a5a6a" roughness={0.6} metalness={0.1} />
      </mesh>
      
      {/* Tail flukes */}
      <group ref={tailRef} position={[0, 0, 5]}>
        <mesh position={[0, 0, 0.5]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <boxGeometry args={[5, 0.3, 1.5]} />
          <meshStandardMaterial color="#1a3a4a" roughness={0.5} metalness={0.1} />
        </mesh>
      </group>
      
      {/* Pectoral fins */}
      <mesh position={[3, -0.5, -1]} rotation={[0, 0.3, -Math.PI / 3]} castShadow>
        <boxGeometry args={[2.5, 0.3, 1]} />
        <meshStandardMaterial color="#1a3a4a" roughness={0.5} metalness={0.1} />
      </mesh>
      <mesh position={[-3, -0.5, -1]} rotation={[0, -0.3, Math.PI / 3]} castShadow>
        <boxGeometry args={[2.5, 0.3, 1]} />
        <meshStandardMaterial color="#1a3a4a" roughness={0.5} metalness={0.1} />
      </mesh>
      
      {/* Dorsal fin */}
      <mesh position={[0, 2, 1]} rotation={[0.3, 0, 0]} castShadow>
        <coneGeometry args={[0.8, 1.5, 4]} />
        <meshStandardMaterial color="#1a3a4a" roughness={0.5} metalness={0.1} />
      </mesh>
      
      {/* Eyes */}
      <mesh position={[1.5, 0.5, -4]}>
        <sphereGeometry args={[0.12, 12, 12]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      <mesh position={[-1.5, 0.5, -4]}>
        <sphereGeometry args={[0.12, 12, 12]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
    </group>
  );
}

function Shark({ startPos, id }: { startPos: [number, number, number]; id: number }) {
  const sharkRef = useRef<THREE.Group>(null);
  const tailRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (sharkRef.current) {
      const time = state.clock.getElapsedTime();
      const speed = 0.12 + id * 0.03; // Slower, more menacing
      
      // Slower predatory swimming pattern
      sharkRef.current.position.x = startPos[0] + Math.sin(time * speed + id) * 35;
      sharkRef.current.position.y = startPos[1] + Math.sin(time * 0.15 + id) * 3;
      sharkRef.current.position.z = startPos[2] + Math.cos(time * speed + id) * 35;
      
      sharkRef.current.rotation.y = Math.atan2(
        Math.cos(time * speed + id),
        Math.sin(time * speed + id)
      ) + Math.PI / 2;
      
      // Subtle hunting dive motion
      sharkRef.current.rotation.x = Math.sin(time * 0.2 + id) * 0.1;
    }
    
    // Slower, powerful tail movement
    if (tailRef.current) {
      tailRef.current.rotation.z = Math.sin(state.clock.getElapsedTime() * 2.5 + id) * 0.3;
    }
  });

  return (
    <group ref={sharkRef}>
      {/* Body */}
      <mesh castShadow>
        <capsuleGeometry args={[0.6, 3.5, 20, 32]} />
        <meshStandardMaterial 
          color="#5a6a7a"
          roughness={0.4}
          metalness={0.1}
        />
      </mesh>
      
      {/* Head/snout */}
      <mesh position={[0, 0, -2.2]} castShadow>
        <coneGeometry args={[0.65, 1.2, 20]} />
        <meshStandardMaterial color="#5a6a7a" roughness={0.4} metalness={0.1} />
      </mesh>
      
      {/* Belly - lighter */}
      <mesh position={[0, -0.4, -0.5]} castShadow>
        <capsuleGeometry args={[0.5, 2.5, 16, 24]} />
        <meshStandardMaterial color="#7a8a9a" roughness={0.4} metalness={0.1} />
      </mesh>
      
      {/* Dorsal fin */}
      <mesh position={[0, 1.1, 0.3]} rotation={[0.2, 0, 0]} castShadow>
        <boxGeometry args={[0.05, 1.2, 0.8]} />
        <meshStandardMaterial color="#4a5a6a" roughness={0.4} />
      </mesh>
      
      {/* Tail with animation */}
      <group position={[0, 0.2, 2.2]} ref={tailRef}>
        <mesh rotation={[0, 0, 0]} castShadow>
          <boxGeometry args={[0.05, 1.2, 1.2]} />
          <meshStandardMaterial color="#4a5a6a" roughness={0.4} />
        </mesh>
      </group>
      
      {/* Pectoral fins */}
      <mesh position={[0.7, -0.3, -0.5]} rotation={[0.2, 0.1, -Math.PI / 4]} castShadow>
        <boxGeometry args={[1.2, 0.05, 0.6]} />
        <meshStandardMaterial color="#4a5a6a" roughness={0.4} />
      </mesh>
      <mesh position={[-0.7, -0.3, -0.5]} rotation={[0.2, -0.1, Math.PI / 4]} castShadow>
        <boxGeometry args={[1.2, 0.05, 0.6]} />
        <meshStandardMaterial color="#4a5a6a" roughness={0.4} />
      </mesh>
      
      {/* Eyes */}
      <mesh position={[0.25, 0.15, -2.5]}>
        <sphereGeometry args={[0.08, 12, 12]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      <mesh position={[-0.25, 0.15, -2.5]}>
        <sphereGeometry args={[0.08, 12, 12]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      
      {/* Gills */}
      {[0, 1, 2].map((i) => (
        <group key={i}>
          <mesh position={[0.55, -0.15, -0.8 + i * 0.35]} castShadow>
            <boxGeometry args={[0.03, 0.25, 0.1]} />
            <meshStandardMaterial color="#3a4a5a" roughness={0.5} />
          </mesh>
          <mesh position={[-0.55, -0.15, -0.8 + i * 0.35]} castShadow>
            <boxGeometry args={[0.03, 0.25, 0.1]} />
            <meshStandardMaterial color="#3a4a5a" roughness={0.5} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Crab({ position, id }: { position: [number, number, number]; id: number }) {
  const crabRef = useRef<THREE.Group>(null);
  const clawRefs = useRef<THREE.Group[]>([]);
  const legRefs = useRef<THREE.Group[]>([]);

  useFrame((state) => {
    if (crabRef.current) {
      const time = state.clock.getElapsedTime();
      
      // Slow sideways walking motion
      crabRef.current.position.x = position[0] + Math.sin(time * 0.3 + id) * 4;
      crabRef.current.position.z = position[2] + Math.cos(time * 0.15 + id) * 2;
      
      // Face walking direction
      crabRef.current.rotation.y = Math.sin(time * 0.2 + id) * Math.PI / 4;
    }
    
    // Animate claws - opening and closing slowly
    clawRefs.current.forEach((claw, i) => {
      if (claw) {
        claw.rotation.z = Math.sin(state.clock.getElapsedTime() * 1.5 + id + i) * 0.3;
      }
    });
    
    // Animate legs - walking motion
    legRefs.current.forEach((leg, i) => {
      if (leg) {
        leg.rotation.z = Math.sin(state.clock.getElapsedTime() * 2 + id + i * 0.5) * 0.2;
      }
    });
  });

  return (
    <group ref={crabRef} position={position}>
      {/* Body */}
      <mesh castShadow>
        <boxGeometry args={[0.8, 0.4, 1]} />
        <meshStandardMaterial 
          color="#8b4513"
          roughness={0.8}
          metalness={0.1}
        />
      </mesh>
      
      {/* Shell pattern */}
      <mesh position={[0, 0.15, 0]} castShadow>
        <sphereGeometry args={[0.45, 12, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#a0522d" roughness={0.8} />
      </mesh>
      
      {/* Eyes on stalks */}
      <mesh position={[0.25, 0.35, -0.4]}>
        <cylinderGeometry args={[0.04, 0.04, 0.2, 8]} />
        <meshStandardMaterial color="#8b4513" />
      </mesh>
      <mesh position={[0.25, 0.45, -0.4]}>
        <sphereGeometry args={[0.06, 8, 8]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      <mesh position={[-0.25, 0.35, -0.4]}>
        <cylinderGeometry args={[0.04, 0.04, 0.2, 8]} />
        <meshStandardMaterial color="#8b4513" />
      </mesh>
      <mesh position={[-0.25, 0.45, -0.4]}>
        <sphereGeometry args={[0.06, 8, 8]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      
      {/* Claws */}
      {[1, -1].map((side, i) => (
        <group 
          key={`claw-${i}`}
          ref={(el) => { if (el) clawRefs.current[i] = el; }}
          position={[side * 0.5, 0, -0.6]}
        >
          {/* Claw arm */}
          <mesh position={[side * 0.2, 0, 0]} rotation={[0, 0, side * -Math.PI / 6]} castShadow>
            <cylinderGeometry args={[0.08, 0.1, 0.6, 8]} />
            <meshStandardMaterial color="#a0522d" roughness={0.7} />
          </mesh>
          {/* Claw pincer */}
          <mesh position={[side * 0.4, 0, 0]} rotation={[0, 0, 0]} castShadow>
            <boxGeometry args={[0.15, 0.25, 0.15]} />
            <meshStandardMaterial color="#a0522d" roughness={0.7} />
          </mesh>
        </group>
      ))}
      
      {/* Legs - 4 on each side */}
      {[...Array(4)].map((_, i) => (
        <group key={`leg-${i}`}>
          {/* Right side leg */}
          <group
            ref={(el) => { if (el) legRefs.current[i * 2] = el; }}
            position={[0.4, -0.1, 0.3 - i * 0.25]}
            rotation={[0, 0, -Math.PI / 4]}
          >
            <mesh castShadow>
              <cylinderGeometry args={[0.04, 0.03, 0.5, 8]} />
              <meshStandardMaterial color="#8b4513" roughness={0.7} />
            </mesh>
          </group>
          {/* Left side leg */}
          <group
            ref={(el) => { if (el) legRefs.current[i * 2 + 1] = el; }}
            position={[-0.4, -0.1, 0.3 - i * 0.25]}
            rotation={[0, 0, Math.PI / 4]}
          >
            <mesh castShadow>
              <cylinderGeometry args={[0.04, 0.03, 0.5, 8]} />
              <meshStandardMaterial color="#8b4513" roughness={0.7} />
            </mesh>
          </group>
        </group>
      ))}
    </group>
  );
}

function JellyfishComponent({ position, offset }: { position: [number, number, number]; offset: number }) {
  const jellyRef = useRef<THREE.Group>(null);
  const tentaclesRef = useRef<THREE.Group[]>([]);

  useFrame((state) => {
    if (jellyRef.current) {
      const time = state.clock.getElapsedTime();
      
      // Slow, gentle pulsing movement
      jellyRef.current.position.y = position[1] + Math.sin(time * 0.4 + offset) * 2;
      jellyRef.current.position.x = position[0] + Math.sin(time * 0.1 + offset) * 1;
      jellyRef.current.position.z = position[2] + Math.cos(time * 0.1 + offset) * 1;
      
      // Gentle bell pulsing
      jellyRef.current.scale.y = 1 + Math.sin(time * 1.2 + offset) * 0.15;
      jellyRef.current.scale.x = 1 - Math.sin(time * 1.2 + offset) * 0.08;
      jellyRef.current.scale.z = 1 - Math.sin(time * 1.2 + offset) * 0.08;
    }
    
    // Slow tentacle wave motion
    tentaclesRef.current.forEach((tentacle, i) => {
      if (tentacle) {
        tentacle.rotation.x = Math.sin(state.clock.getElapsedTime() * 1.5 + offset + i) * 0.3;
        tentacle.rotation.z = Math.cos(state.clock.getElapsedTime() * 1.2 + offset + i) * 0.2;
      }
    });
  });

  return (
    <group ref={jellyRef} position={position}>
      {/* Bell/Head - more realistic translucent color */}
      <mesh castShadow>
        <sphereGeometry args={[0.8, 20, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial 
          color="#d8b4e2"
          transparent
          opacity={0.5}
          roughness={0.1}
          metalness={0.05}
          emissive="#c8a4d2"
          emissiveIntensity={0.2}
        />
      </mesh>
      
      {/* Inner glow - subtle */}
      <pointLight color="#d8b4e2" intensity={0.8} distance={5} />
      
      {/* Tentacles - realistic number */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * Math.PI * 2;
        const x = Math.cos(angle) * 0.5;
        const z = Math.sin(angle) * 0.5;
        
        return (
          <group 
            key={i}
            ref={(el) => {
              if (el) tentaclesRef.current[i] = el;
            }}
            position={[x, -0.4, z]}
          >
            <mesh castShadow>
              <cylinderGeometry args={[0.03, 0.015, 1.5 + Math.random() * 0.5, 8]} />
              <meshStandardMaterial 
                color="#e8c4f2"
                transparent
                opacity={0.6}
                emissive="#d8b4e2"
                emissiveIntensity={0.15}
              />
            </mesh>
          </group>
        );
      })}{/* Oral arms - thicker shorter tentacles */}
      {Array.from({ length: 4 }).map((_, i) => {
        const angle = (i / 4) * Math.PI * 2;
        const x = Math.cos(angle) * 0.3;
        const z = Math.sin(angle) * 0.3;
        
        return (
          <group key={`oral-${i}`} position={[x, -0.5, z]}>
            <mesh castShadow>
              <cylinderGeometry args={[0.05, 0.03, 0.8, 8]} />
              <meshStandardMaterial 
                color="#e8c4f2"
                transparent
                opacity={0.7}
              />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

export function MarineLife() {
  // Reduced number of fish for less noise
  const fishSchools = Array.from({ length: 20 }, (_, i) => ({
    position: [
      (Math.random() - 0.5) * 80,
      -8 - Math.random() * 20,
      (Math.random() - 0.5) * 80,
    ] as [number, number, number],
    speed: 0.2 + Math.random() * 0.3,
    scale: 0.5 + Math.random() * 0.8,
  }));

  const sharkPositions: [number, number, number][] = [
    [0, -15, 0],
    [35, -12, 35],
    [-30, -18, -25],
  ];

  const crabPositions: [number, number, number][] = [
    [-10, -33.8, 15],
    [20, -33.8, -10],
    [-25, -33.8, -20],
    [15, -33.8, 25],
    [-5, -33.8, -30],
    [30, -33.8, 10],
    [-20, -33.8, 30],
    [5, -33.8, -15],
  ];

  return (
    <group>
      {/* Fish schools - fewer, slower */}
      {fishSchools.map((fish, i) => (
        <Fish key={`fish-${i}`} {...fish} />
      ))}
      
      {/* Whales - majestic and slow */}
      <Whale />
      
      {/* Sharks - fewer, slower, more menacing */}
      {sharkPositions.map((pos, i) => (
        <Shark key={`shark-${i}`} startPos={pos} id={i} />
      ))}
      
      {/* Crabs - walking on ocean floor */}
      {crabPositions.map((pos, i) => (
        <Crab key={`crab-${i}`} position={pos} id={i} />
      ))}
      
      {/* Jellyfish - fewer, slower */}
      {Array.from({ length: 6 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 60;
        const z = (Math.random() - 0.5) * 60;
        
        return (
          <JellyfishComponent 
            key={`jellyfish-${i}`}
            position={[x, -10 - Math.random() * 12, z]}
            offset={i}
          />
        );
      })}
    </group>
  );
}
