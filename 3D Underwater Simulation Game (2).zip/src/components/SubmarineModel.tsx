import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export function SubmarineModel() {
  const groupRef = useRef<THREE.Group>(null);
  const propellerRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.position.y = -8 + Math.sin(state.clock.getElapsedTime() * 0.5) * 0.3;
      groupRef.current.rotation.z = Math.sin(state.clock.getElapsedTime() * 0.3) * 0.015;
    }
    
    if (propellerRef.current) {
      propellerRef.current.rotation.z += 0.3;
    }
  });

  return (
    <group ref={groupRef} position={[0, -8, 0]}>
      {/* Main hull - elongated teardrop shape */}
      <mesh castShadow receiveShadow position={[0, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <capsuleGeometry args={[1.8, 18, 32, 64]} />
        <meshStandardMaterial 
          color="#0a0a0a"
          roughness={0.25}
          metalness={0.9}
          envMapIntensity={1.5}
        />
      </mesh>
      
      {/* Forward hull section - tapered */}
      <mesh castShadow receiveShadow position={[-10.5, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[1.8, 3, 32]} />
        <meshStandardMaterial 
          color="#0a0a0a"
          roughness={0.25}
          metalness={0.9}
        />
      </mesh>
      
      {/* Bow dome */}
      <mesh castShadow position={[-11.8, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <sphereGeometry args={[1.2, 24, 24]} />
        <meshStandardMaterial 
          color="#1a1a1a"
          roughness={0.3}
          metalness={0.85}
        />
      </mesh>
      
      {/* Sonar array on bow */}
      <mesh position={[-12, 0, 0]}>
        <sphereGeometry args={[1.0, 24, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial 
          color="#003344"
          roughness={0.15}
          metalness={0.9}
          emissive="#004466"
          emissiveIntensity={0.3}
        />
      </mesh>
      
      {/* Aft hull section - tapered */}
      <mesh castShadow receiveShadow position={[10.5, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[1.8, 3, 32]} />
        <meshStandardMaterial 
          color="#0a0a0a"
          roughness={0.25}
          metalness={0.9}
        />
      </mesh>
      
      {/* Hull panels with anechoic tiles texture */}
      {Array.from({ length: 15 }).map((_, i) => (
        <group key={`panel-${i}`}>
          <mesh position={[i * 1.5 - 10, 1.85, 0]} castShadow>
            <boxGeometry args={[1.3, 0.05, 3.6]} />
            <meshStandardMaterial 
              color="#050505"
              roughness={0.35}
              metalness={0.85}
            />
          </mesh>
          <mesh position={[i * 1.5 - 10, -1.85, 0]} castShadow>
            <boxGeometry args={[1.3, 0.05, 3.6]} />
            <meshStandardMaterial 
              color="#050505"
              roughness={0.35}
              metalness={0.85}
            />
          </mesh>
        </group>
      ))}
      
      {/* Conning Tower (Sail) - Scorpene style */}
      <group position={[-2, 0, 0]}>
        {/* Main sail structure */}
        <mesh castShadow receiveShadow position={[0, 3.5, 0]}>
          <boxGeometry args={[3.5, 4, 2]} />
          <meshStandardMaterial 
            color="#0a0a0a"
            roughness={0.25}
            metalness={0.9}
          />
        </mesh>
        
        {/* Sail top fairing */}
        <mesh castShadow position={[0, 5.6, 0]} rotation={[0, Math.PI / 2, 0]}>
          <boxGeometry args={[2, 0.4, 3.5]} />
          <meshStandardMaterial 
            color="#0f0f0f"
            roughness={0.2}
            metalness={0.92}
          />
        </mesh>
        
        {/* Sail front edge */}
        <mesh castShadow position={[-1.75, 3.5, 0]} rotation={[0, 0, Math.PI / 4]}>
          <boxGeometry args={[1, 4, 2]} />
          <meshStandardMaterial 
            color="#0a0a0a"
            roughness={0.25}
            metalness={0.9}
          />
        </mesh>
        
        {/* Windows/Bridge */}
        <mesh position={[-1.5, 4.2, 0]}>
          <boxGeometry args={[0.1, 0.6, 1.2]} />
          <meshStandardMaterial 
            color="#001a33"
            roughness={0.05}
            metalness={0.3}
            emissive="#003366"
            emissiveIntensity={0.4}
          />
        </mesh>
        
        {/* Navigation lights on sail */}
        <pointLight position={[0, 5.8, 1.2]} intensity={2} color="#00ff00" distance={10} />
        <pointLight position={[0, 5.8, -1.2]} intensity={2} color="#ff0000" distance={10} />
        
        {/* Light housings */}
        <mesh position={[0, 5.8, 1.2]}>
          <cylinderGeometry args={[0.15, 0.15, 0.2, 12]} />
          <meshStandardMaterial 
            color="#00ff00"
            emissive="#00ff00"
            emissiveIntensity={2}
          />
        </mesh>
        <mesh position={[0, 5.8, -1.2]}>
          <cylinderGeometry args={[0.15, 0.15, 0.2, 12]} />
          <meshStandardMaterial 
            color="#ff0000"
            emissive="#ff0000"
            emissiveIntensity={2}
          />
        </mesh>
      </group>
      
      {/* Periscopes and masts */}
      <group position={[-1.5, 5.8, 0]}>
        {/* Main periscope */}
        <mesh castShadow>
          <cylinderGeometry args={[0.12, 0.12, 2.5, 16]} />
          <meshStandardMaterial 
            color="#1a1a1a"
            roughness={0.15}
            metalness={0.95}
          />
        </mesh>
        <mesh position={[0, 1.4, 0]}>
          <boxGeometry args={[0.35, 0.25, 0.5]} />
          <meshStandardMaterial color="#1a1a1a" roughness={0.15} metalness={0.95} />
        </mesh>
        
        {/* Periscope lens */}
        <mesh position={[0, 1.4, 0.28]}>
          <cylinderGeometry args={[0.1, 0.1, 0.05, 16]} />
          <meshStandardMaterial 
            color="#0044aa" 
            roughness={0.05} 
            metalness={0.5}
            emissive="#0066cc"
            emissiveIntensity={0.5}
          />
        </mesh>
      </group>
      
      {/* Search periscope */}
      <mesh position={[-2.5, 5.8, 0.5]} castShadow>
        <cylinderGeometry args={[0.08, 0.08, 2.2, 12]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.2} metalness={0.94} />
      </mesh>
      
      {/* Radio/ESM mast */}
      <mesh position={[-2.8, 6.2, -0.5]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 1.8, 10]} />
        <meshStandardMaterial color="#0a0a0a" roughness={0.25} metalness={0.93} />
      </mesh>
      
      {/* Forward diving planes (retractable) */}
      <group position={[-7, 0, 0]}>
        <mesh position={[0, 0, 2.5]} rotation={[0, 0.1, 0]} castShadow>
          <boxGeometry args={[1.5, 0.2, 3]} />
          <meshStandardMaterial 
            color="#0f0f0f" 
            roughness={0.25} 
            metalness={0.9}
          />
        </mesh>
        <mesh position={[0, 0, -2.5]} rotation={[0, -0.1, 0]} castShadow>
          <boxGeometry args={[1.5, 0.2, 3]} />
          <meshStandardMaterial 
            color="#0f0f0f" 
            roughness={0.25} 
            metalness={0.9}
          />
        </mesh>
        
        {/* Plane edge stripes */}
        <mesh position={[0, 0, 2.5]} rotation={[0, 0.1, 0]}>
          <boxGeometry args={[0.15, 0.25, 3]} />
          <meshStandardMaterial color="#ff9900" roughness={0.3} metalness={0.85} />
        </mesh>
        <mesh position={[0, 0, -2.5]} rotation={[0, -0.1, 0]}>
          <boxGeometry args={[0.15, 0.25, 3]} />
          <meshStandardMaterial color="#ff9900" roughness={0.3} metalness={0.85} />
        </mesh>
      </group>
      
      {/* Aft control surfaces - X-configuration (typical for Scorpene) */}
      <group position={[11.5, 0, 0]} rotation={[0, 0, Math.PI / 4]}>
        {/* Upper right */}
        <mesh position={[0, 2.8, 0]} rotation={[0, 0.05, 0]} castShadow>
          <boxGeometry args={[0.8, 0.18, 2.5]} />
          <meshStandardMaterial color="#0f0f0f" roughness={0.25} metalness={0.9} />
        </mesh>
        {/* Lower right */}
        <mesh position={[0, -2.8, 0]} rotation={[0, -0.05, 0]} castShadow>
          <boxGeometry args={[0.8, 0.18, 2.5]} />
          <meshStandardMaterial color="#0f0f0f" roughness={0.25} metalness={0.9} />
        </mesh>
        {/* Upper left */}
        <mesh position={[0, 0, 2.8]} rotation={[0, 0.05, 0]} castShadow>
          <boxGeometry args={[0.8, 0.18, 2.5]} />
          <meshStandardMaterial color="#0f0f0f" roughness={0.25} metalness={0.9} />
        </mesh>
        {/* Lower left */}
        <mesh position={[0, 0, -2.8]} rotation={[0, -0.05, 0]} castShadow>
          <boxGeometry args={[0.8, 0.18, 2.5]} />
          <meshStandardMaterial color="#0f0f0f" roughness={0.25} metalness={0.9} />
        </mesh>
        
        {/* Warning stripes on control surfaces */}
        <mesh position={[0, 2.8, 0]} rotation={[0, 0.05, 0]}>
          <boxGeometry args={[0.2, 0.22, 0.5]} />
          <meshStandardMaterial color="#ff9900" roughness={0.3} metalness={0.85} />
        </mesh>
        <mesh position={[0, -2.8, 0]} rotation={[0, -0.05, 0]}>
          <boxGeometry args={[0.2, 0.22, 0.5]} />
          <meshStandardMaterial color="#ff9900" roughness={0.3} metalness={0.85} />
        </mesh>
      </group>
      
      {/* Propeller assembly */}
      <group ref={propellerRef} position={[12.5, 0, 0]} rotation={[0, 0, 0]}>
        {/* 7-blade pumpjet-style propeller */}
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <mesh 
            key={i}
            rotation={[0, 0, (Math.PI * 2 / 7) * i]}
            castShadow
          >
            <boxGeometry args={[2.2, 0.15, 0.08]} />
            <meshStandardMaterial 
              color="#1a1a1a" 
              metalness={0.96} 
              roughness={0.12}
            />
          </mesh>
        ))}
        
        {/* Propeller hub */}
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.45, 0.45, 0.4, 24]} />
          <meshStandardMaterial color="#0f0f0f" metalness={0.94} roughness={0.18} />
        </mesh>
        
        {/* Drive shaft */}
        <mesh position={[-0.8, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.22, 0.22, 1.6, 16]} />
          <meshStandardMaterial color="#0a0a0a" metalness={0.96} roughness={0.15} />
        </mesh>
        
        {/* Propeller shroud ring */}
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <torusGeometry args={[1.5, 0.12, 16, 32]} />
          <meshStandardMaterial color="#0a0a0a" metalness={0.92} roughness={0.2} />
        </mesh>
      </group>
      
      {/* Torpedo tubes - 6 tubes (typical Scorpene configuration) */}
      {[
        [-1.5, -1.2, -10],
        [0, -1.2, -10],
        [1.5, -1.2, -10],
        [-1.5, 0.2, -10],
        [0, 0.2, -10],
        [1.5, 0.2, -10],
      ].map((pos, i) => (
        <group key={`tube-${i}`}>
          <mesh position={pos as [number, number, number]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <cylinderGeometry args={[0.27, 0.27, 1.8, 20]} />
            <meshStandardMaterial 
              color="#000000" 
              roughness={0.5} 
              metalness={0.8}
            />
          </mesh>
          {/* Tube door */}
          <mesh position={[pos[0], pos[1], pos[2] - 1] as [number, number, number]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.24, 0.24, 0.08, 20]} />
            <meshStandardMaterial color="#0a0a0a" roughness={0.4} metalness={0.9} />
          </mesh>
        </group>
      ))}
      
      {/* Bow navigation light */}
      <pointLight position={[-12, 0, 0]} intensity={4} color="#ffffff" distance={20} />
      <mesh position={[-12, 0, 0]}>
        <sphereGeometry args={[0.2, 12, 12]} />
        <meshStandardMaterial 
          color="#ffffff"
          emissive="#ffffff"
          emissiveIntensity={3}
        />
      </mesh>
      
      {/* Hull identification - Indian Navy style */}
      <mesh position={[-4, 0, 1.9]}>
        <boxGeometry args={[2.5, 0.02, 0.6]} />
        <meshStandardMaterial 
          color="#ffffff"
          roughness={0.6}
          metalness={0.3}
          emissive="#ffffff"
          emissiveIntensity={0.1}
        />
      </mesh>
      
      {/* S5 marking */}
      <mesh position={[-4, 0, -1.9]}>
        <boxGeometry args={[1.5, 0.02, 0.5]} />
        <meshStandardMaterial 
          color="#ffffff"
          roughness={0.6}
          metalness={0.3}
          emissive="#ffffff"
          emissiveIntensity={0.1}
        />
      </mesh>
      
      {/* Anchor points and deck fittings */}
      {[-8, -5, -2, 2, 5, 8].map((x, i) => (
        <mesh key={`fitting-${i}`} position={[x, 1.9, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
          <torusGeometry args={[0.12, 0.05, 10, 12]} />
          <meshStandardMaterial color="#666666" roughness={0.4} metalness={0.85} />
        </mesh>
      ))}
      
      {/* Snorkel mast (retracted) */}
      <mesh position={[-3.2, 3.5, 0.3]} castShadow>
        <cylinderGeometry args={[0.08, 0.08, 2, 12]} />
        <meshStandardMaterial color="#0a0a0a" roughness={0.3} metalness={0.9} />
      </mesh>
    </group>
  );
}
