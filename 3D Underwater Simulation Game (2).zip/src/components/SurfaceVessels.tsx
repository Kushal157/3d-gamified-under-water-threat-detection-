import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function CargoShip({ position, id }: { position: [number, number, number]; id: number }) {
  const shipRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (shipRef.current) {
      const time = state.clock.getElapsedTime();
      
      // Realistic bobbing motion
      shipRef.current.position.y = position[1] + Math.sin(time * 0.5 + id) * 0.4;
      
      // Rocking motion (pitch and roll)
      shipRef.current.rotation.x = Math.sin(time * 0.6 + id) * 0.08;
      shipRef.current.rotation.z = Math.sin(time * 0.4 + id) * 0.06;
      
      // Slight forward drift
      shipRef.current.position.x = position[0] + Math.sin(time * 0.1 + id) * 3;
    }
  });

  return (
    <group ref={shipRef} position={position}>
      {/* Main hull */}
      <mesh castShadow receiveShadow>
        <boxGeometry args={[12, 4, 5]} />
        <meshStandardMaterial 
          color="#8b4513"
          roughness={0.7}
          metalness={0.3}
        />
      </mesh>
      
      {/* Bow */}
      <mesh position={[-6.5, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <coneGeometry args={[2.5, 2, 4]} />
        <meshStandardMaterial color="#7a3a0f" roughness={0.7} metalness={0.3} />
      </mesh>
      
      {/* Deck */}
      <mesh position={[0, 2.2, 0]} castShadow>
        <boxGeometry args={[11.5, 0.4, 4.8]} />
        <meshStandardMaterial color="#6a2a0a" roughness={0.8} />
      </mesh>
      
      {/* Cargo containers */}
      {Array.from({ length: 12 }).map((_, i) => {
        const x = (i % 4) * 2.5 - 3.5;
        const y = Math.floor(i / 4) * 2.5 + 3;
        const colors = ['#c41e3a', '#0051ba', '#00a86b', '#ff8c00'];
        return (
          <mesh key={i} position={[x, y, 0]} castShadow>
            <boxGeometry args={[2, 2, 4]} />
            <meshStandardMaterial 
              color={colors[i % 4]}
              roughness={0.6}
              metalness={0.4}
            />
          </mesh>
        );
      })}
      
      {/* Superstructure */}
      <mesh position={[4, 4, 0]} castShadow>
        <boxGeometry args={[3, 4, 4]} />
        <meshStandardMaterial color="#e8e8e8" roughness={0.5} metalness={0.5} />
      </mesh>
      
      {/* Bridge windows */}
      <mesh position={[4, 5, 2.1]}>
        <boxGeometry args={[2.5, 1.5, 0.1]} />
        <meshStandardMaterial 
          color="#001a33"
          emissive="#ffcc00"
          emissiveIntensity={0.6}
          roughness={0.1}
        />
      </mesh>
      
      {/* Smokestack */}
      <mesh position={[3, 7, 0]} castShadow>
        <cylinderGeometry args={[0.6, 0.7, 2.5, 16]} />
        <meshStandardMaterial color="#cc0000" roughness={0.4} metalness={0.6} />
      </mesh>
      
      {/* Smoke effect */}
      <mesh position={[3, 8.5, 0]}>
        <sphereGeometry args={[0.8, 8, 8]} />
        <meshStandardMaterial 
          color="#555555"
          transparent
          opacity={0.3}
        />
      </mesh>
      
      {/* Navigation lights */}
      <pointLight position={[-6, 3, 2.5]} intensity={2} color="#00ff00" distance={15} />
      <pointLight position={[-6, 3, -2.5]} intensity={2} color="#ff0000" distance={15} />
      
      {/* Wake effect */}
      <mesh position={[7, -2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <coneGeometry args={[3, 6, 8]} />
        <meshStandardMaterial 
          color="#ffffff"
          transparent
          opacity={0.4}
        />
      </mesh>
    </group>
  );
}

function Destroyer({ position, id }: { position: [number, number, number]; id: number }) {
  const shipRef = useRef<THREE.Group>(null);
  const radarRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (shipRef.current) {
      const time = state.clock.getElapsedTime();
      shipRef.current.position.y = position[1] + Math.sin(time * 0.6 + id) * 0.35;
      shipRef.current.rotation.x = Math.sin(time * 0.7 + id) * 0.06;
      shipRef.current.rotation.z = Math.sin(time * 0.5 + id) * 0.05;
      shipRef.current.position.z = position[2] + Math.sin(time * 0.15 + id) * 4;
    }
    
    // Rotate radar
    if (radarRef.current) {
      radarRef.current.rotation.y = state.clock.getElapsedTime();
    }
  });

  return (
    <group ref={shipRef} position={position}>
      {/* Hull */}
      <mesh castShadow receiveShadow>
        <boxGeometry args={[10, 3, 4]} />
        <meshStandardMaterial 
          color="#4a5568"
          roughness={0.4}
          metalness={0.7}
        />
      </mesh>
      
      {/* Bow */}
      <mesh position={[-5.5, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <coneGeometry args={[2, 2, 4]} />
        <meshStandardMaterial color="#3a4558" roughness={0.4} metalness={0.7} />
      </mesh>
      
      {/* Deck */}
      <mesh position={[0, 1.7, 0]} castShadow>
        <boxGeometry args={[9.5, 0.3, 3.8]} />
        <meshStandardMaterial color="#5a6578" roughness={0.5} metalness={0.6} />
      </mesh>
      
      {/* Main gun turret */}
      <group position={[-3, 2.5, 0]}>
        <mesh castShadow>
          <cylinderGeometry args={[0.8, 1, 1, 16]} />
          <meshStandardMaterial color="#2a3548" roughness={0.3} metalness={0.8} />
        </mesh>
        <mesh position={[0, 0.5, 0.8]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.2, 0.2, 2.5, 12]} />
          <meshStandardMaterial color="#1a2538" roughness={0.2} metalness={0.9} />
        </mesh>
      </group>
      
      {/* Superstructure */}
      <mesh position={[1, 3.5, 0]} castShadow>
        <boxGeometry args={[4, 3, 3.5]} />
        <meshStandardMaterial color="#e8e8e8" roughness={0.4} metalness={0.6} />
      </mesh>
      
      {/* Radar mast */}
      <mesh position={[1, 6, 0]} castShadow>
        <cylinderGeometry args={[0.2, 0.2, 2, 12]} />
        <meshStandardMaterial color="#4a5568" roughness={0.3} metalness={0.8} />
      </mesh>
      
      {/* Rotating radar */}
      <mesh ref={radarRef} position={[1, 7.2, 0]}>
        <boxGeometry args={[2, 0.1, 0.3]} />
        <meshStandardMaterial 
          color="#00ff00"
          emissive="#00ff00"
          emissiveIntensity={1}
        />
      </mesh>
      
      {/* Lights */}
      <pointLight position={[-5, 2, 2]} intensity={2} color="#00ff00" distance={12} />
      <pointLight position={[-5, 2, -2]} intensity={2} color="#ff0000" distance={12} />
    </group>
  );
}

export function SurfaceVessels() {
  return (
    <group>
      <CargoShip position={[-40, 2, -30]} id={0} />
      <CargoShip position={[50, 2, 40]} id={1} />
      <Destroyer position={[30, 2, -50]} id={2} />
      <Destroyer position={[-50, 2, 50]} id={3} />
    </group>
  );
}
