import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function Shipwreck({ position, rotation, scale }: { position: [number, number, number]; rotation: [number, number, number]; scale: number }) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      // Subtle swaying
      groupRef.current.rotation.x = rotation[0] + Math.sin(state.clock.getElapsedTime() * 0.2) * 0.01;
    }
  });

  return (
    <group ref={groupRef} position={position} rotation={rotation} scale={scale}>
      {/* Main hull */}
      <mesh castShadow receiveShadow>
        <boxGeometry args={[8, 3, 20]} />
        <meshStandardMaterial 
          color="#3a2a1a"
          roughness={0.9}
          metalness={0.1}
        />
      </mesh>
      
      {/* Broken deck */}
      <mesh position={[0, 1.6, 0]} rotation={[0, 0, 0.1]} castShadow>
        <boxGeometry args={[7.5, 0.3, 18]} />
        <meshStandardMaterial 
          color="#2a1a0a"
          roughness={0.95}
        />
      </mesh>
      
      {/* Broken mast */}
      <mesh position={[0, 2, -5]} rotation={[0.3, 0, 0.2]} castShadow>
        <cylinderGeometry args={[0.3, 0.4, 8, 8]} />
        <meshStandardMaterial 
          color="#1a1a1a"
          roughness={0.8}
        />
      </mesh>
      
      {/* Cargo containers (rusted) */}
      {Array.from({ length: 6 }).map((_, i) => {
        const x = ((i % 2) - 0.5) * 3;
        const z = (Math.floor(i / 2) - 1) * 4;
        return (
          <mesh key={i} position={[x, 2.5, z]} rotation={[0, Math.random() * 0.3, Math.random() * 0.2]} castShadow>
            <boxGeometry args={[2, 2, 3]} />
            <meshStandardMaterial 
              color={i % 2 === 0 ? "#8b4513" : "#a0522d"}
              roughness={0.9}
              metalness={0.2}
            />
          </mesh>
        );
      })}
      
      {/* Debris */}
      {Array.from({ length: 10 }).map((_, i) => {
        const angle = (i / 10) * Math.PI * 2;
        const dist = 3 + Math.random() * 4;
        const x = Math.cos(angle) * dist;
        const z = Math.sin(angle) * dist;
        return (
          <mesh 
            key={`debris-${i}`}
            position={[x, -1 + Math.random() * 0.5, z]} 
            rotation={[Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI]}
            castShadow
          >
            <boxGeometry args={[0.5 + Math.random(), 0.5 + Math.random(), 0.5 + Math.random()]} />
            <meshStandardMaterial 
              color="#2a2a2a"
              roughness={0.9}
            />
          </mesh>
        );
      })}
      
      {/* Coral growth on wreck */}
      {Array.from({ length: 15 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 8;
        const z = (Math.random() - 0.5) * 20;
        return (
          <mesh key={`coral-${i}`} position={[x, -1.5, z]} castShadow>
            <coneGeometry args={[0.2 + Math.random() * 0.3, 0.5 + Math.random() * 1, 6]} />
            <meshStandardMaterial 
              color={['#ff6b6b', '#4ecdc4', '#45b7d1'][Math.floor(Math.random() * 3)]}
              roughness={0.6}
              emissive={['#ff6b6b', '#4ecdc4', '#45b7d1'][Math.floor(Math.random() * 3)]}
              emissiveIntensity={0.1}
            />
          </mesh>
        );
      })}
      
      {/* Barnacles */}
      {Array.from({ length: 20 }).map((_, i) => {
        const x = (Math.random() - 0.5) * 8;
        const y = Math.random() * 3 - 1.5;
        const z = (Math.random() - 0.5) * 20;
        return (
          <mesh key={`barnacle-${i}`} position={[x, y, z]}>
            <sphereGeometry args={[0.1, 6, 6]} />
            <meshStandardMaterial color="#e8d5c4" roughness={0.9} />
          </mesh>
        );
      })}
    </group>
  );
}

export function Shipwrecks() {
  return (
    <group>
      {/* Large shipwreck */}
      <Shipwreck 
        position={[-50, -33, 30]} 
        rotation={[0.2, 0.5, 0.1]}
        scale={1.2}
      />
      
      {/* Medium shipwreck */}
      <Shipwreck 
        position={[45, -32, -50]} 
        rotation={[0.1, -0.8, -0.15]}
        scale={0.8}
      />
      
      {/* Small boat wreck */}
      <group position={[25, -34, 40]} rotation={[0.3, 1.2, 0.2]} scale={0.4}>
        <mesh castShadow>
          <boxGeometry args={[4, 1.5, 8]} />
          <meshStandardMaterial color="#4a3a2a" roughness={0.95} />
        </mesh>
        <mesh position={[0, 0.8, -2]} castShadow>
          <boxGeometry args={[2, 1, 3]} />
          <meshStandardMaterial color="#3a2a1a" roughness={0.95} />
        </mesh>
      </group>
    </group>
  );
}
