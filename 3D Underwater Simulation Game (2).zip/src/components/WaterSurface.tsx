import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export function WaterSurface() {
  const waterRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.MeshStandardMaterial>(null);

  useFrame((state) => {
    if (waterRef.current) {
      const time = state.clock.getElapsedTime();
      const positions = waterRef.current.geometry.attributes.position;
      
      // Create realistic wave patterns
      for (let i = 0; i < positions.count; i++) {
        const x = positions.getX(i);
        const y = positions.getY(i);
        
        // Multiple wave frequencies for realistic ocean
        const wave1 = Math.sin(x * 0.2 + time * 0.8) * 0.3;
        const wave2 = Math.sin(y * 0.15 + time * 0.6) * 0.4;
        const wave3 = Math.sin((x + y) * 0.1 + time * 0.5) * 0.25;
        const wave4 = Math.sin((x - y) * 0.08 + time * 0.4) * 0.2;
        
        positions.setZ(i, wave1 + wave2 + wave3 + wave4);
      }
      
      positions.needsUpdate = true;
      waterRef.current.geometry.computeVertexNormals();
    }
    
    // Animate water shimmer
    if (materialRef.current) {
      materialRef.current.emissiveIntensity = 0.15 + Math.sin(state.clock.getElapsedTime() * 0.5) * 0.05;
    }
  });

  return (
    <mesh 
      ref={waterRef}
      position={[0, 0, 0]} 
      rotation={[-Math.PI / 2, 0, 0]}
      receiveShadow
    >
      <planeGeometry args={[200, 200, 128, 128]} />
      <meshStandardMaterial 
        ref={materialRef}
        color="#0a4d6e"
        transparent
        opacity={0.85}
        roughness={0.1}
        metalness={0.8}
        emissive="#0a3d5e"
        emissiveIntensity={0.15}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}
