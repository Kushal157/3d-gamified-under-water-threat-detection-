import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Text } from '@react-three/drei';

interface DetectedThreat {
  id: number;
  type: string;
  position: [number, number, number];
  distance: string;
  confidence: string;
  threat: number;
}

interface ThreatVisualizerProps {
  threats: DetectedThreat[];
  isVisualizationActive: boolean;
}

function ThreatMarker({ 
  threat, 
  index 
}: { 
  threat: DetectedThreat; 
  index: number;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const boxRef = useRef<THREE.Mesh>(null);
  const pulseRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    
    if (groupRef.current) {
      // Gentle floating animation
      groupRef.current.position.y = threat.position[1] + Math.sin(time * 1.5 + index) * 0.3;
    }

    if (boxRef.current) {
      // Subtle rotation
      boxRef.current.rotation.y = time * 0.5;
    }

    if (pulseRef.current) {
      // Pulsing effect
      const pulse = 1 + Math.sin(time * 3 + index) * 0.3;
      pulseRef.current.scale.setScalar(pulse);
      pulseRef.current.material.opacity = 0.15 + Math.sin(time * 2 + index) * 0.1;
    }
  });

  const getThreatColor = (type: string): string => {
    switch (type) {
      case 'submarine': return '#ff3333';
      case 'mine': return '#ff8800';
      case 'torpedo': return '#ff0000';
      case 'drone': return '#ffaa00';
      default: return '#ffff00';
    }
  };

  const getThreatIcon = (type: string) => {
    const color = getThreatColor(type);
    
    switch (type) {
      case 'submarine':
        return (
          <mesh castShadow>
            <capsuleGeometry args={[0.6, 2.5, 8, 16]} />
            <meshStandardMaterial 
              color={color}
              emissive={color}
              emissiveIntensity={0.8}
              roughness={0.3}
              metalness={0.8}
            />
          </mesh>
        );
      case 'mine':
        return (
          <mesh castShadow>
            <icosahedronGeometry args={[1, 1]} />
            <meshStandardMaterial 
              color={color}
              emissive={color}
              emissiveIntensity={0.8}
              roughness={0.3}
              metalness={0.8}
            />
          </mesh>
        );
      case 'torpedo':
        return (
          <mesh castShadow rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.4, 0.4, 2.5, 12]} />
            <meshStandardMaterial 
              color={color}
              emissive={color}
              emissiveIntensity={0.8}
              roughness={0.3}
              metalness={0.8}
            />
          </mesh>
        );
      case 'drone':
        return (
          <mesh castShadow>
            <octahedronGeometry args={[0.9, 0]} />
            <meshStandardMaterial 
              color={color}
              emissive={color}
              emissiveIntensity={0.8}
              roughness={0.3}
              metalness={0.8}
            />
          </mesh>
        );
      default:
        return (
          <mesh castShadow>
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial 
              color={color}
              emissive={color}
              emissiveIntensity={0.8}
            />
          </mesh>
        );
    }
  };

  const color = getThreatColor(threat.type);
  const bboxSize = useMemo(() => {
    switch (threat.type) {
      case 'submarine': return [4, 3, 3] as [number, number, number];
      case 'mine': return [2.5, 2.5, 2.5] as [number, number, number];
      case 'torpedo': return [3.5, 2, 2] as [number, number, number];
      case 'drone': return [2.5, 2.5, 2.5] as [number, number, number];
      default: return [3, 3, 3] as [number, number, number];
    }
  }, [threat.type]);

  return (
    <group 
      ref={groupRef} 
      position={[threat.position[0], threat.position[1], threat.position[2]]}
    >
      {/* Bounding Box */}
      <lineSegments>
        <edgesGeometry args={[new THREE.BoxGeometry(...bboxSize)]} />
        <lineBasicMaterial color={color} linewidth={2} />
      </lineSegments>

      {/* Corner markers */}
      {[
        [-bboxSize[0]/2, bboxSize[1]/2, bboxSize[2]/2],
        [bboxSize[0]/2, bboxSize[1]/2, bboxSize[2]/2],
        [-bboxSize[0]/2, -bboxSize[1]/2, bboxSize[2]/2],
        [bboxSize[0]/2, -bboxSize[1]/2, bboxSize[2]/2],
      ].map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]}>
          <sphereGeometry args={[0.15, 8, 8]} />
          <meshBasicMaterial color={color} />
        </mesh>
      ))}

      {/* Central threat indicator */}
      <group ref={boxRef}>
        {getThreatIcon(threat.type)}
      </group>

      {/* Pulsing sphere */}
      <mesh ref={pulseRef}>
        <sphereGeometry args={[2.5, 16, 16]} />
        <meshBasicMaterial 
          color={color}
          transparent
          opacity={0.15}
          side={THREE.BackSide}
        />
      </mesh>

      {/* Warning beacon on top */}
      <mesh position={[0, bboxSize[1]/2 + 1.5, 0]}>
        <coneGeometry args={[0.4, 1.2, 4]} />
        <meshBasicMaterial 
          color={color}
          transparent
          opacity={0.9}
        />
      </mesh>

      {/* Connecting line to beacon */}
      <mesh position={[0, bboxSize[1]/2 + 0.5, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 1, 8]} />
        <meshBasicMaterial color={color} opacity={0.5} transparent />
      </mesh>

      {/* Point light for glow */}
      <pointLight 
        color={color} 
        intensity={3} 
        distance={10} 
        decay={2}
      />

      {/* Threat Information Label */}
      <group position={[0, bboxSize[1]/2 + 2.5, 0]}>
        <Text
          position={[0, 0.8, 0]}
          fontSize={0.5}
          color={color}
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.05}
          outlineColor="#000000"
        >
          {threat.type.toUpperCase()}
        </Text>
        <Text
          position={[0, 0.2, 0]}
          fontSize={0.35}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.03}
          outlineColor="#000000"
        >
          ID: {threat.id}
        </Text>
        <Text
          position={[0, -0.3, 0]}
          fontSize={0.35}
          color="#00ffff"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.03}
          outlineColor="#000000"
        >
          {threat.distance}m
        </Text>
        <Text
          position={[0, -0.8, 0]}
          fontSize={0.35}
          color="#00ff00"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.03}
          outlineColor="#000000"
        >
          {threat.confidence}% CONF
        </Text>
      </group>

      {/* Scanning grid effect */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -bboxSize[1]/2 - 0.1, 0]}>
        <ringGeometry args={[0, 3, 32, 1]} />
        <meshBasicMaterial 
          color={color}
          transparent
          opacity={0.3}
          wireframe
        />
      </mesh>
    </group>
  );
}

export function ThreatVisualizer({ threats, isVisualizationActive }: ThreatVisualizerProps) {
  if (!isVisualizationActive || threats.length === 0) {
    return null;
  }

  return (
    <group>
      {threats.map((threat, index) => (
        <ThreatMarker 
          key={threat.id} 
          threat={threat} 
          index={index}
        />
      ))}
    </group>
  );
}
