import { jsPDF } from 'jspdf';
import { FileText } from 'lucide-react';
import { Button } from './ui/button';

interface ThreatData {
  id: string | number;
  type: string;
  position: [number, number, number];
  distance: string;
  confidence: string;
  threatLevel: string;
}

interface ScanParameters {
  direction: string;
  range: number;
  sensitivity: number;
  submarinePosition: [number, number, number];
}

interface PDFReportGeneratorProps {
  threats: ThreatData[];
  scanParams: ScanParameters;
  disabled?: boolean;
}

export function PDFReportGenerator({ threats, scanParams, disabled }: PDFReportGeneratorProps) {
  const generateReport = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    
    // Title
    doc.setFillColor(0, 50, 100);
    doc.rect(0, 0, pageWidth, 35, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.text('THREAT DETECTION REPORT', pageWidth / 2, 15, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text('Indian Navy - INS Vagir (S5)', pageWidth / 2, 25, { align: 'center' });
    
    // Classification
    doc.setFontSize(10);
    doc.setTextColor(255, 200, 0);
    doc.text('CLASSIFIED - NAVAL OPERATIONS', pageWidth / 2, 32, { align: 'center' });
    
    // Reset text color
    doc.setTextColor(0, 0, 0);
    
    // Report Details
    let yPos = 50;
    
    // Timestamp Section
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('SCAN TIMESTAMP', 15, yPos);
    yPos += 8;
    
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    const timestamp = new Date().toLocaleString('en-IN', { 
      timeZone: 'Asia/Kolkata',
      dateStyle: 'full',
      timeStyle: 'long'
    });
    doc.text(`Date/Time: ${timestamp}`, 20, yPos);
    yPos += 15;
    
    // Submarine Position
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('SUBMARINE COORDINATES', 15, yPos);
    yPos += 8;
    
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text(`X: ${scanParams.submarinePosition[0].toFixed(2)}m`, 20, yPos);
    yPos += 6;
    doc.text(`Y: ${scanParams.submarinePosition[1].toFixed(2)}m (Depth)`, 20, yPos);
    yPos += 6;
    doc.text(`Z: ${scanParams.submarinePosition[2].toFixed(2)}m`, 20, yPos);
    yPos += 15;
    
    // Scan Parameters
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('SCAN PARAMETERS', 15, yPos);
    yPos += 8;
    
    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text(`Direction: ${scanParams.direction.toUpperCase()}`, 20, yPos);
    yPos += 6;
    doc.text(`Detection Range: ${scanParams.range}m`, 20, yPos);
    yPos += 6;
    doc.text(`AI Sensitivity: ${(scanParams.sensitivity * 100).toFixed(0)}%`, 20, yPos);
    yPos += 6;
    doc.text(`YOLOv8 Model Version: v8.2-naval`, 20, yPos);
    yPos += 15;
    
    // Threats Detected
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    if (threats.length > 0) {
      doc.setTextColor(200, 0, 0);
    } else {
      doc.setTextColor(0, 150, 0);
    }
    doc.text(`THREATS DETECTED: ${threats.length}`, 15, yPos);
    doc.setTextColor(0, 0, 0);
    yPos += 10;
    
    if (threats.length > 0) {
      // Table Header
      doc.setFillColor(230, 230, 230);
      doc.rect(15, yPos - 5, pageWidth - 30, 8, 'F');
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text('ID', 20, yPos);
      doc.text('Type', 40, yPos);
      doc.text('Distance', 85, yPos);
      doc.text('Confidence', 120, yPos);
      doc.text('Threat Level', 155, yPos);
      yPos += 8;
      
      // Table Rows
      doc.setFont('helvetica', 'normal');
      threats.forEach((threat, index) => {
        if (yPos > pageHeight - 30) {
          doc.addPage();
          yPos = 20;
        }
        
        // Alternate row colors
        if (index % 2 === 0) {
          doc.setFillColor(250, 250, 250);
          doc.rect(15, yPos - 5, pageWidth - 30, 7, 'F');
        }
        
        // Threat level color
        const threatLevel = threat.threatLevel.toUpperCase();
        if (threatLevel === 'CRITICAL' || threatLevel === 'HIGH') {
          doc.setTextColor(200, 0, 0);
        } else if (threatLevel === 'MEDIUM') {
          doc.setTextColor(200, 100, 0);
        } else {
          doc.setTextColor(0, 0, 0);
        }
        
        doc.text(`#${threat.id}`, 20, yPos);
        doc.text(threat.type.toUpperCase(), 40, yPos);
        doc.text(`${threat.distance}m`, 85, yPos);
        doc.text(`${threat.confidence}%`, 120, yPos);
        doc.text(threatLevel, 155, yPos);
        
        doc.setTextColor(0, 0, 0);
        yPos += 7;
      });
      
      yPos += 10;
      
      // Visual Map Section
      if (yPos > pageHeight - 80) {
        doc.addPage();
        yPos = 20;
      }
      
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('TACTICAL SITUATION MAP', 15, yPos);
      yPos += 10;
      
      // Draw map
      const mapSize = 100;
      const mapX = (pageWidth - mapSize) / 2;
      const mapY = yPos;
      
      // Map background
      doc.setFillColor(200, 220, 240);
      doc.rect(mapX, mapY, mapSize, mapSize, 'F');
      
      // Grid lines
      doc.setDrawColor(150, 150, 150);
      doc.setLineWidth(0.3);
      for (let i = 0; i <= 4; i++) {
        const pos = mapX + (i * mapSize / 4);
        doc.line(pos, mapY, pos, mapY + mapSize);
        doc.line(mapX, mapY + (i * mapSize / 4), mapX + mapSize, mapY + (i * mapSize / 4));
      }
      
      // Submarine position (center)
      doc.setFillColor(0, 100, 200);
      doc.circle(mapX + mapSize / 2, mapY + mapSize / 2, 3, 'F');
      doc.setFontSize(8);
      doc.text('SUB', mapX + mapSize / 2 - 5, mapY + mapSize / 2 + 8);
      
      // Detection range circle
      const rangeScale = (scanParams.range / 100) * (mapSize / 2);
      doc.setDrawColor(0, 150, 255);
      doc.setLineWidth(0.8);
      doc.circle(mapX + mapSize / 2, mapY + mapSize / 2, rangeScale, 'S');
      
      // Plot threats
      threats.forEach((threat) => {
        const relX = threat.position[0] - scanParams.submarinePosition[0];
        const relZ = threat.position[2] - scanParams.submarinePosition[2];
        
        const plotX = mapX + mapSize / 2 + (relX / 100) * (mapSize / 2);
        const plotY = mapY + mapSize / 2 + (relZ / 100) * (mapSize / 2);
        
        // Only plot if within map bounds
        if (plotX >= mapX && plotX <= mapX + mapSize && plotY >= mapY && plotY <= mapY + mapSize) {
          const threatLevel = threat.threatLevel.toUpperCase();
          if (threatLevel === 'CRITICAL' || threatLevel === 'HIGH') {
            doc.setFillColor(255, 0, 0);
          } else if (threatLevel === 'MEDIUM') {
            doc.setFillColor(255, 165, 0);
          } else {
            doc.setFillColor(255, 255, 0);
          }
          
          doc.circle(plotX, plotY, 2, 'F');
          doc.setFontSize(6);
          doc.setTextColor(0, 0, 0);
          doc.text(`#${threat.id}`, plotX - 2, plotY - 3);
        }
      });
      
      yPos = mapY + mapSize + 10;
      
      // Map Legend
      doc.setFontSize(8);
      doc.setTextColor(0, 0, 0);
      doc.text('Legend:', mapX, yPos);
      yPos += 5;
      
      doc.setFillColor(0, 100, 200);
      doc.circle(mapX + 5, yPos - 1, 1.5, 'F');
      doc.text('Submarine', mapX + 10, yPos);
      yPos += 5;
      
      doc.setFillColor(255, 0, 0);
      doc.circle(mapX + 5, yPos - 1, 1.5, 'F');
      doc.text('High Threat', mapX + 10, yPos);
      
      doc.setFillColor(255, 165, 0);
      doc.circle(mapX + 45, yPos - 1, 1.5, 'F');
      doc.text('Medium Threat', mapX + 50, yPos);
      
      doc.setFillColor(255, 255, 0);
      doc.circle(mapX + 95, yPos - 1, 1.5, 'F');
      doc.text('Low Threat', mapX + 100, yPos);
      
      yPos += 10;
    } else {
      doc.setFontSize(11);
      doc.setTextColor(0, 150, 0);
      doc.text('No threats detected in scan zone.', 20, yPos);
      doc.setTextColor(0, 0, 0);
      yPos += 10;
    }
    
    // Footer
    const footerY = pageHeight - 20;
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    doc.text(`Generated by YOLOv8 Threat Detection System`, pageWidth / 2, footerY, { align: 'center' });
    doc.text(`Report ID: ${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`, pageWidth / 2, footerY + 5, { align: 'center' });
    doc.text(`Page 1 of ${doc.getNumberOfPages()}`, pageWidth / 2, footerY + 10, { align: 'center' });
    
    // Classification footer
    doc.setTextColor(200, 0, 0);
    doc.setFontSize(9);
    doc.text('CLASSIFIED - FOR AUTHORIZED PERSONNEL ONLY', pageWidth / 2, footerY + 15, { align: 'center' });
    
    // Save PDF
    const filename = `Threat_Report_${new Date().toISOString().split('T')[0]}_${Date.now()}.pdf`;
    doc.save(filename);
  };

  return (
    <Button
      onClick={generateReport}
      disabled={disabled || threats.length === 0}
      className="bg-blue-600 hover:bg-blue-700 text-white"
    >
      <FileText className="w-4 h-4 mr-2" />
      Generate PDF Report
    </Button>
  );
}
