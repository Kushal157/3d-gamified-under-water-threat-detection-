import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface SonarRangeVisualizerProps {
  submarinePosition: [number, number, number];
  range: number;
  direction: 'north' | 'south' | 'east' | 'west' | 'all';
  isActive: boolean;
}

export function SonarRangeVisualizer({ submarinePosition, range, direction, isActive }: SonarRangeVisualizerProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.MeshBasicMaterial>(null);
  
  useFrame((state) => {
    if (meshRef.current && materialRef.current && isActive) {
      // Pulsing opacity
      materialRef.current.opacity = 0.15 + Math.sin(state.clock.getElapsedTime() * 2) * 0.1;
    }
  });
  
  if (!isActive) return null;
  
  // Calculate visualization based on direction
  let geometry: THREE.BufferGeometry;
  let rotation: [number, number, number] = [Math.PI / 2, 0, 0];
  
  if (direction === 'all') {
    // Full circle
    geometry = new THREE.CircleGeometry(range, 64);
  } else {
    // Arc for directional scan
    const startAngle = {
      north: -Math.PI / 4,
      south: Math.PI * 3 / 4,
      east: Math.PI / 4,
      west: -Math.PI * 3 / 4
    }[direction];
    
    geometry = new THREE.CircleGeometry(range, 32, startAngle, Math.PI / 2);
  }
  
  return (
    <group position={submarinePosition}>
      <mesh
        ref={meshRef}
        rotation={rotation}
        position={[0, 0.5, 0]}
      >
        <primitive object={geometry} />
        <meshBasicMaterial
          ref={materialRef}
          color="#00ffff"
          transparent
          opacity={0.2}
          side={THREE.DoubleSide}
          depthWrite={false}
        />
      </mesh>
      
      {/* Range circle outline */}
      <lineLoop position={[0, 0.5, 0]} rotation={rotation}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={64}
            array={new Float32Array(
              Array.from({ length: 64 }, (_, i) => {
                const angle = (i / 64) * Math.PI * 2;
                return [
                  Math.cos(angle) * range,
                  Math.sin(angle) * range,
                  0
                ];
              }).flat()
            )}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#00ffff" transparent opacity={0.4} />
      </lineLoop>
    </group>
  );
}
