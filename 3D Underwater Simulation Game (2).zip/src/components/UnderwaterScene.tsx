import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import { Suspense, useEffect, useState } from 'react';
import { OceanFloor } from './OceanFloor';
import { SonarPulse } from './SonarPulse';
import { ThreatObjects } from './ThreatObjects';
import { MovableSubmarine } from './MovableSubmarine';
import { WaterSurface } from './WaterSurface';
import { MarineLife } from './MarineLife';
import { SurfaceVessels } from './SurfaceVessels';
import { TetheredMines } from './TetheredMines';
import { Shipwrecks } from './Shipwrecks';
import { Divers } from './Divers';
import { ThreatVisualizer } from './ThreatVisualizer';
import { SonarRangeVisualizer } from './SonarRangeVisualizer';
import { SubmarineWaterEffects } from './SubmarineWaterEffects';
import { yoloDetector } from './YOLOv8Detector';
import type { DynamicThreat } from './DynamicEnvironmentManager';

interface UnderwaterSceneProps {
  isScanning: boolean;
  detectionRange: number;
  aiSensitivity: number;
  scanDirection: 'north' | 'south' | 'east' | 'west' | 'all';
  onThreatsDetected: (threats: any[]) => void;
  sonarPulseActive: boolean;
  isVisualizationActive: boolean;
  detectedThreats: any[];
  submarinePosition: [number, number, number];
  submarineRotation: number;
  submarineVelocity?: [number, number, number];
  dynamicThreats: DynamicThreat[];
  dynamicMines: { id: number; position: [number, number, number] }[];
}

export function UnderwaterScene({ 
  isScanning, 
  detectionRange, 
  aiSensitivity,
  scanDirection,
  onThreatsDetected,
  sonarPulseActive,
  isVisualizationActive,
  detectedThreats,
  submarinePosition,
  submarineRotation,
  submarineVelocity,
  dynamicThreats,
  dynamicMines
}: UnderwaterSceneProps) {
  useEffect(() => {
    if (isScanning) {
      // Use YOLOv8 detector for AI-powered threat detection with dynamic threats
      yoloDetector.detectThreats(
        dynamicThreats,
        dynamicMines,
        detectionRange,
        aiSensitivity,
        scanDirection,
        submarinePosition // Pass submarine position for relative detection
      ).then(result => {
        // Styled console logging
        console.log(
          '%c🤖 YOLOv8 Detection Complete',
          'background: #7c3aed; color: white; padding: 8px 12px; border-radius: 4px; font-weight: bold;'
        );
        console.log(
          '%c⚡ Processing Time: ' + result.processingTime + 'ms',
          'color: #fbbf24; font-weight: bold;'
        );
        console.log(
          '%c📊 Model: ' + result.modelVersion,
          'color: #a78bfa; font-weight: bold;'
        );
        console.log(
          '%c🎯 Detections: ' + result.detections.length,
          'color: #34d399; font-weight: bold;'
        );
        
        if (result.detections.length > 0) {
          console.table(result.detections.map(d => ({
            ID: d.id,
            Class: d.class.toUpperCase(),
            Confidence: (d.confidence * 100).toFixed(1) + '%',
            'Threat Level': d.threatLevel.toUpperCase(),
            Position: `[${d.position.map(p => p.toFixed(1)).join(', ')}]`
          })));
        }
        
        const detectedThreats = result.detections.map(detection => ({
          id: detection.id,
          type: detection.class,
          position: detection.position,
          distance: Math.sqrt(
            detection.position[0] ** 2 + 
            detection.position[2] ** 2
          ).toFixed(1),
          confidence: (detection.confidence * 100).toFixed(1),
          threat: detection.confidence,
          bbox: detection.bbox,
          threatLevel: detection.threatLevel
        }));
        
        onThreatsDetected(detectedThreats);
      });
    }
  }, [isScanning, detectionRange, aiSensitivity, scanDirection, dynamicThreats, dynamicMines, onThreatsDetected, submarinePosition]);

  return (
    <Canvas shadows className="w-full h-full">
      <Suspense fallback={null}>
        <PerspectiveCamera makeDefault position={[0, 15, 50]} fov={60} />
        <OrbitControls 
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          minPolarAngle={0}
          maxPolarAngle={Math.PI}
          minDistance={20}
          maxDistance={150}
          target={[0, -10, 0]}
        />
        
        {/* Lighting - Enhanced for better visibility */}
        <ambientLight intensity={0.4} color="#87ceeb" />
        <directionalLight 
          position={[50, 50, 50]} 
          intensity={1.2} 
          color="#ffffff"
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={200}
          shadow-camera-left={-100}
          shadow-camera-right={100}
          shadow-camera-top={100}
          shadow-camera-bottom={-100}
        />
        <directionalLight 
          position={[-30, 40, -30]} 
          intensity={0.6} 
          color="#b0d4ff"
        />
        
        {/* Underwater lighting */}
        <pointLight position={[0, -5, 0]} intensity={1.5} color="#00aaff" distance={60} decay={2} />
        <pointLight position={[30, -15, -30]} intensity={0.8} color="#0088cc" distance={40} decay={2} />
        <pointLight position={[-30, -15, -30]} intensity={0.8} color="#0088cc" distance={40} decay={2} />
        
        {/* Fog for depth effect */}
        <fog attach="fog" args={['#1a4d6d', 30, 120]} />
        
        {/* Scene Components */}
        <WaterSurface />
        <OceanFloor />
        <MarineLife />
        <SurfaceVessels />
        <Shipwrecks />
        <Divers />
        
        {/* Player Submarine */}
        <MovableSubmarine 
          position={submarinePosition}
          rotation={submarineRotation}
          velocity={submarineVelocity}
        />
        
        {/* Submarine Water Effects */}
        <SubmarineWaterEffects
          position={submarinePosition}
          velocity={submarineVelocity}
          rotation={submarineRotation}
        />
        
        {/* Sonar System */}
        {sonarPulseActive && (
          <group position={submarinePosition}>
            <SonarPulse 
              isActive={isScanning} 
              range={detectionRange}
              direction={scanDirection}
            />
          </group>
        )}
        
        {/* Threat Submarines */}
        <ThreatObjects 
          threats={dynamicThreats} 
          isScanning={isScanning}
          detectionRange={detectionRange}
        />
        
        {/* Tethered Mines */}
        <TetheredMines 
          mines={dynamicMines}
          isScanning={isScanning}
          detectionRange={detectionRange}
        />
        
        {/* Threat Visualization - YOLOv8 Bounding Boxes & Labels */}
        <ThreatVisualizer 
          threats={detectedThreats}
          isVisualizationActive={isVisualizationActive}
        />
        
        {/* Sonar Range Visualizer */}
        <SonarRangeVisualizer 
          submarinePosition={submarinePosition}
          range={detectionRange}
          direction={scanDirection}
          isActive={isScanning}
        />
      </Suspense>
    </Canvas>
  );
}