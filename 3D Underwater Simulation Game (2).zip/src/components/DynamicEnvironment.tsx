import { useMemo, useEffect, useState } from 'react';

export interface DynamicThreat {
  id: number;
  position: [number, number, number];
  type: 'submarine' | 'drone' | 'torpedo' | 'mine';
  threat: number;
}

interface DynamicEnvironmentProps {
  submarinePosition: [number, number, number];
  onThreatsUpdate: (threats: DynamicThreat[], mines: any[]) => void;
}

export function DynamicEnvironment({ submarinePosition, onThreatsUpdate }: DynamicEnvironmentProps) {
  const [generatedZones, setGeneratedZones] = useState<Set<string>>(new Set());
  
  // Generate zone key based on submarine position
  const getCurrentZone = (pos: [number, number, number]) => {
    const zoneSize = 50;
    const zoneX = Math.floor(pos[0] / zoneSize);
    const zoneZ = Math.floor(pos[2] / zoneSize);
    return `${zoneX},${zoneZ}`;
  };
  
  useEffect(() => {
    const currentZone = getCurrentZone(submarinePosition);
    
    if (!generatedZones.has(currentZone)) {
      // Generate new threats for this zone
      const [zoneX, zoneZ] = currentZone.split(',').map(Number);
      const basePosX = zoneX * 50;
      const basePosZ = zoneZ * 50;
      
      // Generate threats contextually
      const newThreats: DynamicThreat[] = [];
      const newMines: any[] = [];
      
      // Determine zone characteristics based on position
      const threatDensity = Math.random();
      
      // Submarine threats (20% chance per zone)
      if (threatDensity > 0.8) {
        for (let i = 0; i < Math.floor(Math.random() * 2) + 1; i++) {
          newThreats.push({
            id: Date.now() + Math.random() * 10000,
            position: [
              basePosX + (Math.random() - 0.5) * 40,
              -15 - Math.random() * 10,
              basePosZ + (Math.random() - 0.5) * 40
            ],
            type: Math.random() > 0.5 ? 'submarine' : 'drone',
            threat: 0.85 + Math.random() * 0.15
          });
        }
      }
      
      // Mines (30% chance per zone)
      if (threatDensity > 0.7) {
        for (let i = 0; i < Math.floor(Math.random() * 3) + 1; i++) {
          newMines.push({
            id: Date.now() + Math.random() * 10000,
            position: [
              basePosX + (Math.random() - 0.5) * 40,
              -20 - Math.random() * 8,
              basePosZ + (Math.random() - 0.5) * 40
            ]
          });
        }
      }
      
      // Torpedoes (rare, 10% chance)
      if (threatDensity > 0.9) {
        newThreats.push({
          id: Date.now() + Math.random() * 10000,
          position: [
            basePosX + (Math.random() - 0.5) * 30,
            -18 - Math.random() * 5,
            basePosZ + (Math.random() - 0.5) * 30
          ],
          type: 'torpedo',
          threat: 0.98
        });
      }
      
      // Update generated zones
      setGeneratedZones(prev => new Set(prev).add(currentZone));
      
      // Notify parent of new threats
      if (newThreats.length > 0 || newMines.length > 0) {
        onThreatsUpdate(newThreats, newMines);
      }
    }
  }, [submarinePosition, generatedZones, onThreatsUpdate]);
  
  return null; // This component manages data, no visual output
}
