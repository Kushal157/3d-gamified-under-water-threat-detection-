export function SceneLighting() {
  return (
    <>
      {/* Ambient light - ocean ambient */}
      <ambientLight intensity={0.35} color="#5a8fb5" />
      
      {/* Sun - directional light from above */}
      <directionalLight 
        position={[80, 100, 40]} 
        intensity={1.8} 
        color="#ffeedd"
        castShadow
        shadow-mapSize-width={4096}
        shadow-mapSize-height={4096}
        shadow-camera-far={300}
        shadow-camera-left={-150}
        shadow-camera-right={150}
        shadow-camera-top={150}
        shadow-camera-bottom={-150}
        shadow-bias={-0.0001}
      />
      
      {/* Secondary sun light for softer shadows */}
      <directionalLight 
        position={[-50, 60, -60]} 
        intensity={0.8} 
        color="#b5d5f5"
      />
      
      {/* Underwater ambient lights */}
      <pointLight position={[0, -8, 0]} intensity={0.8} color="#0088cc" distance={80} decay={2} />
      <pointLight position={[40, -15, -40]} intensity={0.6} color="#006699" distance={60} decay={2} />
      <pointLight position={[-40, -15, -40]} intensity={0.6} color="#006699" distance={60} decay={2} />
      <pointLight position={[0, -25, 0]} intensity={0.4} color="#004466" distance={50} decay={2} />
      
      {/* Caustic light simulation */}
      <spotLight
        position={[20, 5, 20]}
        angle={Math.PI / 6}
        penumbra={0.5}
        intensity={0.5}
        color="#88ccff"
        distance={50}
        decay={2}
      />
      <spotLight
        position={[-20, 5, -20]}
        angle={Math.PI / 6}
        penumbra={0.5}
        intensity={0.5}
        color="#88ccff"
        distance={50}
        decay={2}
      />
      
      {/* Hemisphere light for better color gradation */}
      <hemisphereLight
        args={['#87ceeb', '#1a3a52', 0.6]}
        position={[0, 50, 0]}
      />
    </>
  );
}
