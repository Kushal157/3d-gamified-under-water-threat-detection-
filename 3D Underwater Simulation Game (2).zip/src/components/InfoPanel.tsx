import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Waves, Brain, Radio } from 'lucide-react';

export function InfoPanel() {
  return (
    <Card className="bg-slate-900/90 border-cyan-500/30 backdrop-blur-sm p-4">
      <div className="flex items-center justify-between flex-wrap gap-4">
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg">
            <Waves className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl text-white">Underwater Threat Detection System</h1>
            <p className="text-slate-400 text-sm">AI-Powered Sonar Analysis Platform</p>
          </div>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            <div>
              <p className="text-xs text-slate-500">Sonar Type</p>
              <p className="text-sm text-white">Active Array</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400" />
            <div>
              <p className="text-xs text-slate-500">AI Model</p>
              <p className="text-sm text-white">YOLOv8-Underwater</p>
            </div>
          </div>
          
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            SYSTEM ONLINE
          </Badge>
        </div>
      </div>
    </Card>
  );
}
