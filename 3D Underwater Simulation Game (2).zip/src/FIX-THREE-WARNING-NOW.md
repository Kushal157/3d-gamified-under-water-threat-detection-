# 🔧 Fix Three.js Multiple Instances Warning

## ⚡ Quick Fix (Run This Now!)

### Option 1: Clear Cache and Reinstall (RECOMMENDED)

**Linux/Mac:**
```bash
chmod +x clear-cache.sh
./clear-cache.sh
npm install
npm run dev
```

**Windows:**
```bash
clear-cache.bat
npm install
npm run dev
```

### Option 2: Force Vite to Rebuild

Stop the dev server if running, then:

```bash
# Delete Vite cache
rm -rf .vite
rm -rf node_modules/.vite

# Restart with force flag (already configured in package.json)
npm run dev
```

### Option 3: Nuclear Option (If Warning Persists)

```bash
# Clear everything
rm -rf node_modules .vite dist package-lock.json

# Clear npm cache
npm cache clean --force

# Reinstall
npm install

# Start fresh
npm run dev
```

## ✅ What Was Fixed

Your project already has all the correct configurations:

1. ✅ **vite.config.ts** - Configured with:
   - `dedupe` for three.js packages
   - `force: true` in optimizeDeps
   - Manual chunks for three.js
   - Proper alias resolution

2. ✅ **package.json** - Configured with:
   - `overrides` to force single three.js version
   - `resolutions` for yarn/pnpm compatibility
   - `peerDependencies` declaration
   - `--force` flag in dev script

3. ✅ **main.tsx** - Sets global THREE instance

4. ✅ **.npmrc** - npm configuration for proper hoisting

5. ✅ **All imports** - Consistent `import * as THREE from 'three'`

## 🔍 Why This Warning Happens

The warning appears because Vite caches the pre-bundled dependencies. Even though your config is correct, the old cached version might still load multiple Three.js instances.

## 📋 Verification Steps

After running the fix:

1. **Check console** - The warning should be gone
2. **Verify single instance:**
   ```bash
   npm ls three
   ```
   Should show only ONE version

3. **Check in browser console:**
   ```javascript
   console.log(THREE.REVISION)
   ```
   Should only appear once

## 🎯 Most Common Solutions

### If Warning Still Shows:

1. **Hard refresh browser** - Ctrl+Shift+R (or Cmd+Shift+R on Mac)
2. **Clear browser cache** - Sometimes browser caches old bundles
3. **Restart terminal** - Close and reopen terminal, then `npm run dev`
4. **Check for running instances** - Make sure no other dev servers are running

## 🚀 Best Practices Going Forward

1. Always use `npm run dev` (already has `--force` flag)
2. If you install new packages, clear `.vite` folder
3. Keep imports consistent: `import * as THREE from 'three'`
4. Don't import Three.js types separately

## 💡 Pro Tips

- **Use pnpm** - Better at deduplication than npm
  ```bash
  npm install -g pnpm
  pnpm install
  pnpm dev
  ```

- **Check for duplicate installs regularly:**
  ```bash
  npm ls three
  ```

- **Clear cache after package updates:**
  ```bash
  rm -rf .vite && npm run dev
  ```

## 📞 Still Having Issues?

If the warning persists after trying all options:

1. Make sure you've completely stopped the dev server
2. Delete these folders/files:
   - `node_modules`
   - `.vite`
   - `dist`
   - `package-lock.json`
3. Run `npm cache clean --force`
4. Reinstall: `npm install`
5. Start: `npm run dev`
6. Hard refresh browser

---

**This warning is usually just a cache issue!** The configuration is already correct. 🎉
