# 🚀 Quick Start Guide - YOLOv8 Threat Visualization

## 30-Second Tutorial

### Step 1: Start a Scan
1. Click **"Sonar Control"** button (bottom left)
2. Click any scan direction button (EAST, WEST, NORTH, SOUTH, or SCAN ALL)
3. Wait 3 seconds for YOLOv8 processing

### Step 2: View Detections
1. Click **"Threat Detection"** button (bottom right)
2. See detected threats with confidence scores
3. Check the threat count badge on the button

### Step 3: Visualize in 3D
1. Click **"Visualize Threats"** button (green button in threat panel)
2. See 3D bounding boxes appear around detected objects
3. Use mouse to orbit around and inspect threats
4. Click **"Hide Visualization"** to remove markers

## 🎮 Controls

### Mouse Controls
- **Left Click + Drag**: Rotate camera (orbit)
- **Right Click + Drag**: Pan camera
- **Scroll Wheel**: Zoom in/out

### UI Buttons
- **Sonar Control**: Configure detection settings
- **Threat Detection**: View detected threats
- **Visualize Threats**: Toggle 3D markers on/off
- **SCAN [Direction]**: Initiate directional scan
- **RESET**: Clear all detections

## 🎯 What You'll See

### During Scanning
- Purple "YOLOv8 Processing" indicator (top-left)
- Cyan pulsing overlay
- "SCANNING..." message

### After Detection
- Threat cards with details
- Red badge showing count
- Console logs with YOLOv8 stats

### When Visualized
- 🔴 Red boxes: Submarines/Torpedoes
- 🟠 Orange boxes: Mines
- 🟡 Yellow boxes: Drones
- Floating labels with ID, distance, confidence
- Pulsing glow effects
- Warning beacons on top

## 💡 Tips

1. **Try SCAN ALL first** to find all threats
2. **Use EAST/WEST** for horizontal scanning focus
3. **Adjust AI Sensitivity** for more/fewer detections
4. **Increase Range** to detect distant threats
5. **Orbit around visualizations** to see all angles

## 🐛 Troubleshooting

**No detections appearing?**
- Increase detection range
- Lower AI sensitivity
- Try SCAN ALL direction

**Can't see visualizations?**
- Make sure you clicked "Visualize Threats"
- Check that threats were detected first
- Look for green "3D Visualization Active" indicator

**Performance issues?**
- Reduce detection range
- Hide visualization when not needed
- Close other browser tabs

## 📊 Understanding Results

### Confidence Score
- **90-99%**: Very high confidence
- **80-89%**: High confidence
- **70-79%**: Medium confidence
- **65-69%**: Lower confidence

### Threat Levels
- **CRITICAL**: Immediate danger (torpedoes, close submarines)
- **HIGH**: Significant threat (submarines, high-confidence detections)
- **MEDIUM**: Moderate threat (drones, distant objects)
- **LOW**: Minimal threat (low confidence detections)

### Distance
- Measured in meters from your submarine
- Closer = more dangerous
- Used in threat level calculation

---

**Ready to detect threats?** Click "Sonar Control" to begin! 🎯
