# YOLOv8 Threat Detection & Visualization

## Overview

This underwater threat detection system now uses **YOLOv8** (You Only Look Once v8) AI model for real-time object detection and threat classification. The system provides both traditional detection displays and advanced 3D visualization of detected threats.

## Features

### 🤖 YOLOv8 AI Detection
- **Model**: YOLOv8n-underwater (optimized for underwater sonar detection)
- **Processing Time**: ~800ms inference time (simulated)
- **Detection Classes**: Submarine, Mine, Torpedo, Drone
- **Confidence Scoring**: AI-powered confidence levels (65-99%)
- **Bounding Box Detection**: Normalized coordinates for precise localization

### 📊 Threat Classification
The YOLOv8 model automatically assesses threat levels based on:
- **Object Type**: Different threat types have varying risk levels
- **Detection Confidence**: Higher confidence = more reliable detection
- **Distance**: Proximity-based threat assessment
- **Threat Levels**: Critical, High, Medium, Low

### 🎯 3D Visualization System
When you click the "Visualize Threats" button, detected objects are highlighted with:
- **3D Bounding Boxes**: Wireframe boxes showing object boundaries
- **Corner Markers**: Spherical markers at bbox corners
- **Threat Labels**: Real-time information display including:
  - Object type (SUBMARINE, MINE, TORPEDO, DRONE)
  - Detection ID
  - Distance in meters
  - Confidence percentage
- **Visual Effects**:
  - Pulsing glow effects
  - Warning beacons
  - Animated point lights
  - Scanning grid at base

## How to Use

### Step 1: Configure Sonar
1. Click the **"Sonar Control"** button at the bottom
2. Adjust detection range (10-100m)
3. Set AI sensitivity (0.5-1.0)

### Step 2: Initiate Scan
1. Select scan direction:
   - **SCAN ALL**: 360-degree omnidirectional scan
   - **EAST**: Eastward directional scan
   - **WEST**: Westward directional scan
   - **NORTH**: Northward directional scan
   - **SOUTH**: Southward directional scan
2. Click the direction button to start scanning

### Step 3: View Detections
1. During scanning, you'll see "YOLOv8 AI Processing..." message
2. After 3 seconds, detections appear
3. Click **"Threat Detection"** button to view results
4. See detailed threat cards with:
   - Threat type and ID
   - Distance from submarine
   - AI confidence score
   - Threat level assessment

### Step 4: Visualize in 3D
1. After threats are detected, click **"Visualize Threats"** button
2. The 3D scene will show:
   - Bounding boxes around each threat
   - Animated labels with threat info
   - Pulsing visual effects
   - Color-coded by threat type:
     - 🔴 Red: Submarine/Torpedo (Critical)
     - 🟠 Orange: Mine (High)
     - 🟡 Yellow: Drone (Medium)

### Step 5: Toggle Visualization
- Click **"Hide Visualization"** to remove 3D markers
- Click **"Visualize Threats"** again to show them
- Use orbit controls to inspect threats from different angles

## YOLOv8 Detection Pipeline

```
Sonar Scan → YOLOv8 Model → Object Detection → Threat Assessment → Visualization
```

### Detection Process
1. **Input**: Sonar scan data with position coordinates
2. **Processing**: YOLOv8 model analyzes potential threats
3. **Classification**: Objects classified into categories
4. **Bounding Boxes**: Calculate precise object boundaries
5. **Confidence**: AI assigns confidence scores
6. **Threat Level**: Automatic risk assessment
7. **Output**: Structured detection results

## Technical Details

### YOLOv8 Model Information
- **Version**: YOLOv8n-underwater
- **Architecture**: Optimized for real-time detection
- **Input**: Positional sonar data
- **Output**: Detection boxes with class probabilities
- **Inference Time**: ~800ms per scan

### Detection Data Structure
```typescript
{
  id: number,              // Unique detection ID
  class: string,           // Object class (submarine, mine, etc.)
  confidence: number,      // AI confidence (0-1)
  bbox: {                  // Bounding box coordinates
    x: number,             // Normalized X position
    y: number,             // Normalized Y position
    width: number,         // Box width
    height: number         // Box height
  },
  position: [x, y, z],     // 3D world coordinates
  threatLevel: string      // Critical/High/Medium/Low
}
```

### Visualization Components
- **ThreatVisualizer.tsx**: Main 3D visualization component
- **YOLOv8Detector.tsx**: AI detection simulation engine
- **ThreatMarker**: Individual threat 3D marker component

## Tips for Best Results

1. **Start with SCAN ALL** to get a complete picture
2. **Use directional scans** for focused threat analysis
3. **Adjust AI sensitivity** based on your needs:
   - Higher sensitivity (0.8-1.0): Fewer false positives
   - Lower sensitivity (0.5-0.7): More detections
4. **Increase detection range** for long-range surveillance
5. **Use visualization** to understand threat positioning
6. **Orbit the camera** to view threats from all angles

## Future Enhancements

- Real YOLOv8 model integration (currently simulated)
- Live camera feed processing
- Historical threat tracking
- Automated threat response recommendations
- Multi-spectral detection fusion
- Machine learning model retraining

## System Requirements

- Modern web browser with WebGL 2.0 support
- Minimum 4GB RAM
- GPU acceleration recommended for smooth visualization

---

**Model**: YOLOv8n-underwater
**Status**: ✅ OPERATIONAL
**Last Updated**: November 5, 2025
